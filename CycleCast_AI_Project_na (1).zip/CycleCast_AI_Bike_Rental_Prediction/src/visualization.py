"""
Module: visualization.py
Project: Bike Rental Demand Prediction Using Machine Learning
Institution: Amrita Vishwa Vidyapeetham (BCA Final Year Project)

Description:
    Contains reusable plotting functions using Matplotlib and Seaborn to generate
    publication-quality visualizations for Exploratory Data Analysis and project reports.
"""

import os
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np


# Setup consistent style and color palette
sns.set_theme(style="whitegrid", font="sans-serif", font_scale=1.05)
plt.rcParams['figure.autolayout'] = True
plt.rcParams['font.size'] = 11

REPORTS_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "reports", "graphs")
os.makedirs(REPORTS_DIR, exist_ok=True)


def plot_target_distribution(df: pd.DataFrame, output_dir: str = REPORTS_DIR) -> str:
    """
    Plots the histogram, KDE curve, and box plot of the target variable (cnt).
    """
    fig, (ax_box, ax_hist) = plt.subplots(
        2, 1, figsize=(10, 7), sharex=True, gridspec_kw={'height_ratios': [0.25, 0.75]}
    )
    
    # Box plot
    sns.boxplot(x=df['cnt'], ax=ax_box, color="#4C72B0", fliersize=3)
    ax_box.set(xlabel="")
    ax_box.set_title("Distribution of Total Hourly Bike Rentals (cnt)", fontsize=14, fontweight="bold", pad=10)

    # Histogram + KDE
    sns.histplot(df['cnt'], kde=True, ax=ax_hist, color="#4C72B0", bins=40, stat="density", alpha=0.6)
    mean_val = df['cnt'].mean()
    median_val = df['cnt'].median()
    ax_hist.axvline(mean_val, color="red", linestyle="--", linewidth=2, label=f"Mean: {mean_val:.1f}")
    ax_hist.axvline(median_val, color="green", linestyle="-.", linewidth=2, label=f"Median: {median_val:.1f}")
    
    ax_hist.set_xlabel("Hourly Rental Count (cnt)", fontsize=12, fontweight="bold")
    ax_hist.set_ylabel("Probability Density", fontsize=12, fontweight="bold")
    ax_hist.legend(loc="upper right", frameon=True)

    output_path = os.path.join(output_dir, "01_target_distribution.png")
    fig.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    return output_path


def plot_hourly_trend(df: pd.DataFrame, output_dir: str = REPORTS_DIR) -> str:
    """
    Plots the hourly rental pattern separated by working day vs weekend/holiday.
    """
    fig, ax = plt.subplots(figsize=(12, 6))
    
    df_copy = df.copy()
    df_copy['Day Type'] = df_copy['workingday'].map({1: 'Working Day', 0: 'Weekend / Holiday'})
    
    hourly_avg = df_copy.groupby(['hr', 'Day Type'])['cnt'].mean().reset_index()
    
    sns.lineplot(
        data=hourly_avg, x='hr', y='cnt', hue='Day Type', marker='o',
        palette={'Working Day': '#1f77b4', 'Weekend / Holiday': '#ff7f0e'},
        linewidth=2.5, markersize=7, ax=ax
    )
    
    ax.set_title("Hourly Bike Rental Demand: Working Days vs. Weekends / Holidays", fontsize=14, fontweight="bold", pad=12)
    ax.set_xlabel("Hour of the Day (0 to 23)", fontsize=12, fontweight="bold")
    ax.set_ylabel("Average Rental Count (bikes/hour)", fontsize=12, fontweight="bold")
    ax.set_xticks(range(0, 24))
    ax.grid(True, linestyle="--", alpha=0.6)
    ax.legend(title="Day Classification", frameon=True)
    
    # Annotate peak commute hours
    ax.annotate('Morning Peak (8 AM)', xy=(8, 470), xytext=(4, 520),
                arrowprops=dict(facecolor='black', shrink=0.05, width=1.5, headwidth=7),
                fontweight='bold', fontsize=10)
    ax.annotate('Evening Peak (5-6 PM)', xy=(17, 525), xytext=(18, 570),
                arrowprops=dict(facecolor='black', shrink=0.05, width=1.5, headwidth=7),
                fontweight='bold', fontsize=10)

    output_path = os.path.join(output_dir, "02_hourly_rentals.png")
    fig.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    return output_path


def plot_seasonal_distribution(df: pd.DataFrame, output_dir: str = REPORTS_DIR) -> str:
    """
    Plots bike rental counts across four seasons using box plots.
    """
    fig, ax = plt.subplots(figsize=(10, 6))
    df_copy = df.copy()
    season_map = {1: 'Spring', 2: 'Summer', 3: 'Fall', 4: 'Winter'}
    df_copy['Season Name'] = df_copy['season'].map(season_map)
    order = ['Spring', 'Summer', 'Fall', 'Winter']

    sns.boxplot(
        data=df_copy, x='Season Name', y='cnt', order=order,
        palette='Set2', showmeans=True,
        meanprops={"marker": "D", "markerfacecolor": "red", "markeredgecolor": "black", "markersize": "7"},
        ax=ax
    )

    ax.set_title("Bike Rental Demand Distribution Across Seasons", fontsize=14, fontweight="bold", pad=12)
    ax.set_xlabel("Season", fontsize=12, fontweight="bold")
    ax.set_ylabel("Hourly Rental Count (cnt)", fontsize=12, fontweight="bold")
    ax.grid(True, linestyle="--", alpha=0.6)

    output_path = os.path.join(output_dir, "03_seasonal_rentals.png")
    fig.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    return output_path


def plot_monthly_trend(df: pd.DataFrame, output_dir: str = REPORTS_DIR) -> str:
    """
    Plots the monthly average bike rentals over the two calendar years.
    """
    fig, ax = plt.subplots(figsize=(11, 6))
    df_copy = df.copy()
    month_map = {1: 'Jan', 2: 'Feb', 3: 'Mar', 4: 'Apr', 5: 'May', 6: 'Jun', 
                 7: 'Jul', 8: 'Aug', 9: 'Sep', 10: 'Oct', 11: 'Nov', 12: 'Dec'}
    df_copy['Month Name'] = df_copy['mnth'].map(month_map)
    df_copy['Year'] = df_copy['yr'].map({0: '2011', 1: '2012'})
    
    monthly_data = df_copy.groupby(['Month Name', 'Year', 'mnth'])['cnt'].mean().reset_index()
    monthly_data = monthly_data.sort_values('mnth')

    sns.barplot(
        data=monthly_data, x='Month Name', y='cnt', hue='Year',
        palette='Blues_d', ax=ax
    )

    ax.set_title("Monthly Average Bike Rentals (Year 2011 vs. Year 2012)", fontsize=14, fontweight="bold", pad=12)
    ax.set_xlabel("Month", fontsize=12, fontweight="bold")
    ax.set_ylabel("Average Hourly Rentals (cnt)", fontsize=12, fontweight="bold")
    ax.legend(title="Calendar Year", frameon=True)
    ax.grid(True, linestyle="--", alpha=0.6)

    output_path = os.path.join(output_dir, "04_monthly_rentals.png")
    fig.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    return output_path


def plot_weekday_distribution(df: pd.DataFrame, output_dir: str = REPORTS_DIR) -> str:
    """
    Plots average bike rental demand across days of the week.
    """
    fig, ax = plt.subplots(figsize=(10, 6))
    df_copy = df.copy()
    day_map = {0: 'Sun', 1: 'Mon', 2: 'Tue', 3: 'Wed', 4: 'Thu', 5: 'Fri', 6: 'Sat'}
    df_copy['Day Name'] = df_copy['weekday'].map(day_map)
    order = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']

    sns.barplot(
        data=df_copy, x='Day Name', y='cnt', order=order,
        palette='crest', errorbar=None, ax=ax
    )

    ax.set_title("Average Bike Rentals by Day of the Week", fontsize=14, fontweight="bold", pad=12)
    ax.set_xlabel("Day of Week", fontsize=12, fontweight="bold")
    ax.set_ylabel("Average Hourly Rentals (cnt)", fontsize=12, fontweight="bold")
    ax.grid(True, linestyle="--", alpha=0.6)

    output_path = os.path.join(output_dir, "05_weekday_rentals.png")
    fig.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    return output_path


def plot_workingday_and_holiday(df: pd.DataFrame, output_dir: str = REPORTS_DIR) -> str:
    """
    Compares demand distributions across Working Days vs. Non-Working Days and Holidays.
    """
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 6))
    df_copy = df.copy()
    
    df_copy['Working Day'] = df_copy['workingday'].map({1: 'Working Day', 0: 'Non-Working Day'})
    df_copy['Holiday Status'] = df_copy['holiday'].map({1: 'Holiday', 0: 'Regular Day'})

    # Plot 1: Working day box plot
    sns.boxplot(data=df_copy, x='Working Day', y='cnt', palette='pastel', ax=ax1, showmeans=True)
    ax1.set_title("Rentals: Working Day vs. Non-Working Day", fontsize=12, fontweight="bold")
    ax1.set_xlabel("Working Day Status", fontsize=11, fontweight="bold")
    ax1.set_ylabel("Hourly Rental Count (cnt)", fontsize=11, fontweight="bold")

    # Plot 2: Holiday box plot
    sns.boxplot(data=df_copy, x='Holiday Status', y='cnt', palette='Set1', ax=ax2, showmeans=True)
    ax2.set_title("Rentals: Regular Day vs. Public Holiday", fontsize=12, fontweight="bold")
    ax2.set_xlabel("Holiday Classification", fontsize=11, fontweight="bold")
    ax2.set_ylabel("Hourly Rental Count (cnt)", fontsize=11, fontweight="bold")

    fig.suptitle("Impact of Working Days & Public Holidays on Bike Rentals", fontsize=14, fontweight="bold", y=1.02)
    
    output_path = os.path.join(output_dir, "06_workingday_vs_holiday.png")
    fig.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    return output_path


def plot_temperature_relationship(df: pd.DataFrame, output_dir: str = REPORTS_DIR) -> str:
    """
    Plots scatter plot with regression trend between temperature (Celsius) and rental count.
    """
    fig, ax = plt.subplots(figsize=(10, 6))
    df_copy = df.copy()
    # Unnormalize temperature: temp * 41 Celsius
    df_copy['temp_celsius'] = df_copy['temp'] * 41

    sns.regplot(
        data=df_copy.sample(n=3000, random_state=42), x='temp_celsius', y='cnt',
        scatter_kws={'alpha': 0.2, 'color': '#d95f02', 's': 15},
        line_kws={'color': '#1b9e77', 'linewidth': 2.5},
        ax=ax
    )

    ax.set_title("Relationship Between Temperature (°C) and Hourly Bike Rentals", fontsize=14, fontweight="bold", pad=12)
    ax.set_xlabel("Temperature in Celsius (°C)", fontsize=12, fontweight="bold")
    ax.set_ylabel("Hourly Rental Count (cnt)", fontsize=12, fontweight="bold")
    ax.grid(True, linestyle="--", alpha=0.6)

    output_path = os.path.join(output_dir, "07_temperature_vs_rentals.png")
    fig.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    return output_path


def plot_humidity_relationship(df: pd.DataFrame, output_dir: str = REPORTS_DIR) -> str:
    """
    Plots relationship between relative humidity percentage and rental count.
    """
    fig, ax = plt.subplots(figsize=(10, 6))
    df_copy = df.copy()
    # Unnormalize humidity: hum * 100
    df_copy['humidity_pct'] = df_copy['hum'] * 100

    sns.regplot(
        data=df_copy.sample(n=3000, random_state=42), x='humidity_pct', y='cnt',
        scatter_kws={'alpha': 0.2, 'color': '#7570b3', 's': 15},
        line_kws={'color': '#e7298a', 'linewidth': 2.5},
        ax=ax
    )

    ax.set_title("Relationship Between Relative Humidity (%) and Hourly Bike Rentals", fontsize=14, fontweight="bold", pad=12)
    ax.set_xlabel("Relative Humidity (%)", fontsize=12, fontweight="bold")
    ax.set_ylabel("Hourly Rental Count (cnt)", fontsize=12, fontweight="bold")
    ax.grid(True, linestyle="--", alpha=0.6)

    output_path = os.path.join(output_dir, "08_humidity_vs_rentals.png")
    fig.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    return output_path


def plot_windspeed_relationship(df: pd.DataFrame, output_dir: str = REPORTS_DIR) -> str:
    """
    Plots relationship between wind speed (km/h) and rental count.
    """
    fig, ax = plt.subplots(figsize=(10, 6))
    df_copy = df.copy()
    # Unnormalize windspeed: windspeed * 67 km/h
    df_copy['windspeed_kmh'] = df_copy['windspeed'] * 67

    sns.regplot(
        data=df_copy.sample(n=3000, random_state=42), x='windspeed_kmh', y='cnt',
        scatter_kws={'alpha': 0.2, 'color': '#66a61e', 's': 15},
        line_kws={'color': '#e6ab02', 'linewidth': 2.5},
        ax=ax
    )

    ax.set_title("Relationship Between Wind Speed (km/h) and Hourly Bike Rentals", fontsize=14, fontweight="bold", pad=12)
    ax.set_xlabel("Wind Speed (km/h)", fontsize=12, fontweight="bold")
    ax.set_ylabel("Hourly Rental Count (cnt)", fontsize=12, fontweight="bold")
    ax.grid(True, linestyle="--", alpha=0.6)

    output_path = os.path.join(output_dir, "09_windspeed_vs_rentals.png")
    fig.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    return output_path


def plot_correlation_heatmap(df: pd.DataFrame, output_dir: str = REPORTS_DIR) -> str:
    """
    Computes and plots the Pearson correlation matrix for numerical and continuous features.
    """
    fig, ax = plt.subplots(figsize=(11, 9))
    
    # Feature columns to include in correlation matrix
    cols = ['season', 'yr', 'mnth', 'hr', 'holiday', 'weekday', 'workingday', 'weathersit', 
            'temp', 'atemp', 'hum', 'windspeed', 'cnt']
    corr_df = df[[c for c in cols if c in df.columns]].corr()

    # Mask for upper triangle to create clean aesthetic
    mask = np.triu(np.ones_like(corr_df, dtype=bool))

    sns.heatmap(
        corr_df, mask=mask, annot=True, fmt=".2f", cmap="vlag",
        vmin=-1, vmax=1, square=True, linewidths=.6, cbar_kws={"shrink": .8},
        ax=ax
    )

    ax.set_title("Correlation Heatmap: Calendar, Weather & Bike Demand", fontsize=14, fontweight="bold", pad=14)

    output_path = os.path.join(output_dir, "10_correlation_heatmap.png")
    fig.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    return output_path
