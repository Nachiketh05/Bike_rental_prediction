"""
Module: eda.py
Project: Bike Rental Demand Prediction Using Machine Learning
Institution: Amrita Vishwa Vidyapeetham (BCA Final Year Project)

Description:
    Performs comprehensive Exploratory Data Analysis (EDA):
    1. Statistical summary & distribution shape (skewness, kurtosis).
    2. Hourly, seasonal, monthly, weekday, and holiday pattern analysis.
    3. Weather impacts (temperature, humidity, wind speed).
    4. Correlation matrix and multicollinearity inspection.
    5. Generates and saves all high-resolution figures into reports/graphs/.
    6. Summarizes analytical findings for academic viva defense.
"""

import os
import sys

# Ensure root directory is on python path for module imports
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

import pandas as pd
import numpy as np
from src.data_preprocessing import load_raw_data, preprocess_data, CLEANED_DATA_PATH, RAW_DATA_PATH
from src.visualization import (
    plot_target_distribution,
    plot_hourly_trend,
    plot_seasonal_distribution,
    plot_monthly_trend,
    plot_weekday_distribution,
    plot_workingday_and_holiday,
    plot_temperature_relationship,
    plot_humidity_relationship,
    plot_windspeed_relationship,
    plot_correlation_heatmap,
    REPORTS_DIR
)


RESULTS_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "reports", "model_results")
os.makedirs(RESULTS_DIR, exist_ok=True)


def get_cleaned_dataframe() -> pd.DataFrame:
    """
    Retrieves the cleaned dataframe. If cleaned_data.csv doesn't exist,
    triggers preprocessing first.
    """
    if os.path.exists(CLEANED_DATA_PATH) and os.path.getsize(CLEANED_DATA_PATH) > 0:
        df = pd.read_csv(CLEANED_DATA_PATH)
        if 'dteday' in df.columns:
            df['dteday'] = pd.to_datetime(df['dteday'])
        return df
    else:
        df, _, _ = preprocess_data(RAW_DATA_PATH, CLEANED_DATA_PATH)
        return df


def generate_statistical_summary(df: pd.DataFrame) -> pd.DataFrame:
    """
    Computes extended statistical metrics: count, mean, std, min, 25%, 50%, 75%, max,
    plus Skewness and Kurtosis for numerical attributes.
    """
    num_cols = ['temp', 'atemp', 'hum', 'windspeed', 'cnt']
    stats = df[num_cols].describe().T
    stats['skewness'] = df[num_cols].skew()
    stats['kurtosis'] = df[num_cols].kurt()
    
    # Save to reports/model_results
    summary_path = os.path.join(RESULTS_DIR, "eda_statistical_summary.csv")
    stats.to_csv(summary_path)
    return stats


def compute_correlation_matrix(df: pd.DataFrame) -> pd.DataFrame:
    """
    Calculates the Pearson correlation matrix for modeling features and exports it.
    """
    cols = ['season', 'yr', 'mnth', 'hr', 'holiday', 'weekday', 'workingday', 'weathersit', 
            'temp', 'atemp', 'hum', 'windspeed', 'cnt']
    corr = df[cols].corr()
    
    corr_path = os.path.join(RESULTS_DIR, "correlation_matrix.csv")
    corr.to_csv(corr_path)
    return corr


def run_full_eda() -> dict:
    """
    Runs the end-to-end EDA pipeline and generates all charts and summaries.
    """
    print("\n" + "=" * 80)
    print("      STARTING EXPLORATORY DATA ANALYSIS (EDA): BIKE RENTAL PREDICTION")
    print("=" * 80)

    # 1. Load Data
    df = get_cleaned_dataframe()
    print(f"Dataset Loaded Successfully: {df.shape[0]} rows, {df.shape[1]} columns\n")

    # 2. Statistical Summary
    print("-" * 80)
    print("1. STATISTICAL SUMMARY OF NUMERICAL FEATURES & TARGET")
    print("-" * 80)
    summary_stats = generate_statistical_summary(df)
    print(summary_stats.round(3).to_string())

    # 3. Correlation with Target
    print("\n" + "-" * 80)
    print("2. PEARSON CORRELATION WITH TARGET VARIABLE (cnt)")
    print("-" * 80)
    corr_matrix = compute_correlation_matrix(df)
    target_corr = corr_matrix['cnt'].sort_values(ascending=False)
    print(target_corr.round(3).to_string())

    # 4. Generate All 10 High-Resolution Plots
    print("\n" + "-" * 80)
    print("3. GENERATING & SAVING HIGH-RESOLUTION VISUALIZATIONS")
    print("-" * 80)

    plots_generated = {}
    
    print("  [1/10] Generating Target Distribution Plot...")
    plots_generated["01_target_distribution"] = plot_target_distribution(df, REPORTS_DIR)

    print("  [2/10] Generating Hourly Demand Trend Plot...")
    plots_generated["02_hourly_rentals"] = plot_hourly_trend(df, REPORTS_DIR)

    print("  [3/10] Generating Seasonal Distribution Plot...")
    plots_generated["03_seasonal_rentals"] = plot_seasonal_distribution(df, REPORTS_DIR)

    print("  [4/10] Generating Monthly Demand Comparison Plot...")
    plots_generated["04_monthly_rentals"] = plot_monthly_trend(df, REPORTS_DIR)

    print("  [5/10] Generating Weekday Distribution Plot...")
    plots_generated["05_weekday_rentals"] = plot_weekday_distribution(df, REPORTS_DIR)

    print("  [6/10] Generating Working Day vs. Holiday Comparison Plot...")
    plots_generated["06_workingday_vs_holiday"] = plot_workingday_and_holiday(df, REPORTS_DIR)

    print("  [7/10] Generating Temperature vs. Rentals Plot...")
    plots_generated["07_temperature_vs_rentals"] = plot_temperature_relationship(df, REPORTS_DIR)

    print("  [8/10] Generating Humidity vs. Rentals Plot...")
    plots_generated["08_humidity_vs_rentals"] = plot_humidity_relationship(df, REPORTS_DIR)

    print("  [9/10] Generating Wind Speed vs. Rentals Plot...")
    plots_generated["09_windspeed_vs_rentals"] = plot_windspeed_relationship(df, REPORTS_DIR)

    print("  [10/10] Generating Correlation Heatmap...")
    plots_generated["10_correlation_heatmap"] = plot_correlation_heatmap(df, REPORTS_DIR)

    print(f"\nAll 10 visualizations successfully generated and saved into:\n  {REPORTS_DIR}")

    return {
        "df": df,
        "summary_stats": summary_stats,
        "target_corr": target_corr,
        "plots": plots_generated
    }


if __name__ == "__main__":
    results = run_full_eda()
