"""
Module: feature_engineering.py
Project: Bike Rental Demand Prediction Using Machine Learning
Institution: Amrita Vishwa Vidyapeetham (BCA Final Year Project)

Description:
    Performs comprehensive feature engineering and chronological train/test split:
    1. Extracts useful calendar and time features.
    2. Encodes cyclical features (hour, month, weekday) using sine/cosine transformations.
    3. Solves multicollinearity by eliminating 'atemp' (retaining 'temp').
    4. One-Hot Encodes non-ordinal categorical variables ('season', 'weathersit').
    5. Engineers domain-specific interaction features ('is_rush_hour', 'temp_hum_ratio').
    6. Implements strict chronological 80/20 Train/Test split (no temporal data leakage).
    7. Scales continuous features using StandardScaler fitted solely on training data.
    8. Serializes preprocessor pipeline to 'models/preprocessor.pkl'.
    9. Exports processed datasets to 'dataset/processed/'.
    10. Generates visual charts illustrating cyclical encoding and train/test timeline.
"""

import os
import sys
import json
import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler

# Ensure root directory is on python path
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from src.data_preprocessing import preprocess_data

CLEANED_DATA_PATH = os.path.join(BASE_DIR, "dataset", "cleaned_data.csv")
PROCESSED_DIR = os.path.join(BASE_DIR, "dataset", "processed")
MODELS_DIR = os.path.join(BASE_DIR, "models")
REPORTS_GRAPHS_DIR = os.path.join(BASE_DIR, "reports", "graphs")
RESULTS_DIR = os.path.join(BASE_DIR, "reports", "model_results")

os.makedirs(PROCESSED_DIR, exist_ok=True)
os.makedirs(MODELS_DIR, exist_ok=True)
os.makedirs(REPORTS_GRAPHS_DIR, exist_ok=True)
os.makedirs(RESULTS_DIR, exist_ok=True)


class BikeRentalFeatureEngineer:
    """
    Reusable feature engineering pipeline to transform raw inputs into model-ready features.
    Keeps transformation consistent between training and real-time Streamlit inference.
    """

    def __init__(self):
        self.scaler = StandardScaler()
        self.feature_columns = []
        self.numerical_cols = ['temp', 'hum', 'windspeed', 'temp_hum_ratio']
        self.is_fitted = False

    def transform_raw_dataframe(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Applies feature creation, cyclical transformations, and categorical encoding.
        Does NOT scale; scaling is performed after splitting to prevent leakage.
        """
        df_out = df.copy()

        # 1. Drop irrelevant & target-leakage columns if still present
        for col in ['instant', 'casual', 'registered', 'atemp']:
            if col in df_out.columns:
                df_out = df_out.drop(columns=[col])

        # 2. Cyclical Encoding: Hour (Period = 24)
        df_out['hr_sin'] = np.sin(2 * np.pi * df_out['hr'] / 24.0)
        df_out['hr_cos'] = np.cos(2 * np.pi * df_out['hr'] / 24.0)

        # 3. Cyclical Encoding: Month (Period = 12)
        df_out['mnth_sin'] = np.sin(2 * np.pi * df_out['mnth'] / 12.0)
        df_out['mnth_cos'] = np.cos(2 * np.pi * df_out['mnth'] / 12.0)

        # 4. Cyclical Encoding: Weekday (Period = 7)
        df_out['weekday_sin'] = np.sin(2 * np.pi * df_out['weekday'] / 7.0)
        df_out['weekday_cos'] = np.cos(2 * np.pi * df_out['weekday'] / 7.0)

        # 5. Domain Interaction Features
        # Rush Hour Indicator: High demand concentrated at 8-9 AM and 5-7 PM on working days
        df_out['is_rush_hour'] = ((df_out['workingday'] == 1) & (df_out['hr'].isin([8, 9, 17, 18, 19]))).astype(int)
        
        # Temperature-to-Humidity Comfort Ratio
        df_out['temp_hum_ratio'] = df_out['temp'] / (df_out['hum'] + 0.05)

        # 6. One-Hot Encoding for Non-Ordinal Categoricals: season (1 to 4) & weathersit (1 to 4)
        # Using pd.get_dummies with drop_first=True to avoid dummy variable trap in Linear Regression
        for s in [2, 3, 4]:
            df_out[f'season_{s}'] = (df_out['season'] == s).astype(int)

        for w in [2, 3, 4]:
            df_out[f'weathersit_{w}'] = (df_out['weathersit'] == w).astype(int)

        # Drop original raw categorical columns that have been one-hot encoded
        # Keep raw 'hr', 'weekday', 'mnth', 'workingday', 'holiday', 'yr' as they provide direct tree splits
        cols_to_drop = [c for c in ['season', 'weathersit', 'dteday'] if c in df_out.columns]
        df_out = df_out.drop(columns=cols_to_drop)

        return df_out

    def fit_transform(self, X_train: pd.DataFrame) -> pd.DataFrame:
        """
        Fits scalers on X_train and transforms features.
        """
        X_trans = self.transform_raw_dataframe(X_train)
        
        # Fit scaler on training numerical features only
        self.scaler.fit(X_trans[self.numerical_cols])
        X_trans[self.numerical_cols] = self.scaler.transform(X_trans[self.numerical_cols])

        self.feature_columns = list(X_trans.columns)
        self.is_fitted = True
        return X_trans

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        """
        Transforms new data (e.g. X_test or real-time user inputs) using fitted parameters.
        """
        if not self.is_fitted:
            raise ValueError("FeatureEngineer must be fitted before transforming new data.")
        
        X_trans = self.transform_raw_dataframe(X)
        
        # Ensure all training columns exist
        for col in self.feature_columns:
            if col not in X_trans.columns:
                X_trans[col] = 0

        # Maintain exact column order
        X_trans = X_trans[self.feature_columns]

        # Apply fitted scaler
        X_trans[self.numerical_cols] = self.scaler.transform(X_trans[self.numerical_cols])
        return X_trans


def transform_new_samples(df_raw: pd.DataFrame, artifacts_path: str = os.path.join(MODELS_DIR, "preprocessor.pkl")) -> pd.DataFrame:
    """
    Transforms new unscaled observations (e.g. from user input in Streamlit)
    using the saved scaler and column metadata.
    """
    artifacts = joblib.load(artifacts_path)
    scaler = artifacts["scaler"]
    feature_cols = artifacts["feature_columns"]
    num_cols = artifacts["numerical_cols"]

    df_out = df_raw.copy()

    # Drop non-feature columns if present
    for col in ['instant', 'casual', 'registered', 'atemp', 'cnt', 'dteday']:
        if col in df_out.columns:
            df_out = df_out.drop(columns=[col])

    # Cyclical encodings
    df_out['hr_sin'] = np.sin(2 * np.pi * df_out['hr'] / 24.0)
    df_out['hr_cos'] = np.cos(2 * np.pi * df_out['hr'] / 24.0)
    df_out['mnth_sin'] = np.sin(2 * np.pi * df_out['mnth'] / 12.0)
    df_out['mnth_cos'] = np.cos(2 * np.pi * df_out['mnth'] / 12.0)
    df_out['weekday_sin'] = np.sin(2 * np.pi * df_out['weekday'] / 7.0)
    df_out['weekday_cos'] = np.cos(2 * np.pi * df_out['weekday'] / 7.0)

    # Domain features
    df_out['is_rush_hour'] = ((df_out['workingday'] == 1) & (df_out['hr'].isin([8, 9, 17, 18, 19]))).astype(int)
    df_out['temp_hum_ratio'] = df_out['temp'] / (df_out['hum'] + 0.05)

    # One-hot encodings
    for s in [2, 3, 4]:
        df_out[f'season_{s}'] = (df_out['season'] == s).astype(int) if 'season' in df_out.columns else 0

    for w in [2, 3, 4]:
        df_out[f'weathersit_{w}'] = (df_out['weathersit'] == w).astype(int) if 'weathersit' in df_out.columns else 0

    cols_to_drop = [c for c in ['season', 'weathersit'] if c in df_out.columns]
    df_out = df_out.drop(columns=cols_to_drop)

    # Ensure all required columns exist with default 0
    for col in feature_cols:
        if col not in df_out.columns:
            df_out[col] = 0

    df_out = df_out[feature_cols]
    df_out[num_cols] = scaler.transform(df_out[num_cols])
    return df_out


def chronological_train_test_split(df: pd.DataFrame, test_ratio: float = 0.20) -> tuple:
    """
    Splits the dataset strictly chronologically:
    - Sorts by date and hour to maintain strict temporal order.
    - First (1 - test_ratio) constitutes the training set.
    - Final (test_ratio) constitutes the test set.
    - Guarantees zero look-ahead bias and zero temporal leakage.
    """
    df_sorted = df.copy()
    if 'dteday' in df_sorted.columns:
        df_sorted['dteday'] = pd.to_datetime(df_sorted['dteday'])
        df_sorted = df_sorted.sort_values(by=['dteday', 'hr']).reset_index(drop=True)

    n_samples = len(df_sorted)
    split_idx = int(n_samples * (1.0 - test_ratio))

    train_df = df_sorted.iloc[:split_idx].copy().reset_index(drop=True)
    test_df = df_sorted.iloc[split_idx:].copy().reset_index(drop=True)

    return train_df, test_df


def plot_cyclical_encoding_visual(output_dir: str = REPORTS_GRAPHS_DIR) -> str:
    """
    Plots the circular 2D mapping of 24 hours in (sin, cos) space to visually
    demonstrate how midnight (00:00) and 23:00 smoothly connect.
    """
    fig, ax = plt.subplots(figsize=(8, 8))
    hours = np.arange(0, 24)
    sin_vals = np.sin(2 * np.pi * hours / 24.0)
    cos_vals = np.cos(2 * np.pi * hours / 24.0)

    # Unit circle
    circle = plt.Circle((0, 0), 1.0, color='gray', fill=False, linestyle='--', alpha=0.5)
    ax.add_patch(circle)

    # Plot points
    scatter = ax.scatter(cos_vals, sin_vals, c=hours, cmap='twilight', s=150, edgecolors='black', zorder=5)

    # Annotate hours
    for h, x, y in zip(hours, cos_vals, sin_vals):
        offset_x = 0.12 * x
        offset_y = 0.12 * y
        ax.text(x + offset_x, y + offset_y, f"{h}:00", ha='center', va='center', fontsize=9, fontweight='bold')

    ax.axhline(0, color='black', linewidth=0.8, linestyle=':')
    ax.axvline(0, color='black', linewidth=0.8, linestyle=':')
    ax.set_xlim(-1.3, 1.3)
    ax.set_ylim(-1.3, 1.3)
    ax.set_aspect('equal')

    ax.set_title("Cyclical Hour Feature Transformation (Sine & Cosine Projection)", fontsize=13, fontweight='bold', pad=15)
    ax.set_xlabel("cos(2π · hr / 24)", fontsize=11, fontweight='bold')
    ax.set_ylabel("sin(2π · hr / 24)", fontsize=11, fontweight='bold')
    fig.colorbar(scatter, ax=ax, label="Hour of Day (0 to 23)", shrink=0.8)

    output_path = os.path.join(output_dir, "11_cyclical_time_encoding.png")
    fig.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.close(fig)
    return output_path


def plot_chronological_split_timeline(train_df: pd.DataFrame, test_df: pd.DataFrame, output_dir: str = REPORTS_GRAPHS_DIR) -> str:
    """
    Plots the daily average bike rental timeline showing the clear chronological separation
    between Training (80%) and Testing (20%) periods.
    """
    fig, ax = plt.subplots(figsize=(13, 6))

    train_daily = train_df.groupby('dteday')['cnt'].mean().reset_index()
    test_daily = test_df.groupby('dteday')['cnt'].mean().reset_index()

    ax.plot(train_daily['dteday'], train_daily['cnt'], label=f"Training Set (80%): {len(train_df):,} hourly samples", color='#1f77b4', linewidth=1.5)
    ax.plot(test_daily['dteday'], test_daily['cnt'], label=f"Testing Set (20%): {len(test_df):,} hourly samples", color='#d62728', linewidth=1.8)

    split_date = test_daily['dteday'].iloc[0]
    ax.axvline(split_date, color='black', linestyle='--', linewidth=2, label=f"Chronological Cutoff: {split_date.strftime('%Y-%m-%d')}")

    ax.set_title("Chronological Train / Test Split Timeline (Jan 2011 to Dec 2012)", fontsize=14, fontweight='bold', pad=12)
    ax.set_xlabel("Observation Date", fontsize=12, fontweight='bold')
    ax.set_ylabel("Daily Mean Rental Count (bikes/hour)", fontsize=12, fontweight='bold')
    ax.grid(True, linestyle='--', alpha=0.6)
    ax.legend(loc='upper left', frameon=True, fontsize=10)

    output_path = os.path.join(output_dir, "12_chronological_split_timeline.png")
    fig.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.close(fig)
    return output_path


def plot_rush_hour_impact(df: pd.DataFrame, output_dir: str = REPORTS_GRAPHS_DIR) -> str:
    """
    Plots bike demand comparison between rush hour and regular hours on working days vs weekends.
    """
    fig, ax = plt.subplots(figsize=(10, 6))
    df_copy = df.copy()
    df_copy['is_rush_hour'] = ((df_copy['workingday'] == 1) & (df_copy['hr'].isin([8, 9, 17, 18, 19]))).map(
        {1: 'Peak Commute Rush Hour', 0: 'Non-Rush Hour'}
    )

    sns.barplot(
        data=df_copy, x='is_rush_hour', y='cnt', hue='yr',
        palette='magma', errorbar=None, ax=ax
    )

    ax.set_title("Impact of Engineered Rush Hour Feature on Rental Demand", fontsize=14, fontweight='bold', pad=12)
    ax.set_xlabel("Time Period Classification", fontsize=12, fontweight='bold')
    ax.set_ylabel("Average Hourly Rentals (cnt)", fontsize=12, fontweight='bold')
    ax.legend(labels=['Year 2011', 'Year 2012'], title="Calendar Year", frameon=True)
    ax.grid(True, linestyle='--', alpha=0.6)

    output_path = os.path.join(output_dir, "13_engineered_rush_hour_impact.png")
    fig.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.close(fig)
    return output_path


def run_feature_engineering_pipeline():
    """
    Orchestrates the entire feature engineering, splitting, scaling, and saving workflow.
    """
    print("\n" + "=" * 80)
    print("        STARTING FEATURE ENGINEERING & CHRONOLOGICAL DATA SPLIT")
    print("=" * 80)

    # 1. Load Cleaned Dataset
    print(f"Loading cleaned dataset from: {CLEANED_DATA_PATH}")
    df = pd.read_csv(CLEANED_DATA_PATH)
    df['dteday'] = pd.to_datetime(df['dteday'])
    print(f"Initial Cleaned Data: {df.shape[0]} rows, {df.shape[1]} columns")

    # 2. Chronological Split (80% Train, 20% Test)
    train_df, test_df = chronological_train_test_split(df, test_ratio=0.20)
    print(f"\nChronological Split:")
    print(f"  • Train Set : {len(train_df):,} rows ({train_df['dteday'].min().strftime('%Y-%m-%d')} to {train_df['dteday'].max().strftime('%Y-%m-%d')})")
    print(f"  • Test Set  : {len(test_df):,} rows ({test_df['dteday'].min().strftime('%Y-%m-%d')} to {test_df['dteday'].max().strftime('%Y-%m-%d')})")

    # 3. Separate Features (X) and Target (y)
    y_train = train_df['cnt'].copy()
    y_test = test_df['cnt'].copy()
    X_train_raw = train_df.drop(columns=['cnt']).copy()
    X_test_raw = test_df.drop(columns=['cnt']).copy()

    # 4. Fit Feature Engineer on Train, Transform Both
    engineer = BikeRentalFeatureEngineer()
    print("\nApplying Feature Transformations & Scaling (Fitted solely on Training Data)...")
    X_train_processed = engineer.fit_transform(X_train_raw)
    X_test_processed = engineer.transform(X_test_raw)

    print(f"Engineered Features Count: {len(engineer.feature_columns)}")
    print(f"Feature Columns: {engineer.feature_columns}")

    # 5. Save Processed Datasets
    print("\nSaving Processed Datasets to 'dataset/processed/'...")
    X_train_path = os.path.join(PROCESSED_DIR, "X_train.csv")
    X_test_path = os.path.join(PROCESSED_DIR, "X_test.csv")
    y_train_path = os.path.join(PROCESSED_DIR, "y_train.csv")
    y_test_path = os.path.join(PROCESSED_DIR, "y_test.csv")

    X_train_processed.to_csv(X_train_path, index=False)
    X_test_processed.to_csv(X_test_path, index=False)
    y_train.to_csv(y_train_path, index=False)
    y_test.to_csv(y_test_path, index=False)

    print(f"  • Saved X_train : {X_train_processed.shape} -> {X_train_path}")
    print(f"  • Saved X_test  : {X_test_processed.shape} -> {X_test_path}")
    print(f"  • Saved y_train : {y_train.shape} -> {y_train_path}")
    print(f"  • Saved y_test  : {y_test.shape} -> {y_test_path}")

    # 6. Save Pipeline & Metadata
    pipeline_path = os.path.join(MODELS_DIR, "preprocessor.pkl")
    preprocessor_artifacts = {
        "scaler": engineer.scaler,
        "feature_columns": engineer.feature_columns,
        "numerical_cols": engineer.numerical_cols,
        "train_samples": len(X_train_processed),
        "test_samples": len(X_test_processed)
    }
    joblib.dump(preprocessor_artifacts, pipeline_path)
    print(f"  • Saved Preprocessor Artifacts: {pipeline_path}")

    meta_path = os.path.join(RESULTS_DIR, "feature_metadata.json")
    with open(meta_path, "w") as f:
        json.dump({
            "feature_columns": engineer.feature_columns,
            "num_features": len(engineer.feature_columns),
            "train_samples": len(X_train_processed),
            "test_samples": len(X_test_processed),
            "train_start_date": train_df['dteday'].min().strftime('%Y-%m-%d'),
            "train_end_date": train_df['dteday'].max().strftime('%Y-%m-%d'),
            "test_start_date": test_df['dteday'].min().strftime('%Y-%m-%d'),
            "test_end_date": test_df['dteday'].max().strftime('%Y-%m-%d')
        }, f, indent=4)
    print(f"  • Saved Feature Metadata: {meta_path}")

    # 7. Generate Supporting Feature Visualizations
    print("\nGenerating Feature Engineering Visualizations...")
    p1 = plot_cyclical_encoding_visual(REPORTS_GRAPHS_DIR)
    p2 = plot_chronological_split_timeline(train_df, test_df, REPORTS_GRAPHS_DIR)
    p3 = plot_rush_hour_impact(df, REPORTS_GRAPHS_DIR)
    print(f"  [11/13] Generated: {p1}")
    print(f"  [12/13] Generated: {p2}")
    print(f"  [13/13] Generated: {p3}")

    print("\n" + "=" * 80)
    print("          FEATURE ENGINEERING COMPLETED SUCCESSFULLY!")
    print("=" * 80)


if __name__ == "__main__":
    run_feature_engineering_pipeline()
