# Bike Rental Demand Prediction Using Machine Learning

**Academic Project:** Final Year BCA Major Project  
**Institution:** Amrita Vishwa Vidyapeetham  
**Technology Stack:** Python, Pandas, NumPy, Scikit-learn, Matplotlib, Seaborn, Streamlit  
**Dataset:** UCI Machine Learning Repository — Bike Sharing Dataset (`hour.csv`)

---

## 📌 Project Overview
Bike-sharing systems provide an automated means of renting bicycles across urban networks. Forecasting demand is essential for fleet rebalancing, dock capacity management, and operational efficiency. This system implements end-to-end predictive analytics using historical calendar and meteorological data from the Capital Bikeshare system (Washington D.C.).

---

## 🏗️ Repository Architecture
```text
Bike_Rental_Prediction/
│
├── dataset/
│   ├── hour.csv                          # Raw UCI hourly dataset (17,379 rows, 17 cols)
│   ├── cleaned_data.csv                  # Cleaned data without leakage (14 cols)
│   └── processed/                        # Chronologically split & scaled feature sets
│       ├── X_train.csv (13,903 rows, 23 cols)
│       ├── X_test.csv  (3,476 rows, 23 cols)
│       ├── y_train.csv
│       └── y_test.csv
│
├── notebooks/
│   └── exploratory_data_analysis.ipynb   # Interactive analysis & viva sandbox
│
├── src/
│   ├── __init__.py                       # Package initializer
│   ├── data_preprocessing.py             # Data ingestion, audit, leakage removal
│   ├── eda.py                            # Statistical summaries & correlation
│   ├── visualization.py                  # High-resolution plotting functions
│   ├── feature_engineering.py            # Cyclical encoding, scaling, chronological split
│   ├── train_model.py                    # Training Linear Regression & Random Forest
│   ├── evaluate_model.py                 # Benchmarking (MAE, RMSE, R2) & diagnostics
│   └── predict.py                        # Reusable inference engine for real-time predictions
│
├── models/
│   ├── linear_regression.pkl             # Serialized Baseline Linear Regression model
│   ├── random_forest.pkl                 # Serialized Champion Random Forest model
│   ├── random_forest_regressor.pkl       # Full named model binary
│   └── preprocessor.pkl                  # Serialized scaler and feature metadata
│
├── reports/
│   ├── graphs/                           # 13 high-resolution diagnostic charts (300 DPI)
│   └── model_results/                    # Metric tables, JSON summaries, feature importance
│
├── app.py                                # Full-featured Streamlit Web Dashboard
├── run_app.bat                           # 1-Click Windows execution script
├── requirements.txt                      # Project dependency specification
├── README.md                             # Academic project documentation
└── .gitignore                            # Version control rules
```

---

## 📊 Experimental Results (Chronological Unseen Test Set)

Evaluated on unseen future timestamps (3,476 records from August to December 2012):

| Metric | Linear Regression (Baseline) | Random Forest Regressor (Champion) | Improvement |
| :--- | :---: | :---: | :---: |
| **Mean Absolute Error (MAE)** | 102.36 bikes/hr | **65.73 bikes/hr** | **35.8% Reduction** |
| **Root Mean Squared Error (RMSE)** | 135.70 bikes/hr | **96.75 bikes/hr** | **28.7% Reduction** |
| **Coefficient of Determination ($R^2$)** | 0.6212 (62.1%) | **0.8075 (80.8%)** | **+18.63% Variance Gain** |

---

## 🚀 How to Run the Project

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Run Individual Modules (Optional)
```bash
# Run data preprocessing:
python src/data_preprocessing.py

# Run Exploratory Data Analysis (generates charts in reports/graphs/):
python src/eda.py

# Run Feature Engineering:
python src/feature_engineering.py

# Train both models:
python src/train_model.py

# Run evaluation & generate comparison charts:
python src/evaluate_model.py
```

### 3. Launch the Streamlit Web Dashboard
```bash
streamlit run app.py
```
*Or simply double-click the included `run_app.bat` script on Windows.*

The web dashboard will automatically open in your default browser at `http://localhost:8501`.

---

## 🖥️ Streamlit Web Application Features

1. **🏠 Home Page:** Problem statement, research motivation, objectives, and quick facts.
2. **🔮 Predict Demand:** Interactive sliders for season, hour, day, weather, temperature, humidity, and wind speed. Generates instant predictions using the trained models with qualitative demand status badges.
3. **📊 Model Comparison:** Side-by-side metric cards, comparison bar charts, actual vs. predicted scatter plots, residual diagnostics, and feature importance rankings.
4. **📈 Data Visualizations:** Categorized tabs for inspecting hourly commute rhythms, seasonal trends, weather sensitivity, and cyclical encoding geometry.
5. **ℹ️ About Project:** Academic dissertation details, dataset attribution, algorithm breakdown, and future research directions.
