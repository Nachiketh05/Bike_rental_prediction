"""
Script: test_system_pipeline.py
Description:
    Comprehensive verification and test suite for the Bike Rental Demand Prediction project.
    Executes and asserts all 15 audit checkpoints:
    1. Dataset loading & integrity
    2. Data preprocessing & leakage prevention
    3. Missing value handling
    4. Exploratory Data Analysis & correlations
    5. Feature engineering & cyclical transformations
    6. Chronological train/test split verification
    7. Linear Regression training & evaluation
    8. Random Forest training & evaluation
    9. Evaluation metrics benchmarking (MAE, RMSE, R2)
    10. Model persistence & deserialization
    11. Streamlit inference engine
    12. Input validation & non-negativity constraints
    13. Prediction outputs across multiple scenarios
    14. Model comparison metrics
    15. Graph and visual diagnostic assets
"""

import os
import sys
import json
import joblib
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, root_mean_squared_error, r2_score

# Ensure root directory is in sys.path
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from src.data_preprocessing import (
    load_raw_data,
    preprocess_data,
    handle_missing_values,
    RAW_DATA_PATH,
    CLEANED_DATA_PATH
)
from src.feature_engineering import (
    chronological_train_test_split,
    transform_new_samples,
    PROCESSED_DIR,
    MODELS_DIR,
    REPORTS_GRAPHS_DIR,
    RESULTS_DIR
)
from src.predict import predict_bike_demand, load_model


def log_test(name: str, passed: bool, details: str = ""):
    status = "PASS" if passed else "FAIL"
    symbol = "[OK]" if passed else "[FAIL]"
    print(f"  {symbol} {name:<45} : {status} {details}")
    if not passed:
        raise AssertionError(f"Test Failed: {name} - {details}")


def run_comprehensive_tests():
    print("\n" + "=" * 80)
    print("      COMPREHENSIVE AUDIT & TESTING: BIKE RENTAL PREDICTION SYSTEM")
    print("=" * 80)

    # -------------------------------------------------------------
    # 1. Dataset Loading & Integrity
    # -------------------------------------------------------------
    print("\n[Phase 1] Auditing Dataset Loading & Raw Integrity...")
    df_raw = load_raw_data(RAW_DATA_PATH)
    log_test("Raw Dataset Exists & Loaded", df_raw is not None and len(df_raw) > 0, f"({len(df_raw):,} rows)")
    log_test("Expected Row Count (17,379)", len(df_raw) == 17379, f"(Found: {len(df_raw)})")
    log_test("Expected Column Count (17)", df_raw.shape[1] == 17, f"(Found: {df_raw.shape[1]})")
    log_test("Target Variable 'cnt' Present", "cnt" in df_raw.columns, f"(Min: {df_raw['cnt'].min()}, Max: {df_raw['cnt'].max()})")

    # -------------------------------------------------------------
    # 2. Data Preprocessing & Data Leakage Prevention
    # -------------------------------------------------------------
    print("\n[Phase 2] Auditing Data Preprocessing & Leakage Elimination...")
    cleaned_df, before_stats, after_stats = preprocess_data(RAW_DATA_PATH, CLEANED_DATA_PATH)
    log_test("Cleaned Dataset Produced", os.path.exists(CLEANED_DATA_PATH), f"({CLEANED_DATA_PATH})")
    log_test("Target Leakage 'casual' Removed", "casual" not in cleaned_df.columns)
    log_test("Target Leakage 'registered' Removed", "registered" not in cleaned_df.columns)
    log_test("Serial Index 'instant' Removed", "instant" not in cleaned_df.columns)
    log_test("Cleaned Column Count is 14", cleaned_df.shape[1] == 14, f"(Found: {cleaned_df.shape[1]})")
    log_test("Cleaned Missing Values is 0", cleaned_df.isnull().sum().sum() == 0)
    log_test("Cleaned Duplicate Records is 0", cleaned_df.duplicated().sum() == 0)

    # -------------------------------------------------------------
    # 3. Missing Value Imputation Fallback Test
    # -------------------------------------------------------------
    print("\n[Phase 3] Testing Missing Value Handling Mechanism...")
    test_df_with_nans = cleaned_df.head(50).copy()
    test_df_with_nans.loc[0, 'temp'] = np.nan
    test_df_with_nans.loc[1, 'hum'] = np.nan
    imputed_df = handle_missing_values(test_df_with_nans)
    log_test("Automated Imputation on Synthetic NaNs", imputed_df.isnull().sum().sum() == 0)

    # -------------------------------------------------------------
    # 4. Exploratory Data Analysis & Statistics
    # -------------------------------------------------------------
    print("\n[Phase 4] Auditing Statistical Summary & Correlation Tables...")
    corr_csv = os.path.join(RESULTS_DIR, "correlation_matrix.csv")
    stats_csv = os.path.join(RESULTS_DIR, "eda_statistical_summary.csv")
    log_test("Correlation Matrix CSV Generated", os.path.exists(corr_csv))
    log_test("EDA Statistical Summary CSV Generated", os.path.exists(stats_csv))
    
    corr_df = pd.read_csv(corr_csv, index_col=0)
    temp_atemp_corr = corr_df.loc['temp', 'atemp']
    log_test("Collinearity temp vs atemp Verified", temp_atemp_corr > 0.98, f"(r = {temp_atemp_corr:.4f})")

    # -------------------------------------------------------------
    # 5. Chronological Train/Test Split
    # -------------------------------------------------------------
    print("\n[Phase 5] Auditing Chronological 80/20 Train/Test Split...")
    train_df, test_df = chronological_train_test_split(cleaned_df, test_ratio=0.20)
    log_test("Train Set Size is 80% (13,903)", len(train_df) == 13903, f"(Found: {len(train_df):,})")
    log_test("Test Set Size is 20% (3,476)", len(test_df) == 3476, f"(Found: {len(test_df):,})")
    train_max_date = train_df['dteday'].max()
    test_min_date = test_df['dteday'].min()
    log_test("Strict Chronological Order (Zero Lookahead)", train_max_date <= test_min_date, 
             f"(Train End: {train_max_date.strftime('%Y-%m-%d')}, Test Start: {test_min_date.strftime('%Y-%m-%d')})")

    # -------------------------------------------------------------
    # 6. Feature Engineering & Preprocessing Pipeline Consistency
    # -------------------------------------------------------------
    print("\n[Phase 6] Auditing Feature Engineering & Transformation Consistency...")
    x_tr = pd.read_csv(os.path.join(PROCESSED_DIR, "X_train.csv"))
    x_te = pd.read_csv(os.path.join(PROCESSED_DIR, "X_test.csv"))
    pipe_path = os.path.join(MODELS_DIR, "preprocessor.pkl")
    
    log_test("X_train Shape Verified", x_tr.shape == (13903, 23), f"(Shape: {x_tr.shape})")
    log_test("X_test Shape Verified", x_te.shape == (3476, 23), f"(Shape: {x_te.shape})")
    log_test("Fitted Preprocessor Pipeline Serialized", os.path.exists(pipe_path))
    
    # Verify Cyclical Identity: sin^2 + cos^2 = 1.0
    hr_trig_sum = np.round(x_tr['hr_sin']**2 + x_tr['hr_cos']**2, 5)
    log_test("Hour Cyclical Encoding Identity (sin² + cos² = 1)", np.all(hr_trig_sum == 1.0))
    
    # Verify Inference Pipeline matches Training Schema
    sample_input = pd.DataFrame([{
        "season": 2, "yr": 1, "mnth": 6, "hr": 18, "holiday": 0, "weekday": 2,
        "workingday": 1, "weathersit": 1, "temp": 0.6, "hum": 0.5, "windspeed": 0.2
    }])
    transformed_sample = transform_new_samples(sample_input)
    log_test("Inference Transformation Matches Training Schema", 
             list(transformed_sample.columns) == list(x_tr.columns), f"({len(transformed_sample.columns)} columns)")

    # -------------------------------------------------------------
    # 7. Model Training & Deserialization
    # -------------------------------------------------------------
    print("\n[Phase 7] Auditing Trained Models Deserialization...")
    lr_model = load_model("Linear Regression")
    rf_model = load_model("Random Forest Regressor")
    log_test("Linear Regression Model Loaded", isinstance(lr_model, LinearRegression))
    log_test("Random Forest Regressor Model Loaded", isinstance(rf_model, RandomForestRegressor))

    # -------------------------------------------------------------
    # 8. Model Evaluation & Benchmark Verification
    # -------------------------------------------------------------
    print("\n[Phase 8] Auditing Evaluation Metrics Benchmarking...")
    y_test = pd.read_csv(os.path.join(PROCESSED_DIR, "y_test.csv")).squeeze("columns")
    
    lr_preds = np.clip(lr_model.predict(x_te), 0, None)
    rf_preds = np.clip(rf_model.predict(x_te), 0, None)

    lr_mae = round(mean_absolute_error(y_test, lr_preds), 2)
    lr_rmse = round(root_mean_squared_error(y_test, lr_preds), 2)
    lr_r2 = round(r2_score(y_test, lr_preds), 4)

    rf_mae = round(mean_absolute_error(y_test, rf_preds), 2)
    rf_rmse = round(root_mean_squared_error(y_test, rf_preds), 2)
    rf_r2 = round(r2_score(y_test, rf_preds), 4)

    print(f"    • Linear Regression : MAE = {lr_mae}, RMSE = {lr_rmse}, R² = {lr_r2}")
    print(f"    • Random Forest     : MAE = {rf_mae}, RMSE = {rf_rmse}, R² = {rf_r2}")

    log_test("Random Forest R² > 0.80", rf_r2 >= 0.80, f"(Actual R²: {rf_r2})")
    log_test("Random Forest R² Superior to Linear Regression", rf_r2 > lr_r2, f"({rf_r2} > {lr_r2})")
    log_test("Random Forest MAE Superior to Linear Regression", rf_mae < lr_mae, f"({rf_mae} < {lr_mae})")
    log_test("Random Forest RMSE Superior to Linear Regression", rf_rmse < lr_rmse, f"({rf_rmse} < {lr_rmse})")

    # -------------------------------------------------------------
    # 9. Multiple User Input Scenarios & Edge Cases
    # -------------------------------------------------------------
    print("\n[Phase 9] Testing Inference Engine with Real-World Scenarios...")

    # Scenario 1: Peak Commute Rush Hour (Clear Autumn Thursday)
    s1 = {"season": 3, "yr": 1, "mnth": 9, "hr": 17, "holiday": 0, "weekday": 4, 
          "workingday": 1, "weathersit": 1, "temp": 0.65, "hum": 0.45, "windspeed": 0.15}
    res1 = predict_bike_demand(s1, "Random Forest Regressor")
    log_test("Scenario 1 (Rush Hour Commute): High Demand", 
             res1["prediction_rounded"] > 400, f"({res1['prediction_rounded']} bikes/hr - {res1['demand_category']})")

    # Scenario 2: Freezing Winter Night (Off-Peak)
    s2 = {"season": 1, "yr": 1, "mnth": 1, "hr": 3, "holiday": 0, "weekday": 2, 
          "workingday": 1, "weathersit": 2, "temp": 0.05, "hum": 0.85, "windspeed": 0.35}
    res2 = predict_bike_demand(s2, "Random Forest Regressor")
    log_test("Scenario 2 (Freezing Winter Night): Low Demand", 
             res2["prediction_rounded"] < 50, f"({res2['prediction_rounded']} bikes/hr - {res2['demand_category']})")

    # Scenario 3: Sunny Weekend Afternoon (Leisure Ridership)
    s3 = {"season": 2, "yr": 1, "mnth": 6, "hr": 14, "holiday": 0, "weekday": 6, 
          "workingday": 0, "weathersit": 1, "temp": 0.70, "hum": 0.40, "windspeed": 0.18}
    res3 = predict_bike_demand(s3, "Random Forest Regressor")
    log_test("Scenario 3 (Weekend Leisure): Moderate-High Demand", 
             res3["prediction_rounded"] >= 200, f"({res3['prediction_rounded']} bikes/hr - {res3['demand_category']})")

    # Scenario 4: Adverse Weather / Thunderstorm
    s4 = {"season": 3, "yr": 1, "mnth": 9, "hr": 17, "holiday": 0, "weekday": 4, 
          "workingday": 1, "weathersit": 4, "temp": 0.50, "hum": 0.95, "windspeed": 0.55}
    res4 = predict_bike_demand(s4, "Random Forest Regressor")
    log_test("Scenario 4 (Adverse Weather Suppression vs Scenario 1)", 
             res4["prediction_rounded"] < res1["prediction_rounded"], 
             f"({res4['prediction_rounded']} vs {res1['prediction_rounded']} bikes/hr)")

    # Scenario 5: Non-Negativity Guarantee
    log_test("Scenario 5 (Non-Negativity Constraint Enforced)", 
             res1["prediction_rounded"] >= 0 and res2["prediction_rounded"] >= 0)

    # -------------------------------------------------------------
    # 10. Audit of All Generated Diagnostic Plots
    # -------------------------------------------------------------
    print("\n[Phase 10] Auditing Visual Plot Assets (High-Res 300 DPI)...")
    expected_graphs = [
        os.path.join(REPORTS_GRAPHS_DIR, "01_target_distribution.png"),
        os.path.join(REPORTS_GRAPHS_DIR, "02_hourly_rentals.png"),
        os.path.join(REPORTS_GRAPHS_DIR, "03_seasonal_rentals.png"),
        os.path.join(REPORTS_GRAPHS_DIR, "04_monthly_rentals.png"),
        os.path.join(REPORTS_GRAPHS_DIR, "05_weekday_rentals.png"),
        os.path.join(REPORTS_GRAPHS_DIR, "06_workingday_vs_holiday.png"),
        os.path.join(REPORTS_GRAPHS_DIR, "07_temperature_vs_rentals.png"),
        os.path.join(REPORTS_GRAPHS_DIR, "08_humidity_vs_rentals.png"),
        os.path.join(REPORTS_GRAPHS_DIR, "09_windspeed_vs_rentals.png"),
        os.path.join(REPORTS_GRAPHS_DIR, "10_correlation_heatmap.png"),
        os.path.join(REPORTS_GRAPHS_DIR, "11_cyclical_time_encoding.png"),
        os.path.join(REPORTS_GRAPHS_DIR, "12_chronological_split_timeline.png"),
        os.path.join(REPORTS_GRAPHS_DIR, "13_engineered_rush_hour_impact.png"),
        os.path.join(RESULTS_DIR, "model_performance_comparison.png"),
        os.path.join(RESULTS_DIR, "actual_vs_predicted.png"),
        os.path.join(RESULTS_DIR, "residual_plots.png"),
        os.path.join(RESULTS_DIR, "feature_importance.png")
    ]

    for g_path in expected_graphs:
        fname = os.path.basename(g_path)
        exists = os.path.exists(g_path) and os.path.getsize(g_path) > 10000
        log_test(f"Plot Asset: {fname}", exists, f"({os.path.getsize(g_path):,} bytes)")

    print("\n" + "=" * 80)
    print("        ALL SYSTEM CHECKS & TESTS PASSED WITH ZERO ERRORS!")
    print("=" * 80)


if __name__ == "__main__":
    run_comprehensive_tests()
