# -*- coding: utf-8 -*-
"""
Streamlit Web Application: Bike Rental Demand Prediction System
Author: BCA Final Year Student
Institution: Amrita Vishwa Vidyapeetham
Technology Stack: Python, Pandas, NumPy, Scikit-learn, Matplotlib, Seaborn, Streamlit
"""

import os
import sys
import json
import pandas as pd
import numpy as np
import streamlit as st
from PIL import Image

# Ensure root directory is on python path
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from src.predict import predict_bike_demand, load_model
from src.feature_engineering import transform_new_samples, MODELS_DIR

# Set Streamlit Page Configuration
st.set_page_config(
    page_title="CycleCast AI // Next-Gen Autonomous Mobility",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom Styling (Futuristic Cyber-Glassmorphic HUD)
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700;900&family=Rajdhani:wght@500;600;700&display=swap');
    
    .futuristic-title {
        font-family: 'Orbitron', 'Segoe UI', sans-serif;
        font-size: 2.1rem;
        font-weight: 900;
        background: linear-gradient(135deg, #00F0FF 0%, #38BDF8 50%, #818CF8 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        letter-spacing: 1.5px;
        margin-bottom: 0.2rem;
        text-shadow: 0 0 20px rgba(0, 240, 255, 0.35);
    }
    .futuristic-sub {
        font-family: 'Rajdhani', sans-serif;
        font-size: 1.05rem;
        color: #94A3B8;
        font-weight: 600;
        letter-spacing: 1px;
        margin-bottom: 1.5rem;
        text-transform: uppercase;
    }
    .cyber-badge {
        display: inline-block;
        background: rgba(0, 240, 255, 0.12);
        border: 1px solid #00F0FF;
        color: #00F0FF;
        padding: 0.3rem 0.8rem;
        border-radius: 4px;
        font-size: 0.8rem;
        font-family: 'Orbitron', monospace;
        font-weight: 700;
        letter-spacing: 1.2px;
        box-shadow: 0 0 12px rgba(0, 240, 255, 0.3);
        margin-bottom: 0.4rem;
    }
    .hud-card {
        background: linear-gradient(135deg, rgba(15, 23, 42, 0.85) 0%, rgba(30, 41, 59, 0.65) 100%);
        border: 1px solid rgba(0, 240, 255, 0.25);
        border-left: 4px solid #00F0FF;
        border-radius: 12px;
        padding: 1.3rem;
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4), inset 0 0 12px rgba(0, 240, 255, 0.05);
        margin-bottom: 1rem;
        backdrop-filter: blur(10px);
    }
    .hud-prediction {
        background: linear-gradient(135deg, rgba(8, 47, 73, 0.8) 0%, rgba(15, 23, 42, 0.9) 100%);
        border: 2px solid #00F0FF;
        border-radius: 14px;
        padding: 2rem;
        text-align: center;
        box-shadow: 0 0 25px rgba(0, 240, 255, 0.35), inset 0 0 15px rgba(0, 240, 255, 0.1);
        margin-top: 1.5rem;
    }
    .telemetry-num {
        font-family: 'Orbitron', monospace;
        font-size: 2.2rem;
        font-weight: 900;
        color: #00F0FF;
        text-shadow: 0 0 15px rgba(0, 240, 255, 0.5);
        margin: 0;
    }
    .brand-sub {
        color: #64748B;
        font-size: 0.78rem;
        font-family: monospace;
        letter-spacing: 0.5px;
        margin-top: 0.3rem;
    }
    .main-header {
        font-family: 'Orbitron', sans-serif;
        font-size: 2.1rem;
        font-weight: 900;
        background: linear-gradient(135deg, #00F0FF 0%, #38BDF8 50%, #818CF8 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 0.2rem;
    }
    .sub-header {
        font-family: 'Rajdhani', sans-serif;
        font-size: 1.05rem;
        color: #94A3B8;
        letter-spacing: 0.8px;
        margin-bottom: 1.5rem;
    }
    .metric-card {
        background: linear-gradient(135deg, rgba(15, 23, 42, 0.85) 0%, rgba(30, 41, 59, 0.7) 100%);
        border: 1px solid rgba(0, 240, 255, 0.25);
        border-left: 4px solid #00F0FF;
        border-radius: 12px;
        padding: 1.2rem;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
        margin-bottom: 1rem;
    }
    .prediction-box {
        background: linear-gradient(135deg, rgba(14, 116, 144, 0.25) 0%, rgba(15, 23, 42, 0.8) 100%);
        border: 2px solid #00F0FF;
        border-radius: 14px;
        padding: 1.8rem;
        text-align: center;
        margin-top: 1.5rem;
        box-shadow: 0 0 20px rgba(0, 240, 255, 0.3);
    }
</style>
""", unsafe_allow_html=True)

# Path Constants
REPORTS_DIR = os.path.join(BASE_DIR, "reports", "graphs")
RESULTS_DIR = os.path.join(BASE_DIR, "reports", "model_results")


# ---------------------------------------------------------
# Sidebar Branding & Navigation
# ---------------------------------------------------------
st.sidebar.markdown("<div class='cyber-badge'>⚡ QUANTUM SYSTEM ONLINE</div>", unsafe_allow_html=True)
st.sidebar.markdown("<div style='font-family: Orbitron, sans-serif; font-size: 1.35rem; font-weight: 900; color: #FFFFFF;'>CYCLECAST <span style='color: #00F0FF;'>AI</span></div>", unsafe_allow_html=True)
st.sidebar.markdown("<div class='brand-sub'>// AUTONOMOUS MOBILITY FORECASTER v2.5</div>", unsafe_allow_html=True)
st.sidebar.markdown("---")
st.sidebar.markdown("<small style='font-family: monospace; color: #00F0FF; letter-spacing: 1px;'>[SYSTEM TELEMETRY NAV]</small>", unsafe_allow_html=True)

page = st.sidebar.radio(
    "Select System Section:",
    [
        "⚡ [01] Command Hub",
        "🔮 [02] Neural Demand Predictor",
        "📊 [03] Model Benchmarks",
        "📈 [04] Telemetry Visualizations",
        "ℹ️ [05] System Architecture"
    ]
)

st.sidebar.markdown("---")
st.sidebar.info("🛰️ **Dataset Feed:** UCI Machine Learning Repository (17,379 hourly observations across Capital Bikeshare sensor network).")


# =========================================================
# SECTION 1: HOME PAGE (COMMAND HUB)
# =========================================================
if "[01]" in page or "Home" in page:
    st.markdown("<div class='main-header'>⚡ CycleCast AI // Autonomous Mobility Predictor</div>", unsafe_allow_html=True)
    st.markdown("<div class='sub-header'>Next-Generation Predictive Analytics & Cybernetic Urban Fleet Logistics Engine</div>", unsafe_allow_html=True)

    hero_banner = os.path.join(REPORTS_DIR, "ai_futuristic_bike_hub.jpg")
    if os.path.exists(hero_banner):
        st.image(hero_banner, caption="CYBERNETIC MOBILITY GRID // Autonomous Inductive E-Bike Hub & Real-Time Holographic AR Routing [Year 2050]", use_container_width=True)
        st.markdown("<div style='margin-bottom: 1.2rem;'></div>", unsafe_allow_html=True)

    col_h1, col_h2 = st.columns([1.8, 1.2])

    with col_h1:
        st.markdown("""
        ### 🌐 Intelligent Autonomous Mobility Architecture
        In hyper-connected smart metropolises, micro-mobility acts as an organic, self-balancing transportation grid. Autonomous e-bikes and smart stations dynamically exchange sensor telemetry. However, managing fleet capacity presents an intricate logistical optimization problem: **unpredictable commuter surges trigger dock starvation at central sky-transit hubs, while sudden precipitation leaves hundreds of units grounded.**

        **CycleCast AI** deploys non-linear machine learning ensemble algorithms to anticipate volumetric demand 1 to 24 hours in advance, allowing autonomous rebalancing pods and fleet logistics operators to proactively redistribute resources.
        """)

        st.markdown("""
        ### ⚡ The Spatial-Temporal Rebalancing Dilemma
        Urban micro-mobility demand shifts along dynamic vectors:
        - **Commuter Surge Waves:** Bimodal transit spikes during morning and evening rush hours.
        - **Atmospheric Fluctuations:** Real-time suppression vectors driven by precipitation, ambient humidity, and wind chill.
        - **Autonomous Fleet Rebalancing:** Directing heavy-lift transport pods and transit vans ahead of peak saturation.
        """)

    with col_h2:
        st.markdown("### 📡 System Telemetry Telemetrics")
        st.markdown("""
        <div class='hud-card'>
            <small style='color:#94A3B8; font-family: monospace;'>[LOGGED SENSOR RECORDS]</small>
            <p class='telemetry-num'>17,379</p>
            <small style='color:#64748B;'>Two full calendar years of continuous hourly sensor telemetry</small>
        </div>
        <div class='hud-card'>
            <small style='color:#94A3B8; font-family: monospace;'>[CHAMPION ENSEMBLE R²]</small>
            <p class='telemetry-num' style='color:#10B981;'>80.75%</p>
            <small style='color:#64748B;'>Random Forest Regressor (65.73 Test MAE units/hr)</small>
        </div>
        <div class='hud-card'>
            <small style='color:#94A3B8; font-family: monospace;'>[BASELINE OLS R²]</small>
            <p class='telemetry-num' style='color:#38BDF8;'>62.12%</p>
            <small style='color:#64748B;'>Linear Regression Baseline (102.36 Test MAE)</small>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("---")
    st.markdown("### Project Objectives")
    col_o1, col_o2, col_o3 = st.columns(3)
    with col_o1:
        st.markdown("""
        **1. Robust Data Processing**
        - Ingest raw UCI `hour.csv` data.
        - Eliminate target leakage (`casual`, `registered`).
        - Treat extreme multicollinearity (`temp` vs `atemp`).
        """)
    with col_o2:
        st.markdown("""
        **2. Machine Learning Modeling**
        - Implement baseline Linear Regression.
        - Build an optimized Random Forest Regressor.
        - Strict chronological 80/20 train/test evaluation.
        """)
    with col_o3:
        st.markdown("""
        **3. Interactive Deployment**
        - Real-time prediction dashboard.
        - Scenario simulation under changing weather.
        - Transparent academic model benchmarking.
        """)


# =========================================================
# SECTION 2: PREDICTION PAGE
# =========================================================
elif "[02]" in page or "Predict" in page:
    st.markdown("<div class='main-header'>🔮 Neural Demand Predictor Engine</div>", unsafe_allow_html=True)
    st.markdown("<div class='sub-header'>Configure environmental vectors and temporal coordinates below to simulate expected hourly demand.</div>", unsafe_allow_html=True)

    # Model Selection Bar
    col_sel1, col_sel2 = st.columns([2, 1])
    with col_sel1:
        selected_model_name = st.selectbox(
            "Select Machine Learning Estimator:",
            ["Random Forest Regressor (Recommended - 80.8% R²)", "Linear Regression (Baseline - 62.1% R²)"]
        )
    with col_sel2:
        st.write("")
        st.write("")
        model_key = "Random Forest Regressor" if "Random Forest" in selected_model_name else "Linear Regression"
        st.caption(f"Using estimator: **{model_key}**")

    st.markdown("---")

    weather_img = os.path.join(REPORTS_DIR, "ai_futuristic_cyber_mobility.jpg")
    if os.path.exists(weather_img):
        with st.expander("🛰️ View Real-Time Cyber-Mobility Telemetry & Transit Corridors", expanded=True):
            st.image(weather_img, caption="AI CYBER-MOBILITY TELEMETRY // Heavy-Lift Rebalancing Drones & Augmented-Reality Commuter HUD", use_container_width=True)

    # Form with input parameters
    col_input1, col_input2 = st.columns(2)

    with col_input1:
        st.subheader("📅 Temporal & Calendar Inputs")
        
        season_label = st.selectbox("Season:", ["1: Spring", "2: Summer", "3: Fall", "4: Winter"], index=2)
        season_val = int(season_label.split(":")[0])

        year_label = st.selectbox("Year:", ["2011 (Year 0 - Baseline Adoption)", "2012 (Year 1 - High Adoption)"], index=1)
        yr_val = 0 if "2011" in year_label else 1

        month_label = st.selectbox(
            "Month:",
            ["1: January", "2: February", "3: March", "4: April", "5: May", "6: June",
             "7: July", "8: August", "9: September", "10: October", "11: November", "12: December"],
            index=8
        )
        mnth_val = int(month_label.split(":")[0])

        hr_val = st.slider("Hour of the Day (0:00 to 23:00):", min_value=0, max_value=23, value=17, step=1,
                           help="Rush hours typically occur at 8-9 AM and 5-6 PM on working days.")
        
        weekday_label = st.selectbox(
            "Day of Week:",
            ["0: Sunday", "1: Monday", "2: Tuesday", "3: Wednesday", "4: Thursday", "5: Friday", "6: Saturday"],
            index=4
        )
        weekday_val = int(weekday_label.split(":")[0])

        col_flag1, col_flag2 = st.columns(2)
        with col_flag1:
            workingday_val = st.radio("Is it a Working Day?", [1, 0], format_func=lambda x: "Yes (Weekday)" if x == 1 else "No (Weekend / Holiday)", index=0)
        with col_flag2:
            holiday_val = st.radio("Is it a Public Holiday?", [0, 1], format_func=lambda x: "No" if x == 0 else "Yes", index=0)

    with col_input2:
        st.subheader("🌤️ Weather & Environmental Inputs")

        weather_label = st.selectbox(
            "Weather Condition:",
            [
                "1: Clear / Few Clouds / Partly Cloudy",
                "2: Mist + Cloudy / Broken Clouds",
                "3: Light Snow / Light Rain + Thunderstorm",
                "4: Heavy Rain + Ice Pellets / Fog"
            ],
            index=0
        )
        weathersit_val = int(weather_label.split(":")[0])

        temp_celsius = st.slider("Temperature (°C):", min_value=0.0, max_value=41.0, value=26.0, step=0.5,
                                 help="Normalized temp = Celsius / 41")
        temp_val = temp_celsius / 41.0

        atemp_celsius = st.slider("Feeling Temperature / Feels Like (°C):", min_value=0.0, max_value=50.0, value=28.0, step=0.5,
                                  help="Normalized atemp = Celsius / 50 (Collinear feature excluded from regression)")
        atemp_val = atemp_celsius / 50.0

        humidity_pct = st.slider("Relative Humidity (%):", min_value=0, max_value=100, value=50, step=1,
                                 help="Normalized humidity = % / 100")
        hum_val = humidity_pct / 100.0

        windspeed_kmh = st.slider("Wind Speed (km/h):", min_value=0.0, max_value=67.0, value=12.0, step=1.0,
                                  help="Normalized windspeed = km/h / 67")
        windspeed_val = windspeed_kmh / 67.0

    st.markdown("---")

    # Predict Button
    btn_predict = st.button("🚀 Predict Bike Rentals", use_container_width=True, type="primary")

    if btn_predict:
        try:
            input_dict = {
                "season": season_val,
                "yr": yr_val,
                "mnth": mnth_val,
                "hr": hr_val,
                "holiday": holiday_val,
                "weekday": weekday_val,
                "workingday": workingday_val,
                "weathersit": weathersit_val,
                "temp": temp_val,
                "atemp": atemp_val,
                "hum": hum_val,
                "windspeed": windspeed_val
            }

            # Run prediction through inference engine
            result = predict_bike_demand(input_dict, model_name=model_key)
            other_model_key = "Linear Regression" if model_key == "Random Forest Regressor" else "Random Forest Regressor"
            other_result = predict_bike_demand(input_dict, model_name=other_model_key)

            pred_round = result['prediction_rounded']
            pred_raw = result['prediction_raw']
            badge_bg = result['badge_color']
            demand_cat = result['demand_category']
            model_used = result['model_used']

            st.markdown(f"""
            <div class='hud-prediction'>
                <h3 style='margin:0; color:#00F0FF; font-family: Orbitron, sans-serif; letter-spacing: 1px;'>[QUANTUM DEMAND FORECAST]</h3>
                <div style='font-family: Orbitron, monospace; font-size: 3.8rem; font-weight: 900; color: #00F0FF; margin: 0.5rem 0; text-shadow: 0 0 25px rgba(0,240,255,0.6);'>
                    {pred_round} <span style='font-size: 1.4rem; font-weight: 600; color: #94A3B8;'>UNITS / HR</span>
                </div>
                <div>
                    <span class='cyber-badge' style='background-color: {badge_bg}; font-size:1.05rem; padding: 0.4rem 1.2rem; color: #FFFFFF;'>
                        [STATUS] {demand_cat}
                    </span>
                </div>
                <p style='color: #94A3B8; margin-top: 1rem; font-size: 0.95rem; font-family: monospace;'>
                    SYNTHESIZED VIA <b>{model_used}</b> (Raw: {pred_raw} units)
                </p>
            </div>
            """, unsafe_allow_html=True)

            # Comparative Insight Box
            st.write("")
            col_comp1, col_comp2 = st.columns(2)
            with col_comp1:
                st.info(f"📊 **Alternative Model Comparison:**  \nUnder the identical conditions, **{other_model_key}** predicts: **{other_result['prediction_rounded']} bikes/hour** ({other_result['demand_category']}).")
            with col_comp2:
                # Operational recommendation
                if result['prediction_rounded'] >= 500:
                    st.warning("⚠️ **Fleet Rebalancing Alert:** Peak rush hour surge detected! Pre-position mobile bike trailers and ensure dock clearance at destination transit stations.")
                elif result['prediction_rounded'] >= 250:
                    st.success("✅ **Fleet Status Normal:** High demand expected. Normal rotation cycles will comfortably service rider volume.")
                else:
                    st.info("ℹ️ **Off-Peak Notice:** Low-to-moderate demand expected. Optimal window for fleet inspection and battery/hardware maintenance.")

        except Exception as e:
            st.error(f"❌ Error during prediction execution: {str(e)}")


# =========================================================
# SECTION 3: MODEL COMPARISON PAGE
# =========================================================
elif "[03]" in page or "Model Comparison" in page:
    st.markdown("<div class='main-header'>📊 Machine Learning Model Benchmarking</div>", unsafe_allow_html=True)
    st.markdown("<div class='sub-header'>Rigorous comparison between Baseline Linear Regression and Ensemble Random Forest Regressor on unseen test data.</div>", unsafe_allow_html=True)

    # Metric Cards Row
    col_m1, col_m2, col_m3 = st.columns(3)
    with col_m1:
        st.markdown("""
        <div class='metric-card'>
            <h4 style='margin:0; color:#4B5563;'>Mean Absolute Error (MAE)</h4>
            <div style='display:flex; justify-content:space-between; align-items:baseline; margin-top:0.5rem;'>
                <div>
                    <small style='color:#6B7280;'>Random Forest</small>
                    <p style='font-size:1.8rem; font-weight:800; color:#16A34A; margin:0;'>65.73</p>
                </div>
                <div>
                    <small style='color:#6B7280;'>Linear Regression</small>
                    <p style='font-size:1.4rem; font-weight:700; color:#DC2626; margin:0;'>102.36</p>
                </div>
            </div>
            <small style='color:#16A34A; font-weight:700;'>↓ 35.8% Lower Error</small>
        </div>
        """, unsafe_allow_html=True)

    with col_m2:
        st.markdown("""
        <div class='metric-card'>
            <h4 style='margin:0; color:#4B5563;'>Root Mean Squared Error (RMSE)</h4>
            <div style='display:flex; justify-content:space-between; align-items:baseline; margin-top:0.5rem;'>
                <div>
                    <small style='color:#6B7280;'>Random Forest</small>
                    <p style='font-size:1.8rem; font-weight:800; color:#16A34A; margin:0;'>96.75</p>
                </div>
                <div>
                    <small style='color:#6B7280;'>Linear Regression</small>
                    <p style='font-size:1.4rem; font-weight:700; color:#DC2626; margin:0;'>135.70</p>
                </div>
            </div>
            <small style='color:#16A34A; font-weight:700;'>↓ 28.7% Lower Outlier Penalty</small>
        </div>
        """, unsafe_allow_html=True)

    with col_m3:
        st.markdown("""
        <div class='metric-card'>
            <h4 style='margin:0; color:#4B5563;'>Coefficient of Determination (R²)</h4>
            <div style='display:flex; justify-content:space-between; align-items:baseline; margin-top:0.5rem;'>
                <div>
                    <small style='color:#6B7280;'>Random Forest</small>
                    <p style='font-size:1.8rem; font-weight:800; color:#16A34A; margin:0;'>0.8075</p>
                </div>
                <div>
                    <small style='color:#6B7280;'>Linear Regression</small>
                    <p style='font-size:1.4rem; font-weight:700; color:#DC2626; margin:0;'>0.6212</p>
                </div>
            </div>
            <small style='color:#16A34A; font-weight:700;'>↑ +18.6% Explained Variance</small>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("---")

    # Detailed Comparison Tabs
    tab_comp1, tab_comp2, tab_comp3, tab_comp4 = st.tabs([
        "📊 Benchmark Bar Chart",
        "🎯 Actual vs. Predicted",
        "📉 Residual Diagnostics",
        "🌲 Feature Importances"
    ])

    with tab_comp1:
        img_path = os.path.join(RESULTS_DIR, "model_performance_comparison.png")
        if os.path.exists(img_path):
            st.image(img_path, caption="Figure 1: Comparison of MAE, RMSE, and R2 on Unseen Test Split (3,476 Records)", use_container_width=True)
        st.markdown("""
        **Benchmark Summary:**
        - **Random Forest Regressor** decisively dominates Linear Regression across all three metrics.
        - The high $R^2$ of **0.8075** confirms that decision tree ensembles successfully capture complex rush-hour non-linearities that a fixed linear hyperplane cannot model.
        """)

    with tab_comp2:
        img_path = os.path.join(RESULTS_DIR, "actual_vs_predicted.png")
        if os.path.exists(img_path):
            st.image(img_path, caption="Figure 2: Actual vs Predicted Demand against the Ideal Fit Diagonal Line (y = x)", use_container_width=True)
        st.markdown("""
        **Diagnostic Takeaway:**
        - In **Linear Regression**, scatter points fan outwards and severely underestimate demand above $500$ bikes/hour.
        - In **Random Forest**, predictions cluster tightly along the red identity line, reliably forecasting high rush-hour surges.
        """)

    with tab_comp3:
        img_path = os.path.join(RESULTS_DIR, "residual_plots.png")
        if os.path.exists(img_path):
            st.image(img_path, caption="Figure 3: Residuals vs. Predicted Values and Error Distribution Histograms", use_container_width=True)
        st.markdown("""
        **Residual Analysis:**
        - Random Forest residuals are symmetrically distributed around zero with a tight standard deviation, verifying homoscedasticity.
        - Linear Regression residuals display curvature, proving that important non-linear patterns remained uncaptured by the linear specification.
        """)

    with tab_comp4:
        img_path = os.path.join(RESULTS_DIR, "feature_importance.png")
        if os.path.exists(img_path):
            st.image(img_path, caption="Figure 4: Top Predictive Features Learned by Random Forest", use_container_width=True)
        st.markdown(r"""
        **Key Feature Importance Insights:**
        - `hr` ($19.1\%$) and `is_rush_hour` ($12.4\%$) represent the primary drivers of demand.
        - Cyclical harmonics `hr_sin` and `hr_cos` account for over $24\%$ cumulative importance.
        - The thermal comfort ratio `temp_hum_ratio` ($11.9\%$) confirms that temperature and humidity jointly influence cycling feasibility.
        """)


# =========================================================
# SECTION 4: DATA VISUALIZATION PAGE (EDA)
# =========================================================
elif "[04]" in page or "Visualizations" in page:
    st.markdown("<div class='main-header'>📈 Exploratory Data Analysis & Visualizations</div>", unsafe_allow_html=True)
    st.markdown("<div class='sub-header'>Statistical distributions, temporal demand rhythms, and environmental sensitivity charts.</div>", unsafe_allow_html=True)

    eda_tab1, eda_tab2, eda_tab3, eda_tab4 = st.tabs([
        "🕒 Hourly & Commuter Rhythms",
        "🍂 Seasonal & Monthly Patterns",
        "🌡️ Weather & Meteorological Impacts",
        "🔄 Cyclical Encoding & Split Timeline"
    ])

    with eda_tab1:
        col_eda1, col_eda2 = st.columns(2)
        with col_eda1:
            p = os.path.join(REPORTS_DIR, "02_hourly_rentals.png")
            if os.path.exists(p):
                st.image(p, caption="Hourly Rentals: Working Days (Dual Peak) vs. Weekends (Bell Curve)", use_container_width=True)
        with col_eda2:
            p = os.path.join(REPORTS_DIR, "01_target_distribution.png")
            if os.path.exists(p):
                st.image(p, caption="Target Distribution (cnt): Right-skewed (+1.28) with rush-hour surge tails", use_container_width=True)
        st.info("💡 **Key Finding:** On working days, commuter demand surges at **08:00 AM** and **05:00–06:00 PM** ($> 450$ bikes/hr). On weekends, demand transitions to an afternoon leisure curve peaking between **12:00 PM and 04:00 PM**.")

    with eda_tab2:
        col_eda3, col_eda4 = st.columns(2)
        with col_eda3:
            p = os.path.join(REPORTS_DIR, "03_seasonal_rentals.png")
            if os.path.exists(p):
                st.image(p, caption="Seasonal Demand: Summer & Fall exhibit highest rental volumes", use_container_width=True)
        with col_eda4:
            p = os.path.join(REPORTS_DIR, "04_monthly_rentals.png")
            if os.path.exists(p):
                st.image(p, caption="Monthly Demand Comparison: System adoption surge between 2011 and 2012", use_container_width=True)
        col_eda5, col_eda6 = st.columns(2)
        with col_eda5:
            p = os.path.join(REPORTS_DIR, "05_weekday_rentals.png")
            if os.path.exists(p):
                st.image(p, caption="Weekday Distribution: Consistent total daily demand across days of week", use_container_width=True)
        with col_eda6:
            p = os.path.join(REPORTS_DIR, "06_workingday_vs_holiday.png")
            if os.path.exists(p):
                st.image(p, caption="Working Days vs Public Holidays: High peak variability on workdays", use_container_width=True)

    with eda_tab3:
        col_eda7, col_eda8 = st.columns(2)
        with col_eda7:
            p = os.path.join(REPORTS_DIR, "07_temperature_vs_rentals.png")
            if os.path.exists(p):
                st.image(p, caption="Temperature vs Rentals: Strong positive correlation (+0.405) up to 32°C", use_container_width=True)
        with col_eda8:
            p = os.path.join(REPORTS_DIR, "08_humidity_vs_rentals.png")
            if os.path.exists(p):
                st.image(p, caption="Humidity vs Rentals: Strong negative correlation (-0.323)", use_container_width=True)
        col_eda9, col_eda10 = st.columns(2)
        with col_eda9:
            p = os.path.join(REPORTS_DIR, "09_windspeed_vs_rentals.png")
            if os.path.exists(p):
                st.image(p, caption="Wind Speed vs Rentals: Sharp demand curtailment above 35 km/h", use_container_width=True)
        with col_eda10:
            p = os.path.join(REPORTS_DIR, "10_correlation_heatmap.png")
            if os.path.exists(p):
                st.image(p, caption="Correlation Matrix: Discovery of severe collinearity between temp & atemp (0.988)", use_container_width=True)

    with eda_tab4:
        col_eda11, col_eda12 = st.columns(2)
        with col_eda11:
            p = os.path.join(REPORTS_DIR, "11_cyclical_time_encoding.png")
            if os.path.exists(p):
                st.image(p, caption="Cyclical 24-Hour Clock Projection in (sin, cos) unit space", use_container_width=True)
        with col_eda12:
            p = os.path.join(REPORTS_DIR, "12_chronological_split_timeline.png")
            if os.path.exists(p):
                st.image(p, caption="Chronological 80/20 Train/Test Split Demarcation Timeline", use_container_width=True)
        p = os.path.join(REPORTS_DIR, "13_engineered_rush_hour_impact.png")
        if os.path.exists(p):
            st.image(p, caption="Engineered Rush Hour Feature Impact: Clear bifurcation in demand volume", use_container_width=True)


# =========================================================
# SECTION 5: ABOUT PROJECT PAGE
# =========================================================
elif "[05]" in page or "About" in page:
    st.markdown("<div class='main-header'>ℹ️ About CycleCast AI Architecture</div>", unsafe_allow_html=True)
    st.markdown("<div class='sub-header'>CycleCast AI — Next-Generation Autonomous Smart Mobility & Demand Synthesis Engine.</div>", unsafe_allow_html=True)

    st.markdown("""
    ### 🎯 System Profile
    - **Platform:** CycleCast AI // Autonomous Micro-Mobility Predictor
    - **Domain:** Predictive Analytics, Autonomous Smart Mobility & Neural Machine Learning
    - **Core Objective:** Real-time & hourly bicycle demand forecasting for fleet rebalancing and dock capacity optimization.

    ---

    ### 📌 Problem Statement & Research Motivation
    Automated bike-sharing networks generate rich timestamped sensor records. However, because bikes are rented and returned autonomously, spatial and temporal demand imbalances frequently occur. 
    During morning hours, residential docks empty out while business districts overflow. In the evening, the pattern reverses. Predicting hourly demand enables fleet operators to schedule dynamic rebalancing trucks, manage dock reserves, and minimize lost rides.
    """)

    fleet_img = os.path.join(REPORTS_DIR, "ai_futuristic_command_deck.jpg")
    if os.path.exists(fleet_img):
        st.image(fleet_img, caption="NEURAL MOBILITY COMMAND DECK // 3D Volumetric Digital-Twin City Hologram & Demand Vector Synthesis", use_container_width=True)

    st.markdown("""
    ---

    ### 📦 Dataset Source & Citation
    - **Repository:** UCI Machine Learning Repository — Bike Sharing Dataset
    - **Dataset File:** `hour.csv` (17,379 records, 17 raw columns)
    - **Location:** Capital Bikeshare System, Washington D.C., USA (2011–2012)
    - **Citation:** Fanaee-T, Hadi, and Gama, Joao, *"Event labeling combining ensemble detectors and background knowledge"*, Progress in Artificial Intelligence (2013), Springer Berlin Heidelberg.

    ---

    ### 🛠️ Technology Stack
    - **Language:** Python 3.13
    - **Data Ingestion & Manipulation:** Pandas, NumPy
    - **Exploratory Data Analysis & Visualization:** Matplotlib, Seaborn
    - **Machine Learning & Pipeline Transformers:** Scikit-Learn, Joblib
    - **Web Dashboard & Deployment:** Streamlit

    ---

    ### 🤖 Machine Learning Algorithms Implemented
    1. **Linear Regression:**
       - Implemented as an interpretable baseline model.
       - Solves for ordinary least squares coefficients across cyclical and scaled weather variables.
       - Test $R^2$: **0.6212** | Test MAE: **102.36 bikes/hr**
    2. **Random Forest Regressor (Champion Model):**
       - Implemented with 150 bagged decision trees, max depth of 18, and `sqrt` feature subsampling.
       - Effectively captures non-linear conditional thresholds (e.g. rush-hour interaction with rain).
       - Test $R^2$: **0.8075** | Test MAE: **65.73 bikes/hr**

    ---

    ### 🚀 Future Scope & Enhancements
    1. **Deep Learning Sequence Modeling:** Implementing Recurrent Neural Networks (LSTM / GRU) or Temporal Transformers to capture multi-hour lag momentum.
    2. **Live Weather API Integration:** Connecting the Streamlit app to real-time weather forecasts (e.g., OpenWeatherMap API) for live automated city forecasting.
    3. **Spatial Rebalancing Optimization:** Incorporating station-level latitude/longitude data to compute optimal vehicle routing paths for dynamic rebalancing trucks.
    """)
