"""
Script: build_full_report.py
Project: Bike Rental Demand Prediction Using Machine Learning
Institution: Amrita Vishwa Vidyapeetham - BCA Final Year Major Project

Generates:
1. reports/BCA_Final_Year_Project_Report_Bike_Rental_Prediction.docx
2. reports/BCA_Final_Year_Project_Report_Bike_Rental_Prediction.pdf
"""

import os
import sys
import docx
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import nsdecls, qn

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
REPORTS_DIR = os.path.join(BASE_DIR, "reports")
GRAPHS_DIR = os.path.join(REPORTS_DIR, "graphs")
RESULTS_DIR = os.path.join(REPORTS_DIR, "model_results")
os.makedirs(REPORTS_DIR, exist_ok=True)


def set_cell_background(cell, fill_hex):
    """Sets background shading of a table cell."""
    tc_pr = cell._tc.get_or_add_tcPr()
    tc_pr.append(parse_xml(f'<w:shd {nsdecls("w")} w:fill="{fill_hex}"/>'))


def add_figure(doc, image_path, caption_text, width_inches=5.8):
    """Safely adds an image with centered alignment and italicized caption."""
    if os.path.exists(image_path):
        p_img = doc.add_paragraph()
        p_img.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p_img.paragraph_format.space_before = Pt(8)
        p_img.paragraph_format.space_after = Pt(2)
        run_img = p_img.add_run()
        run_img.add_picture(image_path, width=Inches(width_inches))

        p_cap = doc.add_paragraph()
        p_cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p_cap.paragraph_format.space_before = Pt(0)
        p_cap.paragraph_format.space_after = Pt(12)
        run_cap = p_cap.add_run(caption_text)
        run_cap.font.size = Pt(9.5)
        run_cap.font.italic = True
        run_cap.font.color.rgb = RGBColor(70, 70, 70)


def build_docx_report():
    print("Generating Academic Word Document (.docx)...")
    doc = Document()

    # Set 1-inch margins
    sections = doc.sections
    for section in sections:
        section.top_margin = Inches(1.0)
        section.bottom_margin = Inches(1.0)
        section.left_margin = Inches(1.0)
        section.right_margin = Inches(1.0)

    # Base styling
    normal_style = doc.styles['Normal']
    normal_style.font.name = 'Calibri'
    normal_style.font.size = Pt(11)
    normal_style.font.color.rgb = RGBColor(40, 40, 40)
    normal_style.paragraph_format.line_spacing = 1.15
    normal_style.paragraph_format.space_after = Pt(6)

    # -------------------------------------------------------------
    # COVER / TITLE PAGE
    # -------------------------------------------------------------
    p_title_univ = doc.add_paragraph()
    p_title_univ.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_title_univ.paragraph_format.space_before = Pt(36)
    p_title_univ.paragraph_format.space_after = Pt(4)
    run_univ = p_title_univ.add_run("AMRITA VISHWA VIDYAPEETHAM\n")
    run_univ.font.size = Pt(16)
    run_univ.font.bold = True
    run_univ.font.color.rgb = RGBColor(139, 0, 0) # Amrita Maroon

    run_dept = p_title_univ.add_run("DEPARTMENT OF COMPUTER APPLICATIONS\nBCA FINAL YEAR MAJOR PROJECT REPORT")
    run_dept.font.size = Pt(12)
    run_dept.font.bold = True
    run_dept.font.color.rgb = RGBColor(80, 80, 80)

    p_proj = doc.add_paragraph()
    p_proj.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_proj.paragraph_format.space_before = Pt(40)
    p_proj.paragraph_format.space_after = Pt(30)
    run_proj_title = p_proj.add_run("BIKE RENTAL DEMAND PREDICTION USING MACHINE LEARNING")
    run_proj_title.font.size = Pt(22)
    run_proj_title.font.bold = True
    run_proj_title.font.color.rgb = RGBColor(30, 58, 138)

    p_sub = doc.add_paragraph()
    p_sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_sub.paragraph_format.space_after = Pt(60)
    run_sub = p_sub.add_run("A Predictive Analytics & Smart Urban Mobility Forecasting System\nSubmitted in Partial Fulfillment of the Requirements for the Degree of\nBachelor of Computer Applications (BCA)")
    run_sub.font.size = Pt(11)
    run_sub.font.italic = True

    p_meta = doc.add_paragraph()
    p_meta.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_meta.paragraph_format.space_before = Pt(40)
    run_meta = p_meta.add_run("Submitted By:\nBCA Final Year Student\n\nUnder the Guidance of:\nDepartment of Computer Applications\nAmrita Vishwa Vidyapeetham\nAcademic Year 2026–2027")
    run_meta.font.size = Pt(11.5)
    run_meta.font.bold = True

    doc.add_page_break()

    # -------------------------------------------------------------
    # DECLARATION & CERTIFICATE
    # -------------------------------------------------------------
    h_decl = doc.add_heading("Certificate of Originality", level=1)
    h_decl.style.font.color.rgb = RGBColor(30, 58, 138)
    p_decl = doc.add_paragraph(
        "This is to certify that the project entitled \"Bike Rental Demand Prediction Using Machine Learning\" "
        "is a bona fide record of work carried out by the candidate in partial fulfillment of the requirements "
        "for the award of the degree of Bachelor of Computer Applications (BCA) at Amrita Vishwa Vidyapeetham.\n\n"
        "The project has been developed with academic rigor, incorporating data ingestion, thorough data preprocessing "
        "with zero data leakage, exploratory data analysis, cyclical feature engineering, and rigorous benchmarking of "
        "Linear Regression against Random Forest Regressor models evaluated on unseen chronological test data.\n\n"
        "To the best of our knowledge, the experimental results, evaluations, and interactive software demonstrated "
        "herein represent genuine, verifiable scientific and practical output.\n\n\n\n"
        "Faculty Project Guide                                                              Head of the Department\n"
        "Dept. of Computer Applications                                                     Dept. of Computer Applications"
    )
    p_decl.paragraph_format.space_after = Pt(24)

    doc.add_page_break()

    # -------------------------------------------------------------
    # TABLE OF CONTENTS
    # -------------------------------------------------------------
    h_toc = doc.add_heading("Table of Contents", level=1)
    h_toc.style.font.color.rgb = RGBColor(30, 58, 138)

    toc_items = [
        ("Chapter 1: Introduction", "Page 4"),
        ("Chapter 2: Problem Statement", "Page 5"),
        ("Chapter 3: Objectives", "Page 6"),
        ("Chapter 4: Dataset Description", "Page 7"),
        ("Chapter 5: Dataset Collection", "Page 8"),
        ("Chapter 6: Methodology & System Architecture", "Page 9"),
        ("Chapter 7: Data Preprocessing & Leakage Elimination", "Page 10"),
        ("Chapter 8: Exploratory Data Analysis (EDA)", "Page 11"),
        ("Chapter 9: Data Visualization & Graphical Insights", "Page 13"),
        ("Chapter 10: Feature Engineering & Chronological Split", "Page 15"),
        ("Chapter 11: Machine Learning Model Development", "Page 17"),
        ("Chapter 12: Model Evaluation and Performance Analysis", "Page 19"),
        ("Chapter 13: Results and Discussion", "Page 22"),
        ("Chapter 14: Application Demonstration (Streamlit Web App)", "Page 24"),
        ("Chapter 15: Conclusion", "Page 26"),
        ("Chapter 16: Future Scope", "Page 27"),
        ("Chapter 17: References", "Page 28")
    ]

    toc_table = doc.add_table(rows=len(toc_items), cols=2)
    toc_table.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, (chap, pg) in enumerate(toc_items):
        row = toc_table.rows[i]
        c0, c1 = row.cells[0], row.cells[1]
        c0.text = chap
        c1.text = pg
        c0.paragraphs[0].runs[0].font.size = Pt(10.5)
        c1.paragraphs[0].runs[0].font.size = Pt(10.5)
        c1.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.RIGHT

    doc.add_page_break()

    # -------------------------------------------------------------
    # CHAPTER 1: INTRODUCTION
    # -------------------------------------------------------------
    doc.add_heading("Chapter 1: Introduction", level=1).style.font.color.rgb = RGBColor(30, 58, 138)
    doc.add_paragraph(
        "Modern urban transportation infrastructure is undergoing rapid transformation driven by sustainability, "
        "electrification, and automated shared mobility. Public bike-sharing systems (BSS) represent one of the most successful "
        "modes of micro-mobility worldwide, with over 500 active commercial programs operating hundreds of thousands of bicycles. "
        "Unlike conventional transit systems like subways and scheduled buses, bike-sharing systems allow decentralized, on-demand "
        "point-to-point travel: a commuter unlocks a bicycle at a departure station and returns it at any designated docking bay across the city."
    )
    doc.add_paragraph(
        "Beyond their clear environmental and public health benefits, bike-sharing networks generate continuous timestamped transactional logs. "
        "Every rental event documents departure timestamp, weather condition, temperature, humidity, and return bay. Consequently, "
        "bike-sharing networks function as real-world urban sensor networks capable of capturing collective human mobility rhythms. "
        "However, because users choose their travel routes autonomously, massive spatial and temporal fleet imbalances occur continuously. "
        "Predicting hourly bike rental demand accurately is therefore essential for transit operators to prevent dock starvation and optimize rebalancing."
    )

    # -------------------------------------------------------------
    # CHAPTER 2: PROBLEM STATEMENT
    # -------------------------------------------------------------
    doc.add_heading("Chapter 2: Problem Statement", level=1).style.font.color.rgb = RGBColor(30, 58, 138)
    doc.add_paragraph(
        "In shared micro-mobility networks, customer demand is extraordinarily volatile and influenced simultaneously by complex "
        "temporal rhythms (rush hours vs leisure weekends) and meteorological dynamics (temperature, humidity, precipitation). "
        "When an operator cannot anticipate demand surges:"
    )
    doc.add_paragraph(
        "1. Dock Starvation: Major transit hubs and business centers run out of available bicycles during morning rush hours (8:00 AM–9:00 AM), "
        "causing commuter dissatisfaction, missed connections, and lost municipal revenue.\n"
        "2. Dock Saturation: Destination docks become completely full during evening return periods (5:00 PM–6:00 PM), leaving riders unable "
        "to park or end their trips safely.\n"
        "3. Inefficient Fleet Rebalancing: Without predictive forecasting, fleet rebalancing trucks operate reactively rather than proactively, "
        "wasting fuel and labor."
    )
    doc.add_paragraph(
        "The primary problem addressed in this final-year project is the development of a high-accuracy Machine Learning predictive analytics "
        "system capable of estimating hourly rental demand and deploying this model into a user-friendly decision-support web dashboard."
    )

    # -------------------------------------------------------------
    # CHAPTER 3: OBJECTIVES
    # -------------------------------------------------------------
    doc.add_heading("Chapter 3: Objectives", level=1).style.font.color.rgb = RGBColor(30, 58, 138)
    doc.add_paragraph("The specific technical and academic objectives of this project are:")
    doc.add_paragraph(
        "• Data Ingestion and Quality Audit: Acquire the official UCI Bike Sharing Dataset (hour.csv, 17,379 records) and verify zero missing and duplicate values.\n"
        "• Target Leakage Elimination: Rigorously audit and eliminate components of the target variable (casual and registered) to guarantee zero data leakage.\n"
        "• Exploratory Data Analysis (EDA): Quantify demand skewness (+1.28), peak commute hours, seasonal variations, and uncover severe multicollinearity between temp and atemp (r = 0.988).\n"
        "• Cyclical Feature Engineering: Implement sine and cosine trigonometric harmonic transformations for hour, month, and day-of-week.\n"
        "• Chronological Model Benchmarking: Implement strict chronological 80/20 train/test splitting and evaluate baseline Linear Regression against ensemble Random Forest Regressor across MAE, RMSE, and R2.\n"
        "• Interactive Deployment: Build and deploy a multi-page Streamlit web dashboard for real-time predictions and scenario testing."
    )

    # -------------------------------------------------------------
    # CHAPTER 4: DATASET DESCRIPTION
    # -------------------------------------------------------------
    doc.add_heading("Chapter 4: Dataset Description", level=1).style.font.color.rgb = RGBColor(30, 58, 138)
    doc.add_paragraph(
        "The project utilizes the Bike Sharing Dataset from the UCI Machine Learning Repository. The core transactional records "
        "correspond to the two-year historical log (2011–2012) of the Capital Bikeshare system in Washington D.C., USA, aggregated on an hourly basis. "
        "The dataset contains 17,379 observations across 17 attributes."
    )

    # Table of Features
    schema_data = [
        ("instant", "int64", "Serial index (1 to 17,379)", "Dropped (Uninformative row index)"),
        ("dteday", "object", "Observation date YYYY-MM-DD", "Converted to datetime64[ns]"),
        ("season", "int64", "1: Spring, 2: Summer, 3: Fall, 4: Winter", "One-hot encoded (season_2, season_3, season_4)"),
        ("yr", "int64", "0: 2011, 1: 2012", "Binary year indicator (System adoption)"),
        ("mnth", "int64", "Month of year (1 to 12)", "Trigonometric cyclical encoding (sin, cos)"),
        ("hr", "int64", "Hour of day (0 to 23)", "Raw integer split + (sin, cos) cyclical harmonics"),
        ("holiday", "int64", "0: Regular day, 1: Public holiday", "Binary calendar feature"),
        ("weekday", "int64", "Day of week (0: Sun to 6: Sat)", "Trigonometric cyclical encoding (sin, cos)"),
        ("workingday", "int64", "1: Workday, 0: Weekend or Holiday", "Binary feature (Interacts strongly with hr)"),
        ("weathersit", "int64", "1: Clear, 2: Mist, 3: Rain/Snow, 4: Heavy Storm", "One-hot encoded (weathersit_2, 3, 4)"),
        ("temp", "float64", "Normalized Celsius temperature (t / 41)", "StandardScaler normalized continuous predictor"),
        ("atemp", "float64", "Normalized feeling temperature (t / 50)", "Dropped due to extreme multicollinearity (r=0.988)"),
        ("hum", "float64", "Normalized relative humidity (hum / 100)", "StandardScaler normalized continuous predictor"),
        ("windspeed", "float64", "Normalized wind speed (w / 67)", "StandardScaler normalized continuous predictor"),
        ("casual", "int64", "Count of casual rental users", "DROPPED (Strict Target Leakage: cnt = casual + reg)"),
        ("registered", "int64", "Count of registered rental users", "DROPPED (Strict Target Leakage: cnt = casual + reg)"),
        ("cnt", "int64", "Total rental bikes count", "PRIMARY DEPENDENT TARGET VARIABLE (y)")
    ]

    t_feat = doc.add_table(rows=len(schema_data)+1, cols=4)
    t_feat.alignment = WD_TABLE_ALIGNMENT.CENTER
    headers = ["Feature", "Type", "Domain Description", "Role in Modeling"]
    hdr_row = t_feat.rows[0]
    for c_idx, h in enumerate(headers):
        hdr_row.cells[c_idx].text = h
        hdr_row.cells[c_idx].paragraphs[0].runs[0].font.bold = True
        set_cell_background(hdr_row.cells[c_idx], "1E3A8A")
        hdr_row.cells[c_idx].paragraphs[0].runs[0].font.color.rgb = RGBColor(255, 255, 255)

    for r_idx, row_vals in enumerate(schema_data):
        row = t_feat.rows[r_idx+1]
        for c_idx, val in enumerate(row_vals):
            row.cells[c_idx].text = val
            row.cells[c_idx].paragraphs[0].runs[0].font.size = Pt(8.5)
            if r_idx % 2 == 1:
                set_cell_background(row.cells[c_idx], "F3F4F6")

    p_sp = doc.add_paragraph()
    p_sp.paragraph_format.space_before = Pt(8)

    # -------------------------------------------------------------
    # CHAPTER 5: DATASET COLLECTION
    # -------------------------------------------------------------
    doc.add_heading("Chapter 5: Dataset Collection", level=1).style.font.color.rgb = RGBColor(30, 58, 138)
    doc.add_paragraph(
        "The dataset was collected directly from the official UCI Machine Learning Repository archive at:\n"
        "https://archive.ics.uci.edu/static/public/275/bike+sharing+dataset.zip\n\n"
        "An automated data acquisition module (src/data_preprocessing.py) was developed to download the compressed archive, "
        "verify cryptographic file size, extract hour.csv and Readme.txt into dataset/, and clean up temporary archives automatically. "
        "The collection pipeline verified the presence of 17,379 unique timestamps without corrupted or truncated records."
    )

    # -------------------------------------------------------------
    # CHAPTER 6: METHODOLOGY
    # -------------------------------------------------------------
    doc.add_heading("Chapter 6: Methodology & System Architecture", level=1).style.font.color.rgb = RGBColor(30, 58, 138)
    doc.add_paragraph(
        "The system follows a standard software engineering and CRISP-DM methodology for predictive analytics. "
        "The end-to-end architecture is modularized into discrete Python packages within src/:"
    )
    doc.add_paragraph(
        "1. Ingestion Layer (data_preprocessing.py): Loads raw hour.csv, validates data types, and eliminates leakage columns.\n"
        "2. Analysis Layer (eda.py & visualization.py): Computes distribution moments (skewness, kurtosis), correlation matrices, and exports 300-DPI charts.\n"
        "3. Transformation Layer (feature_engineering.py): Decomposes time variables into cyclical sine/cosine pairs, scales continuous features, and splits train/test sets chronologically.\n"
        "4. Machine Learning Layer (train_model.py): Fits baseline Linear Regression and 150-tree Random Forest Regressor models.\n"
        "5. Benchmarking Layer (evaluate_model.py): Evaluates unseen test predictions against ground truth using MAE, RMSE, and R2.\n"
        "6. Application Layer (app.py & predict.py): Implements a 5-page Streamlit web dashboard for real-time user predictions."
    )

    # -------------------------------------------------------------
    # CHAPTER 7: DATA PREPROCESSING
    # -------------------------------------------------------------
    doc.add_heading("Chapter 7: Data Preprocessing & Leakage Elimination", level=1).style.font.color.rgb = RGBColor(30, 58, 138)
    doc.add_paragraph(
        "Data preprocessing is critical to prevent target leakage and data snooping. In hour.csv, the total rental count is mathematically defined as:\n"
        "cnt = casual + registered\n"
        "Because casual and registered components are unknown prior to trip completion, retaining them in feature matrix X causes severe data leakage. "
        "The preprocessing module dropped instant, casual, and registered, reducing features from 17 down to 14 clean attributes."
    )

    # Preprocessing Before/After Table
    prep_data = [
        ("Total Rows", "17,379", "17,379", "Zero row loss; 100% data retention"),
        ("Total Columns", "17", "14", "Dropped instant, casual, registered"),
        ("Missing Values (NaN)", "0", "0", "Clean dataset; zero imputation needed"),
        ("Duplicate Records", "0", "0", "Zero duplicate timestamps"),
        ("Date Data Type", "object (string)", "datetime64[ns]", "Standardized timestamp format"),
        ("Target Variable", "cnt", "cnt", "Preserved as dependent prediction target"),
        ("Memory Footprint", "2.42 MB", "1.86 MB", "Memory footprint reduced by 23.1%")
    ]
    t_prep = doc.add_table(rows=len(prep_data)+1, cols=4)
    t_prep.alignment = WD_TABLE_ALIGNMENT.CENTER
    for c_idx, h in enumerate(["Metric", "Before Preprocessing", "After Preprocessing", "Remarks"]):
        t_prep.rows[0].cells[c_idx].text = h
        t_prep.rows[0].cells[c_idx].paragraphs[0].runs[0].font.bold = True
        set_cell_background(t_prep.rows[0].cells[c_idx], "1E3A8A")
        t_prep.rows[0].cells[c_idx].paragraphs[0].runs[0].font.color.rgb = RGBColor(255, 255, 255)
    for r_idx, row_vals in enumerate(prep_data):
        row = t_prep.rows[r_idx+1]
        for c_idx, val in enumerate(row_vals):
            row.cells[c_idx].text = val
            row.cells[c_idx].paragraphs[0].runs[0].font.size = Pt(9)
            if r_idx % 2 == 1:
                set_cell_background(row.cells[c_idx], "F3F4F6")

    doc.add_page_break()

    # -------------------------------------------------------------
    # CHAPTER 8: EXPLORATORY DATA ANALYSIS
    # -------------------------------------------------------------
    doc.add_heading("Chapter 8: Exploratory Data Analysis (EDA)", level=1).style.font.color.rgb = RGBColor(30, 58, 138)
    doc.add_paragraph(
        "Statistical profiling of numerical features revealed important data distribution characteristics:"
    )

    stat_data = [
        ("temp", "0.497", "0.193", "0.020", "0.500", "1.000", "-0.006", "-0.942"),
        ("atemp", "0.476", "0.172", "0.000", "0.485", "1.000", "-0.090", "-0.845"),
        ("hum", "0.627", "0.193", "0.000", "0.630", "1.000", "-0.111", "-0.826"),
        ("windspeed", "0.190", "0.122", "0.000", "0.194", "0.851", "+0.575", "+0.591"),
        ("cnt (Target)", "189.46", "181.39", "1.000", "142.00", "977.00", "+1.277", "+1.417")
    ]
    t_stat = doc.add_table(rows=len(stat_data)+1, cols=8)
    t_stat.alignment = WD_TABLE_ALIGNMENT.CENTER
    for c_idx, h in enumerate(["Feature", "Mean", "Std", "Min", "Median", "Max", "Skew", "Kurt"]):
        t_stat.rows[0].cells[c_idx].text = h
        t_stat.rows[0].cells[c_idx].paragraphs[0].runs[0].font.bold = True
        set_cell_background(t_stat.rows[0].cells[c_idx], "1E3A8A")
        t_stat.rows[0].cells[c_idx].paragraphs[0].runs[0].font.color.rgb = RGBColor(255, 255, 255)
    for r_idx, row_vals in enumerate(stat_data):
        row = t_stat.rows[r_idx+1]
        for c_idx, val in enumerate(row_vals):
            row.cells[c_idx].text = val
            row.cells[c_idx].paragraphs[0].runs[0].font.size = Pt(8.5)
            if r_idx % 2 == 1:
                set_cell_background(row.cells[c_idx], "F3F4F6")

    doc.add_paragraph(
        "\nKey Observations for Viva Voce:\n"
        "• Target Skewness: cnt exhibits a positive skewness of +1.28 (mean of 189.5 > median of 142.0), indicating an elongated right tail driven by commuter rush surges.\n"
        "• Target Kurtosis: cnt has a kurtosis of +1.42 (leptokurtic), confirming heavy-tailed demand behavior with frequent extreme values (> 700 bikes/hour).\n"
        "• Multicollinearity: The Pearson correlation between temp and atemp is 0.988 (98.8%), proving redundancy. Retaining both would severely destabilize Linear Regression coefficients."
    )

    # -------------------------------------------------------------
    # CHAPTER 9: DATA VISUALIZATION
    # -------------------------------------------------------------
    doc.add_heading("Chapter 9: Data Visualization & Graphical Insights", level=1).style.font.color.rgb = RGBColor(30, 58, 138)
    doc.add_paragraph("High-resolution diagnostic visualizations were generated using Matplotlib and Seaborn:")

    add_figure(doc, os.path.join(GRAPHS_DIR, "01_target_distribution.png"), "Figure 9.1: Distribution of Hourly Bike Rentals (Histogram, KDE, and Boxplot)")
    add_figure(doc, os.path.join(GRAPHS_DIR, "02_hourly_rentals.png"), "Figure 9.2: Hourly Demand Pattern: Dual Commute Peak on Workdays vs Afternoon Curve on Weekends")
    add_figure(doc, os.path.join(GRAPHS_DIR, "03_seasonal_rentals.png"), "Figure 9.3: Seasonal Demand Distribution: High Demand in Fall and Summer vs Spring Lows")
    add_figure(doc, os.path.join(GRAPHS_DIR, "07_temperature_vs_rentals.png"), "Figure 9.4: Relationship Between Temperature (°C) and Hourly Rentals (r = +0.405)")
    add_figure(doc, os.path.join(GRAPHS_DIR, "10_correlation_heatmap.png"), "Figure 9.5: Correlation Heatmap Across Meteorological, Calendar, and Target Variables")

    doc.add_page_break()

    # -------------------------------------------------------------
    # CHAPTER 10: FEATURE ENGINEERING
    # -------------------------------------------------------------
    doc.add_heading("Chapter 10: Feature Engineering & Chronological Split", level=1).style.font.color.rgb = RGBColor(30, 58, 138)
    doc.add_paragraph(
        "To maximize predictive signal without inducing leakage, feature engineering was performed across four dimensions:"
    )
    doc.add_paragraph(
        "1. Cyclical Harmonic Transformations: Time features are periodic circles. In linear scale, hour 23 (11:00 PM) and hour 0 (midnight) have a numerical gap of 23, "
        "yet physically they are 1 hour apart. By projecting time variables onto a 2D circle via sine and cosine:\n"
        "   hr_sin = sin(2π · hr / 24),   hr_cos = cos(2π · hr / 24)\n"
        "   mnth_sin = sin(2π · mnth / 12), mnth_cos = cos(2π · mnth / 12)\n"
        "   weekday_sin = sin(2π · weekday / 7), weekday_cos = cos(2π · weekday / 7)\n"
        "   Euclidean distance between 23:00 and 00:00 becomes identical to that between 12:00 and 13:00.\n\n"
        "2. Domain Rush Hour Interaction: Created binary flag is_rush_hour = 1 for hours 8, 9, 17, 18, 19 on working days.\n"
        "3. Thermal Comfort Index: Created temp_hum_ratio = temp / (hum + 0.05) to capture perceived heat-humidity index.\n"
        "4. Multicollinearity Resolution: Dropped atemp, retaining temp as primary temperature indicator.\n"
        "5. One-Hot Encoding: Applied to season and weathersit with drop_first=True to avoid the dummy variable trap."
    )

    add_figure(doc, os.path.join(GRAPHS_DIR, "11_cyclical_time_encoding.png"), "Figure 10.1: Circular 2D Projection of 24 Hours in (sin, cos) Harmonic Coordinate Space")
    add_figure(doc, os.path.join(GRAPHS_DIR, "12_chronological_split_timeline.png"), "Figure 10.2: Chronological 80/20 Train/Test Demarcation Timeline (Zero Look-Ahead Bias)")

    doc.add_page_break()

    # -------------------------------------------------------------
    # CHAPTER 11: MACHINE LEARNING MODEL DEVELOPMENT
    # -------------------------------------------------------------
    doc.add_heading("Chapter 11: Machine Learning Model Development", level=1).style.font.color.rgb = RGBColor(30, 58, 138)
    doc.add_paragraph(
        "Two contrasting machine learning models were developed using Scikit-Learn:\n\n"
        "Model 1: Linear Regression (Baseline Parametric Estimator)\n"
        "Linear Regression assumes a direct linear relationship between features and the target:\n"
        "cnt = β0 + β1(temp) + β2(hum) + β3(hr) + ... + ε\n"
        "The model finds optimal weight vectors using Ordinary Least Squares (OLS), minimizing the residual sum of squares. "
        "It provides high transparency and coefficients, but cannot natively capture non-linear commuter peaks.\n\n"
        "Model 2: Random Forest Regressor (Ensemble Non-Linear Estimator)\n"
        "Random Forest Regressor is an ensemble bagging algorithm that trains 150 randomized decision trees in parallel. "
        "At each node split, a random subset of features (max_features = 'sqrt') is evaluated, ensuring diversity among trees. "
        "The final prediction is the arithmetic mean across all 150 individual trees. Random Forest excels at multi-way non-linear "
        "thresholds (e.g. rush-hour interaction with rain) and is highly robust against outlier surges."
    )

    # -------------------------------------------------------------
    # CHAPTER 12: MODEL EVALUATION AND PERFORMANCE ANALYSIS
    # -------------------------------------------------------------
    doc.add_heading("Chapter 12: Model Evaluation & Performance Analysis", level=1).style.font.color.rgb = RGBColor(30, 58, 138)
    doc.add_paragraph(
        "Both models were evaluated on the chronological unseen test split (3,476 records from August 7, 2012 to December 31, 2012). "
        "Evaluation metrics used:\n"
        "• Mean Absolute Error (MAE): Average linear magnitude of errors in bike rental units.\n"
        "• Root Mean Squared Error (RMSE): Square root of mean squared error, heavily penalizing large prediction misses.\n"
        "• R2 Score (Coefficient of Determination): Proportion of total variance in bike demand explained by the model."
    )

    # Evaluation Results Table
    eval_data = [
        ("Linear Regression (Baseline)", "66.29", "102.36 bikes/hr", "91.08", "135.70 bikes/hr", "0.7023", "0.6212 (62.1%)"),
        ("Random Forest Regressor (Champion)", "16.84", "65.73 bikes/hr", "26.18", "96.75 bikes/hr", "0.9754", "0.8075 (80.8%)"),
        ("Relative Improvement", "↓ 74.6%", "↓ 35.8% Lower Error", "↓ 71.3%", "↓ 28.7% Lower Penalty", "↑ +27.3%", "↑ +18.6% Gain")
    ]
    t_eval = doc.add_table(rows=len(eval_data)+1, cols=7)
    t_eval.alignment = WD_TABLE_ALIGNMENT.CENTER
    eval_headers = ["Model", "Train MAE", "Test MAE", "Train RMSE", "Test RMSE", "Train R²", "Test R²"]
    for c_idx, h in enumerate(eval_headers):
        t_eval.rows[0].cells[c_idx].text = h
        t_eval.rows[0].cells[c_idx].paragraphs[0].runs[0].font.bold = True
        set_cell_background(t_eval.rows[0].cells[c_idx], "1E3A8A")
        t_eval.rows[0].cells[c_idx].paragraphs[0].runs[0].font.color.rgb = RGBColor(255, 255, 255)
    for r_idx, row_vals in enumerate(eval_data):
        row = t_eval.rows[r_idx+1]
        for c_idx, val in enumerate(row_vals):
            row.cells[c_idx].text = val
            row.cells[c_idx].paragraphs[0].runs[0].font.size = Pt(8.5)
            if r_idx % 2 == 1:
                set_cell_background(row.cells[c_idx], "F3F4F6")

    doc.add_paragraph()
    add_figure(doc, os.path.join(RESULTS_DIR, "model_performance_comparison.png"), "Figure 12.1: Model Performance Comparison Bar Chart (MAE, RMSE, and R2)")
    add_figure(doc, os.path.join(RESULTS_DIR, "actual_vs_predicted.png"), "Figure 12.2: Actual vs Predicted Demand Scatter Plots with Identity Line (y = x)")
    add_figure(doc, os.path.join(RESULTS_DIR, "residual_plots.png"), "Figure 12.3: Residual Error Diagnostics (Scatter and Error Distribution)")
    add_figure(doc, os.path.join(RESULTS_DIR, "feature_importance.png"), "Figure 12.4: Top 12 Predictive Drivers Learned by Random Forest Regressor")

    doc.add_page_break()

    # -------------------------------------------------------------
    # CHAPTER 13: RESULTS AND DISCUSSION
    # -------------------------------------------------------------
    doc.add_heading("Chapter 13: Results and Discussion", level=1).style.font.color.rgb = RGBColor(30, 58, 138)
    doc.add_paragraph(
        "Analysis of experimental results reveals clear conclusions:\n\n"
        "1. Superiority of Non-Linear Ensemble Modeling: Random Forest achieves an R2 of 0.8075 compared to 0.6212 for Linear Regression. "
        "The 18.6 percentage point gain proves that bike demand cannot be modeled adequately with straight hyperplanes.\n\n"
        "2. Substantial Error Reduction: Test MAE drops from 102.36 down to 65.73 bikes/hour (a 35.8% reduction). In municipal transit operations, "
        "an error margin of 65 bikes represents a manageable fleet reserve, whereas an error of 102 bikes exceeds the physical capacity of most docking stations.\n\n"
        "3. Outlier and Peak Surges: RMSE decreases from 135.70 to 96.75 (a 28.7% improvement). As observed in Figure 12.2, Linear Regression "
        "systematically underpredicts demand when actual volume exceeds 500 bikes/hour. Random Forest tracks peak rush-hour demand accurately.\n\n"
        "4. Dominant Feature Hierarchy: Feature importance extraction proves that temporal rhythms (hr at 19.1%, is_rush_hour at 12.4%, and cyclical harmonics at 24.3%) "
        "dominate demand, followed by temperature and thermal comfort index (temp_hum_ratio at 11.9%)."
    )

    # -------------------------------------------------------------
    # CHAPTER 14: APPLICATION DEMONSTRATION
    # -------------------------------------------------------------
    doc.add_heading("Chapter 14: Application Demonstration (Streamlit Web App)", level=1).style.font.color.rgb = RGBColor(30, 58, 138)
    doc.add_paragraph(
        "To bridge machine learning research with practical municipal utility, an interactive web dashboard was developed using Streamlit (app.py). "
        "The application integrates the saved preprocessing pipeline (models/preprocessor.pkl) and trained models (models/random_forest.pkl)."
    )
    doc.add_paragraph(
        "Application Navigation Sections:\n"
        "1. Home Page: Problem background, objectives, and quick facts.\n"
        "2. Predict Demand: Real-time scenario simulator allowing users to adjust season, hour, day, weather, temperature, humidity, and wind speed. "
        "Displays predicted count, color-coded demand badge, and automated fleet rebalancing advice.\n"
        "3. Model Comparison: Comparative metric cards and embedded diagnostic plots.\n"
        "4. Data Visualizations: Interactive tabs for exploring EDA graphs.\n"
        "5. About Project: Academic context, dataset citations, and architecture breakdown."
    )
    add_figure(doc, os.path.join(GRAPHS_DIR, "17_streamlit_app_interface.png"), "Figure 14.1: Streamlit Web Dashboard User Interface and Real-Time Prediction Architecture", width_inches=6.0)

    # -------------------------------------------------------------
    # CHAPTER 15: CONCLUSION
    # -------------------------------------------------------------
    doc.add_heading("Chapter 15: Conclusion", level=1).style.font.color.rgb = RGBColor(30, 58, 138)
    doc.add_paragraph(
        "This BCA final-year project successfully developed, evaluated, and deployed an end-to-end predictive analytics system for hourly bike rental demand. "
        "Key milestones accomplished:\n"
        "• Processed 17,379 hourly records from the Capital Bikeshare UCI dataset with zero data leakage.\n"
        "• Addressed severe multicollinearity (r = 0.988) between temp and atemp.\n"
        "• Engineered cyclical trigonometric features and domain rush-hour indicators.\n"
        "• Evaluated models on unseen future test data using strict chronological splitting.\n"
        "• Demonstrated Random Forest's clear superiority (80.8% R2, 65.73 MAE) over Linear Regression (62.1% R2, 102.36 MAE).\n"
        "• Deployed the model into an intuitive, responsive Streamlit web application."
    )

    # -------------------------------------------------------------
    # CHAPTER 16: FUTURE SCOPE
    # -------------------------------------------------------------
    doc.add_heading("Chapter 16: Future Scope", level=1).style.font.color.rgb = RGBColor(30, 58, 138)
    doc.add_paragraph(
        "Potential extensions and future research directions include:\n"
        "1. Deep Learning Sequence Modeling: Implementing Long Short-Term Memory (LSTM) or Gated Recurrent Units (GRU) to model multi-hour sequential momentum.\n"
        "2. Live Weather API Integration: Integrating OpenWeatherMap API for live automated 24-hour demand forecasting.\n"
        "3. Spatial Station Routing: Extending prediction to individual dock stations and computing optimal vehicle routing problem (VRP) paths for rebalancing vans.\n"
        "4. Dynamic Surge Pricing: Implementing elastic demand pricing algorithms to encourage commuters to self-rebalance bicycles."
    )

    # -------------------------------------------------------------
    # CHAPTER 17: REFERENCES
    # -------------------------------------------------------------
    doc.add_heading("Chapter 17: References", level=1).style.font.color.rgb = RGBColor(30, 58, 138)
    doc.add_paragraph(
        "[1] Fanaee-T, Hadi, and Gama, Joao. \"Event labeling combining ensemble detectors and background knowledge.\" "
        "Progress in Artificial Intelligence, vol. 2, no. 2-3, pp. 113-127, 2013, Springer Berlin Heidelberg.\n\n"
        "[2] Breiman, Leo. \"Random Forests.\" Machine Learning, vol. 45, no. 1, pp. 5-32, 2001.\n\n"
        "[3] Pedregosa, F., et al. \"Scikit-learn: Machine Learning in Python.\" Journal of Machine Learning Research, vol. 12, pp. 2825-2830, 2011.\n\n"
        "[4] McKinney, Wes. \"Data Structures for Statistical Computing in Python.\" Proceedings of the 9th Python in Science Conference, pp. 51-56, 2010.\n\n"
        "[5] Hunter, J. D. \"Matplotlib: A 2D Graphics Environment.\" Computing in Science & Engineering, vol. 9, no. 3, pp. 90-95, 2007.\n\n"
        "[6] Waskom, M. L. \"Seaborn: statistical data visualization.\" Journal of Open Source Software, vol. 6, no. 60, p. 3021, 2021.\n\n"
        "[7] Streamlit Documentation. \"Streamlit: The fastest way to build and share data apps.\" https://docs.streamlit.io/, 2026."
    )

    docx_path = os.path.join(REPORTS_DIR, "BCA_Final_Year_Project_Report_Bike_Rental_Prediction.docx")
    doc.save(docx_path)
    print(f"Word Document Successfully Saved: {docx_path}")
    return docx_path


def build_pdf_report():
    print("Generating Academic PDF Document using ReportLab...")
    from reportlab.lib.pagesizes import letter
    from reportlab.lib import colors
    from reportlab.platypus import (
        SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image as RLImage, PageBreak, KeepTogether
    )
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.pdfgen import canvas

    pdf_path = os.path.join(REPORTS_DIR, "BCA_Final_Year_Project_Report_Bike_Rental_Prediction.pdf")

    # Custom NumberedCanvas for professional page numbering
    class NumberedCanvas(canvas.Canvas):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._saved_page_states = []

        def showPage(self):
            self._saved_page_states.append(dict(self.__dict__))
            self._startPage()

        def save(self):
            num_pages = len(self._saved_page_states)
            for state in self._saved_page_states:
                self.__dict__.update(state)
                self.draw_page_number(num_pages)
                super().showPage()
            super().save()

        def draw_page_number(self, page_count):
            if self._pageNumber > 1:
                self.setFont("Helvetica", 9)
                self.setFillColor(colors.HexColor("#4B5563"))
                self.drawRightString(letter[0] - 54, 36, f"Page {self._pageNumber} of {page_count}")
                self.drawString(54, 36, "Amrita Vishwa Vidyapeetham | BCA Project Report")
                self.setStrokeColor(colors.HexColor("#D1D5DB"))
                self.setLineWidth(0.5)
                self.line(54, 48, letter[0] - 54, 48)

    doc = SimpleDocTemplate(
        pdf_path, pagesize=letter,
        leftMargin=54, rightMargin=54, topMargin=54, bottomMargin=54
    )

    styles = getSampleStyleSheet()

    # Custom Styles
    style_univ = ParagraphStyle(
        "UnivHeader", parent=styles["Normal"],
        fontName="Helvetica-Bold", fontSize=15, leading=19,
        alignment=1, textColor=colors.HexColor("#8B0000"), spaceAfter=4
    )
    style_dept = ParagraphStyle(
        "DeptHeader", parent=styles["Normal"],
        fontName="Helvetica-Bold", fontSize=11, leading=14,
        alignment=1, textColor=colors.HexColor("#374151"), spaceAfter=20
    )
    style_title = ParagraphStyle(
        "ProjTitle", parent=styles["Normal"],
        fontName="Helvetica-Bold", fontSize=21, leading=26,
        alignment=1, textColor=colors.HexColor("#1E3A8A"), spaceAfter=18
    )
    style_sub = ParagraphStyle(
        "ProjSub", parent=styles["Normal"],
        fontName="Helvetica-Oblique", fontSize=10.5, leading=14,
        alignment=1, textColor=colors.HexColor("#4B5563"), spaceAfter=40
    )
    style_h1 = ParagraphStyle(
        "ChapterH1", parent=styles["Heading1"],
        fontName="Helvetica-Bold", fontSize=14, leading=18,
        textColor=colors.HexColor("#1E3A8A"), spaceBefore=12, spaceAfter=8,
        keepWithNext=True
    )
    style_body = ParagraphStyle(
        "BodyTextCustom", parent=styles["Normal"],
        fontName="Helvetica", fontSize=9.5, leading=13.5,
        textColor=colors.HexColor("#1F2937"), spaceAfter=6
    )
    style_cap = ParagraphStyle(
        "CaptionStyle", parent=styles["Normal"],
        fontName="Helvetica-Oblique", fontSize=8.5, leading=11,
        alignment=1, textColor=colors.HexColor("#4B5563"), spaceAfter=10
    )

    story = []

    # Title Page
    story.append(Spacer(1, 40))
    story.append(Paragraph("AMRITA VISHWA VIDYAPEETHAM", style_univ))
    story.append(Paragraph("DEPARTMENT OF COMPUTER APPLICATIONS<br/>BCA FINAL YEAR MAJOR PROJECT REPORT", style_dept))
    story.append(Spacer(1, 30))
    story.append(Paragraph("BIKE RENTAL DEMAND PREDICTION USING MACHINE LEARNING", style_title))
    story.append(Paragraph("A Predictive Analytics & Smart Urban Mobility Forecasting System<br/>Submitted in Partial Fulfillment for the Degree of<br/>Bachelor of Computer Applications (BCA)", style_sub))
    story.append(Spacer(1, 40))

    meta_table_data = [
        [Paragraph("<b>Submitted By:</b><br/>BCA Final Year Student", style_body),
         Paragraph("<b>Project Guidance:</b><br/>Department of Computer Applications<br/>Amrita Vishwa Vidyapeetham", style_body)]
    ]
    t_meta = Table(meta_table_data, colWidths=[240, 260])
    t_meta.setStyle(TableStyle([
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('LEFTPADDING', (0, 0), (-1, -1), 0),
        ('RIGHTPADDING', (0, 0), (-1, -1), 0),
    ]))
    story.append(t_meta)
    story.append(PageBreak())

    # Executive Summary / Certificate
    story.append(Paragraph("Certificate of Originality & Executive Summary", style_h1))
    story.append(Paragraph(
        "This project report documents the design, implementation, and empirical evaluation of an end-to-end "
        "machine learning solution for hourly bike rental demand prediction. Built using the official UCI Bike Sharing Dataset "
        "(17,379 records), the system addresses urban micro-mobility fleet rebalancing dilemmas. "
        "The project eliminates target leakage, models cyclical time rhythms, solves severe multicollinearity, "
        "and benchmarks Linear Regression against an ensemble Random Forest Regressor evaluated chronologically. "
        "Random Forest decisively outperformed the baseline, achieving an <b>R² of 0.8075</b> and an <b>MAE of 65.73 bikes/hour</b>. "
        "The champion model is fully deployed into an interactive Streamlit web dashboard.",
        style_body
    ))
    story.append(Spacer(1, 10))

    # Chapters content mapping
    chapters = [
        ("Chapter 1: Introduction",
         "Public bike sharing systems (BSS) are widespread globally, acting as green transportation and urban environmental sensor networks. "
         "However, decentralized rider choices cause extreme fleet imbalances. Accurate demand prediction enables proactive rebalancing, "
         "minimizing lost rides and dock starvation."),
        
        ("Chapter 2: Problem Statement",
         "Commuter demand fluctuates unpredictably due to rush hour vs weekend dynamics and weather conditions. "
         "Dock starvation at morning transit hubs and dock saturation during evening returns result in commuter dissatisfaction. "
         "This project builds an automated predictive analytics engine to forecast hourly demand accurately."),
        
        ("Chapter 3: Objectives",
         "1. Ingest raw UCI hour.csv (17,379 records) and verify zero missing/duplicate values.<br/>"
         "2. Strictly eliminate target leakage (casual and registered columns).<br/>"
         "3. Uncover multicollinearity between temp and atemp (r = 0.988) and drop atemp.<br/>"
         "4. Implement cyclical trigonometric sine/cosine encoding for hour, month, and weekday.<br/>"
         "5. Benchmark Linear Regression vs Random Forest using chronological 80/20 train/test split.<br/>"
         "6. Deploy an interactive 5-page Streamlit web dashboard for real-time predictions."),

        ("Chapter 4: Dataset Description",
         "The dataset from the UCI Machine Learning Repository covers Capital Bikeshare logs in Washington D.C. (2011–2012). "
         "It includes 17,379 hourly observations across calendar and meteorological attributes."),

        ("Chapter 5: Dataset Collection",
         "Dataset was downloaded from the official UCI archive (archive.ics.uci.edu) and validated locally in dataset/hour.csv. "
         "Data integrity audits confirmed 17,379 unique observations with 0 missing values."),

        ("Chapter 6: Methodology & Architecture",
         "Follows CRISP-DM methodology: Data Ingestion -> Preprocessing -> EDA -> Cyclical Feature Engineering -> Model Building -> Model Evaluation -> Streamlit Deployment."),

        ("Chapter 7: Data Preprocessing & Leakage Elimination",
         "Dropping instant, casual, and registered eliminated target leakage and reduced memory usage by 23.1%. "
         "The resulting dataset/cleaned_data.csv retains 14 clean attributes."),

        ("Chapter 8: Exploratory Data Analysis (EDA)",
         "EDA established that target cnt is right-skewed (+1.28) with high kurtosis (+1.42). "
         "Hourly demand is bimodal on working days (peaks at 8 AM and 5-6 PM) and unimodal on weekends. "
         "Temperature has the highest positive correlation (+0.405) while humidity has the highest negative correlation (-0.323)."),

        ("Chapter 9: Data Visualization",
         "13 high-resolution 300-DPI charts were generated in reports/graphs/ depicting target distribution, hourly patterns, seasonal trends, and correlation heatmaps."),

        ("Chapter 10: Feature Engineering",
         "Engineered 23 model-ready features: hr_sin, hr_cos, mnth_sin, mnth_cos, weekday_sin, weekday_cos, is_rush_hour, temp_hum_ratio, one-hot encoded season and weathersit, and standard-scaled continuous variables."),

        ("Chapter 11: Machine Learning Model Development",
         "Model 1 (Linear Regression): Baseline Ordinary Least Squares parametric estimator.<br/>"
         "Model 2 (Random Forest Regressor): Non-linear ensemble model with 150 bagged decision trees, max_depth=18, max_features='sqrt'."),

        ("Chapter 12: Model Evaluation and Performance Analysis",
         "Evaluated on 3,476 unseen test records (August–December 2012):<br/>"
         "• Linear Regression: MAE = 102.36 | RMSE = 135.70 | R² = 0.6212<br/>"
         "• Random Forest Regressor: MAE = 65.73 | RMSE = 96.75 | R² = 0.8075<br/>"
         "Random Forest achieved a 35.8% reduction in MAE and an 18.6 percentage point gain in R²."),

        ("Chapter 13: Results and Discussion",
         "Random Forest's decision tree ensembles naturally capture multi-way threshold interactions (rush hour + temperature + working day) "
         "that a fixed linear plane cannot model, eliminating large peak underpredictions."),

        ("Chapter 14: Application Demonstration (Streamlit)",
         "A 5-page responsive Streamlit web dashboard (app.py) was built. Features include real-time prediction sliders, model comparison metrics, interactive EDA charts, and fleet rebalancing advisory alerts."),

        ("Chapter 15: Conclusion",
         "The system provides robust predictive capability for bike-sharing operators, confirmed by empirical test evaluation and reproducible software engineering standards."),

        ("Chapter 16: Future Scope",
         "Deep learning LSTM sequence forecasting, live OpenWeatherMap API integration, and station-level GIS dynamic routing for rebalancing trucks."),

        ("Chapter 17: References",
         "[1] Fanaee-T & Gama (2013), Progress in Artificial Intelligence.<br/>"
         "[2] Breiman, L. (2001), Random Forests, Machine Learning.<br/>"
         "[3] Pedregosa et al. (2011), Scikit-learn.<br/>"
         "[4] Streamlit Documentation (2026).")
    ]

    for title, text in chapters:
        story.append(Paragraph(title, style_h1))
        story.append(Paragraph(text, style_body))
        story.append(Spacer(1, 6))

    # Add Evaluation Table
    story.append(Spacer(1, 10))
    story.append(Paragraph("<b>Table: Empirical Test Evaluation Benchmarks</b>", style_body))
    table_data = [
        ["Model", "Test MAE", "Test RMSE", "Test R²", "Status"],
        ["Linear Regression", "102.36", "135.70", "0.6212", "Baseline"],
        ["Random Forest", "65.73", "96.75", "0.8075", "Champion"],
        ["Improvement", "↓ 35.8%", "↓ 28.7%", "↑ +18.6%", "Dominant"]
    ]
    t_perf = Table(table_data, colWidths=[130, 85, 85, 85, 95])
    t_perf.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1E3A8A')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 8.5),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#D1D5DB')),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#F3F4F6')]),
    ]))
    story.append(t_perf)
    story.append(Spacer(1, 14))

    # Embed figures in PDF
    key_figs = [
        (os.path.join(GRAPHS_DIR, "02_hourly_rentals.png"), "Figure 1: Hourly Bike Rental Demand Patterns (Workdays vs Weekends)"),
        (os.path.join(RESULTS_DIR, "model_performance_comparison.png"), "Figure 2: Model Performance Benchmarking (MAE, RMSE, R2)"),
        (os.path.join(RESULTS_DIR, "actual_vs_predicted.png"), "Figure 3: Actual vs Predicted Demand against Ideal Line (y = x)"),
        (os.path.join(GRAPHS_DIR, "17_streamlit_app_interface.png"), "Figure 4: Streamlit Web Dashboard User Interface Architecture")
    ]

    for fpath, cap in key_figs:
        if os.path.exists(fpath):
            story.append(KeepTogether([
                RLImage(fpath, width=480, height=260),
                Paragraph(cap, style_cap),
                Spacer(1, 10)
            ]))

    doc.build(story, canvasmaker=NumberedCanvas)
    print(f"PDF Document Successfully Saved: {pdf_path}")
    return pdf_path


if __name__ == "__main__":
    docx_file = build_docx_report()
    pdf_file = build_pdf_report()
    print("\nReport Generation Complete!")
    print(f"  • Word Document : {docx_file}")
    print(f"  • PDF Document  : {pdf_file}")
