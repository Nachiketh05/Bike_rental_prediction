@echo off
echo ========================================================
echo  CycleCast AI: Pushing Repository to GitHub
echo  Target: https://github.com/Nachiketh05/Bike_Rental_Prediction.git
echo ========================================================
git push -u origin main
echo.
if %ERRORLEVEL% EQU 0 (
    echo ========================================================
    echo  SUCCESS! Pushed to https://github.com/Nachiketh05/Bike_Rental_Prediction
    echo ========================================================
) else (
    echo ========================================================
    echo  Push encountered an issue. See message above.
    echo ========================================================
)
pause
