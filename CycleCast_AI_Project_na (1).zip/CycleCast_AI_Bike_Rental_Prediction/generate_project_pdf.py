"""
Script: generate_project_pdf.py
Description:
    Generates a comprehensive, professional, multi-page publication-grade PDF
    explaining the working procedure, technical architecture, data pipeline,
    experimental results, and operation of CycleCast AI (Bike Rental Demand Prediction System).
"""

import os
import sys
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image as RLImage, PageBreak, KeepTogether, HRFlowable
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.pdfgen import canvas

BASE_DIR = r"c:\Users\Asus\Documents\Desktop\Bike_Rental_Prediction"
REPORTS_DIR = os.path.join(BASE_DIR, "reports")
GRAPHS_DIR = os.path.join(REPORTS_DIR, "graphs")
RESULTS_DIR = os.path.join(REPORTS_DIR, "model_results")
PDF_PATH_REPORTS = os.path.join(REPORTS_DIR, "CycleCast_AI_Project_Documentation_and_Working_Procedure.pdf")
PDF_PATH_ROOT = os.path.join(BASE_DIR, "CycleCast_AI_Project_Documentation_and_Working_Procedure.pdf")

class ProfessionalNumberedCanvas(canvas.Canvas):
    """
    Two-pass canvas to dynamically compute and draw total page counts,
    along with running running headers and footers.
    """
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._saved_page_states = []

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        num_pages = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self.draw_header_footer(num_pages)
            super().showPage()
        super().save()

    def draw_header_footer(self, page_count):
        # Do not draw on the cover page
        if self._pageNumber > 1:
            self.saveState()
            
            # Header
            self.setFont("Helvetica", 8.5)
            self.setFillColor(colors.HexColor("#4B5563"))
            self.drawString(54, letter[1] - 36, "CycleCast AI — Technical Documentation & Working Procedure")
            self.drawRightString(letter[0] - 54, letter[1] - 36, "Machine Learning System Guide")
            self.setStrokeColor(colors.HexColor("#D1D5DB"))
            self.setLineWidth(0.6)
            self.line(54, letter[1] - 42, letter[0] - 54, letter[1] - 42)
            
            # Footer
            self.setFont("Helvetica", 8.5)
            self.setFillColor(colors.HexColor("#4B5563"))
            self.drawString(54, 34, "Confidential & Academic Technical Documentation")
            self.drawRightString(letter[0] - 54, 34, f"Page {self._pageNumber} of {page_count}")
            self.setStrokeColor(colors.HexColor("#D1D5DB"))
            self.setLineWidth(0.6)
            self.line(54, 46, letter[0] - 54, 46)
            
            self.restoreState()


def build_pdf():
    print("Building Project Documentation & Working Procedure PDF...")
    
    doc = SimpleDocTemplate(
        PDF_PATH_REPORTS,
        pagesize=letter,
        leftMargin=54,
        rightMargin=54,
        topMargin=54,
        bottomMargin=54
    )

    styles = getSampleStyleSheet()

    # Typography & Styles
    c_primary = colors.HexColor("#1E3A8A")     # Deep Royal Navy
    c_secondary = colors.HexColor("#2563EB")   # Bright Blue
    c_dark = colors.HexColor("#1F2937")        # Dark Gray for text
    c_muted = colors.HexColor("#4B5563")       # Slate Gray
    c_accent = colors.HexColor("#0D9488")      # Teal Accent
    c_bg_light = colors.HexColor("#F8FAFC")    # Background light slate

    style_cover_badge = ParagraphStyle(
        "CoverBadge", parent=styles["Normal"],
        fontName="Helvetica-Bold", fontSize=11, leading=14,
        textColor=colors.white, alignment=1
    )
    style_cover_title = ParagraphStyle(
        "CoverTitle", parent=styles["Normal"],
        fontName="Helvetica-Bold", fontSize=25, leading=30,
        textColor=c_primary, alignment=1, spaceAfter=8
    )
    style_cover_sub = ParagraphStyle(
        "CoverSub", parent=styles["Normal"],
        fontName="Helvetica", fontSize=12, leading=16,
        textColor=c_secondary, alignment=1, spaceAfter=25
    )
    style_cover_desc = ParagraphStyle(
        "CoverDesc", parent=styles["Normal"],
        fontName="Helvetica", fontSize=10, leading=14.5,
        textColor=c_muted, alignment=1, spaceAfter=35
    )
    style_h1 = ParagraphStyle(
        "H1_Custom", parent=styles["Heading1"],
        fontName="Helvetica-Bold", fontSize=15, leading=19,
        textColor=c_primary, spaceBefore=16, spaceAfter=8,
        keepWithNext=True
    )
    style_h2 = ParagraphStyle(
        "H2_Custom", parent=styles["Heading2"],
        fontName="Helvetica-Bold", fontSize=11.5, leading=15,
        textColor=c_secondary, spaceBefore=10, spaceAfter=4,
        keepWithNext=True
    )
    style_body = ParagraphStyle(
        "Body_Custom", parent=styles["Normal"],
        fontName="Helvetica", fontSize=9.2, leading=13.5,
        textColor=c_dark, spaceAfter=6
    )
    style_bullet = ParagraphStyle(
        "Bullet_Custom", parent=styles["Normal"],
        fontName="Helvetica", fontSize=9.2, leading=13.5,
        textColor=c_dark, leftIndent=15, firstLineIndent=-10, spaceAfter=4
    )
    style_caption = ParagraphStyle(
        "Caption_Custom", parent=styles["Normal"],
        fontName="Helvetica-Oblique", fontSize=8.2, leading=11,
        textColor=c_muted, alignment=1, spaceAfter=10
    )
    style_callout = ParagraphStyle(
        "Callout_Custom", parent=styles["Normal"],
        fontName="Helvetica", fontSize=9, leading=13,
        textColor=colors.HexColor("#0F172A")
    )
    style_code = ParagraphStyle(
        "Code_Custom", parent=styles["Normal"],
        fontName="Courier", fontSize=8.2, leading=11,
        textColor=colors.HexColor("#0F172A")
    )

    story = []

    # =========================================================================
    # COVER PAGE
    # =========================================================================
    story.append(Spacer(1, 40))
    
    # Badge Box
    badge_data = [[Paragraph("🚲 SMART MOBILITY & PREDICTIVE ANALYTICS SYSTEM", style_cover_badge)]]
    t_badge = Table(badge_data, colWidths=[380])
    t_badge.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), c_secondary),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('TOPPADDING', (0, 0), (-1, -1), 6),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
        ('CORNERPAD', (0, 0), (-1, -1), 10),
    ]))
    story.append(t_badge)
    story.append(Spacer(1, 24))

    story.append(Paragraph("CycleCast AI", style_cover_title))
    story.append(Paragraph("Bike Rental Demand Prediction System", style_cover_sub))
    story.append(Paragraph(
        "Comprehensive Technical Architecture, End-to-End Working Procedure,<br/>"
        "Machine Learning Pipeline & Operational Guide",
        style_cover_desc
    ))

    # AI Hero Image on Cover
    hero_station_img = os.path.join(GRAPHS_DIR, "ai_smart_bike_station.jpg")
    if os.path.exists(hero_station_img):
        story.append(KeepTogether([
            RLImage(hero_station_img, width=470, height=195),
            Paragraph("Automated Smart Bike-Sharing Station Infrastructure & Commuter Network", style_caption),
            Spacer(1, 10)
        ]))

    # Executive Metadata Summary Table
    meta_info = [
        [Paragraph("<b>System Name:</b>", style_body), Paragraph("CycleCast AI", style_body)],
        [Paragraph("<b>Domain:</b>", style_body), Paragraph("Predictive Analytics, Urban Smart Mobility, Machine Learning", style_body)],
        [Paragraph("<b>Dataset Source:</b>", style_body), Paragraph("UCI Machine Learning Repository (Capital Bikeshare 2011–2012, 17,379 Records)", style_body)],
        [Paragraph("<b>Champion Model:</b>", style_body), Paragraph("Random Forest Regressor (R²: 0.8075 | MAE: 65.73 bikes/hour)", style_body)],
        [Paragraph("<b>Baseline Model:</b>", style_body), Paragraph("Linear Regression (R²: 0.6212 | MAE: 102.36 bikes/hour)", style_body)],
        [Paragraph("<b>Deployment Stack:</b>", style_body), Paragraph("Streamlit Dashboard, Scikit-learn, Pandas, NumPy, Joblib, Matplotlib", style_body)],
        [Paragraph("<b>Test Strategy:</b>", style_body), Paragraph("Strict Chronological 80/20 Train/Test Split (Zero Lookahead Bias)", style_body)],
    ]
    t_meta = Table(meta_info, colWidths=[140, 360])
    t_meta.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#F1F5F9')),
        ('BOX', (0, 0), (-1, -1), 1, colors.HexColor('#CBD5E1')),
        ('INNERGRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#E2E8F0')),
        ('TOPPADDING', (0, 0), (-1, -1), 4),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
        ('LEFTPADDING', (0, 0), (-1, -1), 10),
        ('RIGHTPADDING', (0, 0), (-1, -1), 10),
    ]))
    story.append(t_meta)

    story.append(PageBreak())

    # =========================================================================
    # SECTION 1: EXECUTIVE PROJECT OVERVIEW
    # =========================================================================
    story.append(Paragraph("1. Executive Project Overview & Business Motivation", style_h1))
    story.append(Paragraph(
        "Modern bike-sharing networks (BSS) are automated, sensor-enabled public transportation systems that play a "
        "pivotal role in reducing carbon footprints, alleviating traffic congestion, and solving the 'first-mile / last-mile' "
        "transit dilemma. In an automated station network, users pick up a bicycle from one dock and return it at any other dock across the metropolitan grid.",
        style_body
    ))
    story.append(Paragraph(
        "<b>The Operational Challenge:</b> Because bike rentals and returns are completely decentralized, severe demand imbalances "
        "arise throughout the day. During morning peak hours (07:00–09:00), residential docks experience <i>starvation</i> (bikes run out), "
        "while commercial district docks experience <i>saturation</i> (no docks available to park returned bikes). In the evening peak hours "
        "(17:00–19:00), the flow reverses. Furthermore, sudden shifts in meteorological conditions—such as thunderstorms, extreme cold, or "
        "heatwaves—dramatically suppress demand.",
        style_body
    ))

    # AI Fleet Operations Image
    fleet_img = os.path.join(GRAPHS_DIR, "ai_fleet_operations.jpg")
    if os.path.exists(fleet_img):
        story.append(KeepTogether([
            RLImage(fleet_img, width=470, height=190),
            Paragraph("Figure 1: High-Tech Mobility Fleet Operations Control Room — Real-Time Dock Telemetry & Dynamic Truck Rebalancing Routes", style_caption),
            Spacer(1, 6)
        ]))

    story.append(Paragraph(
        "<b>The Solution (CycleCast AI):</b> CycleCast AI addresses this critical urban logistical dilemma by deploying an end-to-end "
        "machine learning engine that forecasts total hourly bike demand (<code>cnt</code>). By anticipating rental surges 1 to 24 hours "
        "ahead, fleet operations teams can strategically dispatch rebalancing vans, pre-position reserve bikes at transit hubs, and optimize "
        "dock maintenance schedules.",
        style_body
    ))

    # Key Objectives Callout Box
    obj_box_data = [[
        Paragraph(
            "<b>Key System Objectives:</b><br/>"
            "• <b>Zero Target Leakage:</b> Strictly eliminate component counts (<code>casual</code> and <code>registered</code>) to safeguard production reliability.<br/>"
            "• <b>Cyclical Time Rhythms:</b> Transform hours, weekdays, and months using trigonometric sine/cosine projections.<br/>"
            "• <b>Collinearity Elimination:</b> Diagnose and resolve extreme collinearity between temperature and feeling temperature (<i>r = 0.988</i>).<br/>"
            "• <b>Chronological Validation:</b> Prevent future data leakage by training on the first 80% chronologically and testing on unseen future timestamps.<br/>"
            "• <b>Interactive Deployment:</b> Deliver an executive-level Streamlit web dashboard with real-time scenario simulation.",
            style_callout
        )
    ]]
    t_obj = Table(obj_box_data, colWidths=[500])
    t_obj.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#EFF6FF')),
        ('BOX', (0, 0), (-1, -1), 1.2, colors.HexColor('#3B82F6')),
        ('TOPPADDING', (0, 0), (-1, -1), 8),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
        ('LEFTPADDING', (0, 0), (-1, -1), 12),
        ('RIGHTPADDING', (0, 0), (-1, -1), 12),
    ]))
    story.append(Spacer(1, 4))
    story.append(t_obj)
    story.append(Spacer(1, 10))

    # =========================================================================
    # SECTION 2: DATASET ARCHITECTURE & AUDIT
    # =========================================================================
    story.append(Paragraph("2. Dataset Architecture & Ingestion Integrity", style_h1))
    story.append(Paragraph(
        "The project utilizes the benchmark Bike Sharing Dataset from the UCI Machine Learning Repository, "
        "compiled from historical transaction logs of the Capital Bikeshare system in Washington D.C., USA, "
        "spanning two full calendar years (January 1, 2011 to December 31, 2012).",
        style_body
    ))
    
    ds_features = [
        ["Attribute", "Type", "Range / Values", "Operational Role & Engineering Description"],
        ["instant", "Integer", "1 to 17,379", "Row sequence index; removed to prevent artificial trend memorization."],
        ["dteday", "Date", "2011-01-01 to 2012-12-31", "Timestamp; parsed into datetime index for chronological ordering."],
        ["season", "Categorical", "1:Spring, 2:Summer, 3:Fall, 4:Winter", "Macro weather cycle; one-hot encoded for model consumption."],
        ["yr", "Binary", "0:2011, 1:2012", "Annual growth factor; captures overall network adoption surge."],
        ["mnth", "Categorical", "1 to 12", "Calendar month; engineered with cyclical trigonometric encoding."],
        ["hr", "Categorical", "0 to 23", "Hour of day; paramount feature for commuter rush-hour peaks."],
        ["holiday", "Binary", "0:No, 1:Yes", "Official public holiday; suppresses business commuter demand."],
        ["weekday", "Categorical", "0:Sunday to 6:Saturday", "Weekly cycle; differentiates commute vs leisure behavior."],
        ["workingday", "Binary", "0:Weekend/Holiday, 1:Workday", "Key discriminator of bimodal vs unimodal demand curves."],
        ["weathersit", "Categorical", "1:Clear, 2:Mist/Cloudy, 3:Rain/Snow", "Precipitation severity; heavy negative impact on ridership."],
        ["temp", "Continuous", "0.02 to 1.00 (Normalized)", "Ambient normalized temperature in Celsius (t_max = 41°C)."],
        ["atemp", "Continuous", "0.00 to 1.00 (Normalized)", "Feeling temperature (dropped due to r = 0.988 collinearity with temp)."],
        ["hum", "Continuous", "0.00 to 1.00 (Normalized)", "Relative humidity; high humidity dampens leisure riding."],
        ["windspeed", "Continuous", "0.00 to 0.85 (Normalized)", "Wind speed; strong gusts suppress commuter confidence."],
        ["casual", "Target Leaker", "0 to 367", "Unregistered walk-up rides (EXCLUDED: casual + registered = cnt)."],
        ["registered", "Target Leaker", "0 to 886", "Subscribed pass-holder rides (EXCLUDED: casual + registered = cnt)."],
        ["cnt", "Target Variable", "1 to 977 (mean: 189.5)", "Ground-truth total hourly bike rental volume to be predicted."]
    ]
    t_ds = Table(ds_features, colWidths=[70, 65, 115, 250])
    t_ds.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), c_primary),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 7.5),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#CBD5E1')),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#F8FAFC')]),
        ('TOPPADDING', (0, 0), (-1, -1), 3),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
    ]))
    story.append(t_ds)
    story.append(Spacer(1, 12))

    # Data Leakage Warning Box
    leak_data = [[
        Paragraph(
            "<b>Critical Engineering Safeguard — Target Leakage Prevention:</b><br/>"
            "In many naive implementations, developers inadvertently keep <code>casual</code> and <code>registered</code> in the "
            "feature matrix. Since total count <code>cnt = casual + registered</code> identically, any algorithm trained on them simply "
            "learns trivial arithmetic addition, achieving an artificial 100% R² score that completely fails in real production. "
            "CycleCast AI strictly audits and purges both columns at the very first step of ingestion.",
            style_callout
        )
    ]]
    t_leak = Table(leak_data, colWidths=[500])
    t_leak.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#FEF2F2')),
        ('BOX', (0, 0), (-1, -1), 1.2, colors.HexColor('#EF4444')),
        ('TOPPADDING', (0, 0), (-1, -1), 7),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 7),
        ('LEFTPADDING', (0, 0), (-1, -1), 12),
        ('RIGHTPADDING', (0, 0), (-1, -1), 12),
    ]))
    story.append(t_leak)
    story.append(Spacer(1, 12))

    # AI Weather & Environmental Telemetry Visual
    weather_img = os.path.join(GRAPHS_DIR, "ai_weather_mobility.jpg")
    if os.path.exists(weather_img):
        story.append(KeepTogether([
            RLImage(weather_img, width=470, height=190),
            Paragraph("Figure 2: Real-World IoT Environmental Sensor Monitoring — Tracking Ambient Weather Telemetry & Cyclist Ridership Flow", style_caption),
            Spacer(1, 6)
        ]))

    story.append(PageBreak())

    # =========================================================================
    # SECTION 3: STEP-BY-STEP WORKING PROCEDURE
    # =========================================================================
    story.append(Paragraph("3. Step-by-Step Technical Working Procedure", style_h1))
    story.append(Paragraph(
        "The complete execution pipeline is organized into six interconnected, modular steps following industry CRISP-DM methodology. "
        "Each stage executes deterministic transformations and verifies mathematical checkpoints.",
        style_body
    ))

    # System Architecture Flowchart
    wf_path = os.path.join(GRAPHS_DIR, "18_project_workflow.png")
    if os.path.exists(wf_path):
        story.append(KeepTogether([
            RLImage(wf_path, width=470, height=160),
            Paragraph("Figure 3: System Architecture & Sequential Pipeline Flowchart (CRISP-DM)", style_caption),
            Spacer(1, 8)
        ]))

    # Pipeline Step 1
    story.append(Paragraph("Step 1: Data Ingestion & Sanitization (<code>src/data_preprocessing.py</code>)", style_h2))
    story.append(Paragraph(
        "• <b>File Ingestion:</b> Loads raw dataset from <code>dataset/hour.csv</code> containing 17,379 observations across 17 attributes.<br/>"
        "• <b>Integrity Verification:</b> Asserts that no missing values (NaN) or duplicate rows exist across the dataframe.<br/>"
        "• <b>Leakage Elimination:</b> Drops the surrogate identifier <code>instant</code> and the components <code>casual</code> and <code>registered</code>.<br/>"
        "• <b>Output Persistence:</b> Saves the sanitized dataset to <code>dataset/cleaned_data.csv</code> (14 columns, 17,379 rows), reducing memory overhead by 23.1%.",
        style_bullet
    ))
    story.append(Spacer(1, 4))

    # Pipeline Step 2
    story.append(Paragraph("Step 2: Exploratory Data Analysis & Statistical Profiling (<code>src/eda.py</code>)", style_h2))
    story.append(Paragraph(
        "• <b>Distribution Analysis:</b> The target variable <code>cnt</code> has a mean of 189.5, median of 142.0, standard deviation of 181.4, "
        "positive skewness of +1.28 (right-tailed), and kurtosis of +1.42.<br/>"
        "• <b>Temporal Rhythm Profiling:</b> Discovers that working day demand is <i>bimodal</i> (peaks at 08:00 with ~360 bikes/hr and 17:00–18:00 with ~490 bikes/hr), "
        "whereas weekend demand is <i>unimodal</i> (broad peak from 12:00 to 16:00 with ~380 bikes/hr).<br/>"
        "• <b>Collinearity Diagnosis:</b> Computes the Pearson correlation matrix. Identifies severe multicollinearity between <code>temp</code> "
        "and <code>atemp</code> (<i>r = 0.9877</i>). To prevent inflated variance in linear coefficients, <code>atemp</code> is discarded.<br/>"
        "• <b>Meteorological Impact:</b> Confirms positive correlation with <code>temp</code> (<i>r = +0.405</i>) and negative correlation with <code>hum</code> (<i>r = -0.323</i>).",
        style_bullet
    ))
    story.append(Spacer(1, 4))

    # Pipeline Step 3
    story.append(Paragraph("Step 3: Feature Engineering & Preprocessing (<code>src/feature_engineering.py</code>)", style_h2))
    story.append(Paragraph(
        "Standard machine learning models treat numerical hours (0 to 23) as a continuous ordinal scale, falsely assuming that hour 23 and hour 0 "
        "are at opposite mathematical extremes (distance = 23). In reality, hour 23 is immediately adjacent to hour 0 (distance = 1 hour).",
        style_body
    ))
    story.append(Paragraph(
        "• <b>Trigonometric Cyclical Encoding:</b> Time variables are mapped onto a 2D unit circle using sine and cosine transformations:<br/>"
        "&nbsp;&nbsp;&nbsp;&nbsp;<i>x_sin = sin(2 * π * t / T)</i> &nbsp;&nbsp;&nbsp;&nbsp; <i>x_cos = cos(2 * π * t / T)</i><br/>"
        "&nbsp;&nbsp;&nbsp;&nbsp;Applied to: Hour (<i>T=24</i>), Month (<i>T=12</i>), and Weekday (<i>T=7</i>). Guaranteed property: <i>sin² + cos² = 1</i>.<br/>"
        "• <b>Domain Specific Indicators:</b> Creates <code>is_rush_hour</code> flag (1 for working days during 07:00–09:00 and 16:00–19:00), "
        "and a non-linear interaction term <code>temp_hum_ratio = temp / (hum + 0.01)</code>.<br/>"
        "• <b>One-Hot Encoding:</b> Transforms nominal categories (<code>season</code> and <code>weathersit</code>) into dummy binary vectors.<br/>"
        "• <b>Strict Chronological 80/20 Train-Test Split:</b> Unlike random k-fold splits which cause future lookahead leakage in time-series, "
        "data is split chronologically: Train set = First 13,903 rows (Jan 1, 2011 to Aug 7, 2012); Test set = Remaining 3,476 rows (Aug 7, 2012 to Dec 31, 2012).<br/>"
        "• <b>Standard Scaling:</b> Continuous numerical features are standardized via <i>Z = (X - μ) / σ</i>. The fitted scaler is serialized to <code>models/preprocessor.pkl</code>.",
        style_bullet
    ))

    story.append(Spacer(1, 6))
    hourly_plot = os.path.join(GRAPHS_DIR, "02_hourly_rentals.png")
    if os.path.exists(hourly_plot):
        story.append(KeepTogether([
            RLImage(hourly_plot, width=470, height=210),
            Paragraph("Figure 4: Distinct Hourly Demand Rhythms — Working Days (Bimodal) vs Non-Working Days (Unimodal)", style_caption)
        ]))

    story.append(PageBreak())

    # Pipeline Step 4
    story.append(Paragraph("Step 4: Model Development & Architecture (<code>src/train_model.py</code>)", style_h2))
    story.append(Paragraph(
        "Two distinct paradigms of supervised regression were developed and trained against the 23 engineered features in <code>X_train</code>:",
        style_body
    ))
    story.append(Paragraph(
        "1. <b>Baseline Model — Ordinary Least Squares (OLS) Linear Regression:</b><br/>"
        "&nbsp;&nbsp;&nbsp;&nbsp;Fits an optimal linear hyperplane: <i>ŷ = β_0 + β_1 X_1 + ... + β_p X_p</i> by minimizing residual sum of squares (RSS). "
        "Serves as the empirical benchmark to evaluate whether non-linear ensemble modeling is justified.<br/>"
        "2. <b>Champion Model — Random Forest Regressor (Ensemble Bagging):</b><br/>"
        "&nbsp;&nbsp;&nbsp;&nbsp;An ensemble of 150 randomized decision trees operating via Bootstrap Aggregating (Bagging). Hyperparameters: "
        "<code>n_estimators=150</code>, <code>max_depth=18</code>, <code>min_samples_split=4</code>, <code>max_features='sqrt'</code>, <code>random_state=42</code>. "
        "Ensemble averaging dramatically lowers variance and captures intricate high-order feature threshold interactions (e.g. rush-hour + pleasant temperature).",
        style_body
    ))
    story.append(Spacer(1, 4))

    # Pipeline Step 5
    story.append(Paragraph("Step 5: Model Evaluation & Benchmarking (<code>src/evaluate_model.py</code>)", style_h2))
    story.append(Paragraph(
        "Models were rigorously benchmarked on the 3,476 unseen chronological test timestamps using three industry standard evaluation metrics:",
        style_body
    ))
    story.append(Paragraph(
        "• <b>Mean Absolute Error (MAE):</b> Average magnitude of errors in raw physical units (bikes/hour):<br/>"
        "&nbsp;&nbsp;&nbsp;&nbsp;<i>MAE = (1 / n) * Σ |y_i - ŷ_i|</i><br/>"
        "• <b>Root Mean Squared Error (RMSE):</b> Penalizes large errors heavily, essential for detecting severe dock starvation:<br/>"
        "&nbsp;&nbsp;&nbsp;&nbsp;<i>RMSE = sqrt( (1 / n) * Σ (y_i - ŷ_i)² )</i><br/>"
        "• <b>Coefficient of Determination (R²):</b> Proportion of variance in rental demand explained by the model:<br/>"
        "&nbsp;&nbsp;&nbsp;&nbsp;<i>R² = 1 - [ Σ (y_i - ŷ_i)² / Σ (y_i - ȳ)² ]</i>",
        style_body
    ))
    story.append(Spacer(1, 4))

    # Pipeline Step 6
    story.append(Paragraph("Step 6: Real-Time Inference & Deployment (<code>src/predict.py</code> & <code>app.py</code>)", style_h2))
    story.append(Paragraph(
        "• <b>Inference Engine:</b> Accepts ad-hoc user parameters (season, hour, temperature, humidity, etc.), reconstructs the cyclical sine/cosine "
        "coordinates, performs dummy one-hot expansion, loads <code>preprocessor.pkl</code>, and generates real-time predictions.<br/>"
        "• <b>Non-Negativity Post-Processing:</b> Physical rental demand cannot be negative. Enforces <i>ŷ_final = max(0, round(ŷ))</i>.<br/>"
        "• <b>Operational Alert Logic:</b> Evaluates predicted demand against fleet capacity thresholds:<br/>"
        "&nbsp;&nbsp;&nbsp;&nbsp;- <i>Low Demand (&lt; 100 bikes/hr):</i> Scheduled routine maintenance, depot battery charging.<br/>"
        "&nbsp;&nbsp;&nbsp;&nbsp;- <i>Moderate Demand (100–300 bikes/hr):</i> Normal fleet equilibrium, standard operations.<br/>"
        "&nbsp;&nbsp;&nbsp;&nbsp;- <i>High Demand (300–550 bikes/hr):</i> Proactive rebalancing active, buffer stations prepared.<br/>"
        "&nbsp;&nbsp;&nbsp;&nbsp;- <i>Peak Rush Surge (&gt; 550 bikes/hr):</i> Maximum dock starvation alert; emergency dispatch vehicles routed to transit hubs.<br/>"
        "• <b>Streamlit User Interface:</b> A 5-page dashboard featuring real-time interactive sliders, performance charts, and fleet diagnostic telemetry.",
        style_bullet
    ))

    story.append(PageBreak())

    # =========================================================================
    # SECTION 4: EXPERIMENTAL RESULTS & COMPARATIVE BENCHMARKS
    # =========================================================================
    story.append(Paragraph("4. Experimental Results & Performance Benchmarking", style_h1))
    story.append(Paragraph(
        "Evaluation on the chronological test partition (3,476 unseen records from August to December 2012) demonstrates "
        "the definitive superiority of the non-linear Random Forest Regressor over the baseline Linear Regression model:",
        style_body
    ))

    # Performance Table
    perf_table_data = [
        ["Evaluation Metric", "Linear Regression (Baseline)", "Random Forest (Champion)", "Performance Gain / Reduction"],
        ["Mean Absolute Error (MAE)", "102.36 bikes/hour", "65.73 bikes/hour", "35.8% Error Reduction (↓ 36.63)"],
        ["Root Mean Squared Error (RMSE)", "135.70 bikes/hour", "96.75 bikes/hour", "28.7% Error Reduction (↓ 38.95)"],
        ["R² Score (Variance Explained)", "0.6212 (62.1%)", "0.8075 (80.8%)", "+18.63% Variance Gain (↑ +0.1863)"],
        ["Mean Squared Error (MSE)", "18,414.5", "9,360.6", "49.2% Variance Error Reduction"],
        ["Peak Surge Handling", "Underpredicts rush hours", "Accurately captures peaks", "No severe saturation surprises"],
        ["Non-Linearity Modeling", "Fails on threshold interactions", "Excels via decision boundaries", "Robust operational stability"]
    ]
    t_perf_comp = Table(perf_table_data, colWidths=[150, 115, 115, 120])
    t_perf_comp.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), c_primary),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 8),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#CBD5E1')),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#F8FAFC')]),
        ('TOPPADDING', (0, 0), (-1, -1), 5),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
    ]))
    story.append(t_perf_comp)
    story.append(Spacer(1, 10))

    # Embed Performance Comparison and Feature Importance Charts
    comp_fig = os.path.join(RESULTS_DIR, "model_performance_comparison.png")
    feat_fig = os.path.join(RESULTS_DIR, "feature_importance.png")
    
    if os.path.exists(comp_fig):
        story.append(KeepTogether([
            RLImage(comp_fig, width=470, height=200),
            Paragraph("Figure 5: Empirical Performance Benchmarking — Linear Regression vs Random Forest Regressor", style_caption)
        ]))

    if os.path.exists(feat_fig):
        story.append(KeepTogether([
            RLImage(feat_fig, width=470, height=200),
            Paragraph("Figure 6: Feature Importance Analysis (Random Forest Mean Decrease in Impurity)", style_caption)
        ]))

    story.append(PageBreak())

    # =========================================================================
    # SECTION 5: OPERATIONAL GUIDE & HOW TO RUN
    # =========================================================================
    story.append(Paragraph("5. Operational Guide & Reproduction Procedure", style_h1))
    story.append(Paragraph(
        "CycleCast AI is architected for 100% reproducibility. All components can be executed independently or through the "
        "integrated test harness and web dashboard.",
        style_body
    ))

    guide_steps = [
        Paragraph("<b>1. Environment Setup & Dependency Installation:</b><br/>"
                  "Install required Python libraries using the provided requirements specification:<br/>"
                  "<code>pip install -r requirements.txt</code>", style_body),
        Paragraph("<b>2. Running the Complete System Test Suite:</b><br/>"
                  "Executes the automated 15-point audit asserting data loading, leakage elimination, model persistence, and scenario inferences:<br/>"
                  "<code>python test_system_pipeline.py</code>", style_body),
        Paragraph("<b>3. Launching the Interactive Web Dashboard:</b><br/>"
                  "Start the interactive Streamlit user interface in your browser:<br/>"
                  "<code>streamlit run app.py</code> (or double-click <code>run_app.bat</code> on Windows).<br/>"
                  "The application opens at <b>http://localhost:8501</b>.", style_body),
        Paragraph("<b>4. Running Individual Pipeline Modules:</b><br/>"
                  "• Ingest & sanitize data: <code>python src/data_preprocessing.py</code><br/>"
                  "• Generate statistical EDA charts: <code>python src/eda.py</code><br/>"
                  "• Engineer cyclical features: <code>python src/feature_engineering.py</code><br/>"
                  "• Train baseline & champion models: <code>python src/train_model.py</code><br/>"
                  "• Benchmark test evaluation metrics: <code>python src/evaluate_model.py</code>", style_body)
    ]
    for step in guide_steps:
        story.append(step)
        story.append(Spacer(1, 4))

    # Embed Actual vs Predicted Scatter and Web Interface
    actual_fig = os.path.join(RESULTS_DIR, "actual_vs_predicted.png")
    app_fig = os.path.join(GRAPHS_DIR, "17_streamlit_app_interface.png")

    if os.path.exists(actual_fig):
        story.append(KeepTogether([
            RLImage(actual_fig, width=470, height=200),
            Paragraph("Figure 7: Actual vs Predicted Demand Distribution against the Ideal Fit Diagonal (y = x)", style_caption)
        ]))

    if os.path.exists(app_fig):
        story.append(KeepTogether([
            RLImage(app_fig, width=470, height=190),
            Paragraph("Figure 8: CycleCast AI Interactive Streamlit Web Application Dashboard", style_caption)
        ]))

    story.append(PageBreak())

    # =========================================================================
    # SECTION 6: SUMMARY & CONCLUSIONS
    # =========================================================================
    story.append(Paragraph("6. Project Summary & Key Conclusions", style_h1))
    story.append(Paragraph(
        "<b>Summary of Accomplishments:</b><br/>"
        "1. <b>Rigorous Leakage Elimination:</b> Audited and removed <code>casual</code> and <code>registered</code> columns, preventing spurious 100% R² artifacts.<br/>"
        "2. <b>Temporal Continuity Modeling:</b> Resolved angular boundary discontinuities by engineering cyclical trigonometric sine/cosine projections.<br/>"
        "3. <b>Collinearity Management:</b> Successfully identified and resolved the <i>r = 0.988</i> collinearity between <code>temp</code> and <code>atemp</code>.<br/>"
        "4. <b>Superior Champion Performance:</b> Random Forest Regressor achieved an impressive <b>R² of 0.8075</b> and an <b>MAE of 65.73 bikes/hour</b> on strictly unseen future chronological data, outperforming Linear Regression by 35.8% in MAE.<br/>"
        "5. <b>Production-Ready Web Deployment:</b> Delivered a 5-page interactive Streamlit dashboard featuring live demand estimation, operational alerts, and dynamic scenario modeling.",
        style_body
    ))
    story.append(Spacer(1, 10))

    # Sign-off box
    sign_data = [[
        Paragraph(
            "<b>Project Status:</b> Production Ready & Fully Documented<br/>"
            "<b>Champion Model File:</b> <code>models/random_forest.pkl</code> (69.9 MB)<br/>"
            "<b>Preprocessor File:</b> <code>models/preprocessor.pkl</code> (StandardScaler + Feature Meta)<br/>"
            "<b>Generated On:</b> November 2026 | CycleCast AI Technical Suite",
            style_callout
        )
    ]]
    t_sign = Table(sign_data, colWidths=[500])
    t_sign.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#F8FAFC')),
        ('BOX', (0, 0), (-1, -1), 1, colors.HexColor('#64748B')),
        ('TOPPADDING', (0, 0), (-1, -1), 8),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
        ('LEFTPADDING', (0, 0), (-1, -1), 12),
        ('RIGHTPADDING', (0, 0), (-1, -1), 12),
    ]))
    story.append(t_sign)

    doc.build(story, canvasmaker=ProfessionalNumberedCanvas)
    
    # Also save a copy to the root workspace directory
    import shutil
    shutil.copy2(PDF_PATH_REPORTS, PDF_PATH_ROOT)
    print(f"Successfully generated PDF documentation at:\n  - {PDF_PATH_REPORTS}\n  - {PDF_PATH_ROOT}")
    return PDF_PATH_ROOT

if __name__ == "__main__":
    build_pdf()
