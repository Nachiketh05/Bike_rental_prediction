"""
Module: train_model.py
Project: Bike Rental Demand Prediction Using Machine Learning
Institution: Amrita Vishwa Vidyapeetham (BCA Final Year Project)

Description:
    Trains, validates, compares, and serializes the Machine Learning models:
    1. Model 1: Linear Regression (Parametric Baseline Model)
    2. Model 2: Random Forest Regressor (Non-linear Ensemble Model)
    
    Includes:
    - Zero data leakage (Strict chronological split evaluation)
    - Full metrics benchmarking: MAE, RMSE, R² Score on both Train and Test splits
    - Feature importance extraction for Random Forest
    - Model serialization to 'models/' directory
    - Simple-language conceptual explanation for BCA viva voce presentation
"""

import os
import sys
import json
import joblib
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, root_mean_squared_error, r2_score

# Ensure root directory is on python path
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from src.feature_engineering import run_feature_engineering_pipeline, PROCESSED_DIR, MODELS_DIR

RESULTS_DIR = os.path.join(BASE_DIR, "reports", "model_results")
os.makedirs(RESULTS_DIR, exist_ok=True)
os.makedirs(MODELS_DIR, exist_ok=True)


def load_train_test_data() -> tuple[pd.DataFrame, pd.DataFrame, pd.Series, pd.Series]:
    """
    Loads preprocessed feature and target matrices.
    If not already generated, automatically executes feature engineering pipeline.
    """
    x_tr_path = os.path.join(PROCESSED_DIR, "X_train.csv")
    x_te_path = os.path.join(PROCESSED_DIR, "X_test.csv")
    y_tr_path = os.path.join(PROCESSED_DIR, "y_train.csv")
    y_te_path = os.path.join(PROCESSED_DIR, "y_test.csv")

    if not all(os.path.exists(p) for p in [x_tr_path, x_te_path, y_tr_path, y_te_path]):
        print("Processed datasets not found. Running feature engineering pipeline first...")
        run_feature_engineering_pipeline()

    X_train = pd.read_csv(x_tr_path)
    X_test = pd.read_csv(x_te_path)
    y_train = pd.read_csv(y_tr_path).squeeze("columns")
    y_test = pd.read_csv(y_te_path).squeeze("columns")

    return X_train, X_test, y_train, y_test


def compute_regression_metrics(y_true: pd.Series, y_pred: np.ndarray) -> dict:
    """
    Computes standard academic regression evaluation metrics:
    - MAE: Mean Absolute Error
    - RMSE: Root Mean Squared Error
    - R²: Coefficient of Determination
    """
    # Enforce non-negative predictions since bike rental demand cannot be negative physically
    y_pred_clipped = np.clip(y_pred, a_min=0, a_max=None)
    
    mae = mean_absolute_error(y_true, y_pred_clipped)
    rmse = root_mean_squared_error(y_true, y_pred_clipped)
    r2 = r2_score(y_true, y_pred_clipped)

    return {
        "MAE": round(mae, 2),
        "RMSE": round(rmse, 2),
        "R2": round(r2, 4)
    }


def train_linear_regression(X_train: pd.DataFrame, y_train: pd.Series) -> LinearRegression:
    """
    Trains standard Ordinary Least Squares Linear Regression.
    """
    print("Training Model 1: Linear Regression (Baseline)...")
    lr = LinearRegression()
    lr.fit(X_train, y_train)
    return lr


def train_random_forest(
    X_train: pd.DataFrame, 
    y_train: pd.Series, 
    n_estimators: int = 150, 
    max_depth: int = 18,
    random_state: int = 42
) -> RandomForestRegressor:
    """
    Trains Random Forest Regressor using ensemble bagging of decision trees.
    """
    print(f"Training Model 2: Random Forest Regressor (n_estimators={n_estimators}, max_depth={max_depth})...")
    rf = RandomForestRegressor(
        n_estimators=n_estimators,
        max_depth=max_depth,
        min_samples_split=4,
        min_samples_leaf=2,
        max_features='sqrt',
        random_state=random_state,
        n_jobs=-1
    )
    rf.fit(X_train, y_train)
    return rf


def save_trained_models(models: dict, output_dir: str = MODELS_DIR) -> dict:
    """
    Serializes trained model objects into models/ directory using joblib with compression
    to ensure file sizes stay well below GitHub's 25MB limit.
    """
    saved_paths = {}
    for name, model in models.items():
        filename = f"{name.lower().replace(' ', '_')}.pkl"
        path = os.path.join(output_dir, filename)
        joblib.dump(model, path, compress=9)
        saved_paths[name] = path
        print(f"  * Model saved (compressed): {name} -> {path}")

    # Also save standard alias 'random_forest.pkl' for convenience
    if "Random Forest Regressor" in models:
        rf_alias_path = os.path.join(output_dir, "random_forest.pkl")
        joblib.dump(models["Random Forest Regressor"], rf_alias_path, compress=9)
        print(f"  * Model alias saved (compressed): random_forest.pkl -> {rf_alias_path}")

    return saved_paths


def evaluate_models(
    models: dict, 
    X_train: pd.DataFrame, 
    y_train: pd.Series, 
    X_test: pd.DataFrame, 
    y_test: pd.Series
) -> tuple[pd.DataFrame, dict]:
    """
    Generates predictions on both train and test splits, calculates metrics,
    and constructs a comprehensive comparative summary table.
    """
    records = []
    predictions_dict = {}

    for name, model in models.items():
        train_preds = model.predict(X_train)
        test_preds = model.predict(X_test)

        train_metrics = compute_regression_metrics(y_train, train_preds)
        test_metrics = compute_regression_metrics(y_test, test_preds)

        predictions_dict[name] = {
            "train_preds": np.clip(train_preds, a_min=0, a_max=None),
            "test_preds": np.clip(test_preds, a_min=0, a_max=None)
        }

        records.append({
            "Model": name,
            "Train MAE": train_metrics["MAE"],
            "Test MAE": test_metrics["MAE"],
            "Train RMSE": train_metrics["RMSE"],
            "Test RMSE": test_metrics["RMSE"],
            "Train R²": train_metrics["R2"],
            "Test R²": test_metrics["R2"]
        })

    comparison_df = pd.DataFrame(records)
    return comparison_df, predictions_dict


def explain_algorithms_simple_language():
    """
    Provides clear, conceptual explanations of both algorithms for viva voce presentation.
    """
    print("\n" + "=" * 80)
    print("      CONCEPTUAL EXPLANATION OF MACHINE LEARNING ALGORITHMS (FOR VIVA)")
    print("=" * 80)

    print("""
1. LINEAR REGRESSION (Baseline Parametric Algorithm):
   -------------------------------------------------
   - Core Concept: Assumes that the target variable (cnt) has a straight-line (linear) 
     relationship with the input features:
         cnt = b0 + b1*(temp) + b2*(hum) + b3*(hr) + ... + error
   - Working Mechanism: Uses Ordinary Least Squares (OLS) to find best-fit coefficients (b) 
     that minimize the sum of squared differences (errors) between actual and predicted demand.
   - Strengths: Highly interpretable; provides direct mathematical coefficients; ultra-fast.
   - Weakness: Cannot naturally capture non-linear relationships, such as rush-hour spikes 
     or the combined impact of high temperature and high humidity.

2. RANDOM FOREST REGRESSOR (Ensemble Non-Linear Algorithm):
   --------------------------------------------------------
   - Core Concept: An ensemble learning algorithm that combines predictions from multiple 
     individual Decision Trees through 'Bagging' (Bootstrap Aggregation).
   - Working Mechanism:
     1. Creates many random subsets of the training data with replacement (bootstrap samples).
     2. Builds a separate decision tree on each subset, splitting nodes on a random subset 
        of features to ensure diversity.
     3. For a new observation, passes inputs through all trees and calculates the average 
        prediction across the entire forest.
   - Strengths: Captures complex non-linear interactions; resistant to outliers; does not 
     overfit easily; accurately learns peak commute demand thresholds.
   - Result: Significantly outperforms Linear Regression on real-world demand prediction.
""")
    print("=" * 80)


def train_and_evaluate_all():
    """
    Main execution pipeline for model development.
    """
    print("\n" + "=" * 80)
    print("          MACHINE LEARNING MODEL TRAINING & COMPARISON PIPELINE")
    print("=" * 80)

    # 1. Load Data
    X_train, X_test, y_train, y_test = load_train_test_data()
    print(f"Loaded Processed Data:")
    print(f"  • X_train: {X_train.shape}, y_train: {y_train.shape}")
    print(f"  • X_test : {X_test.shape}, y_test : {y_test.shape}\n")

    # 2. Train Models
    lr_model = train_linear_regression(X_train, y_train)
    rf_model = train_random_forest(X_train, y_train, n_estimators=150, max_depth=18, random_state=42)

    models = {
        "Linear Regression": lr_model,
        "Random Forest Regressor": rf_model
    }

    # 3. Evaluate Models
    print("\n" + "-" * 80)
    print("EVALUATION & BENCHMARKING (Strict Chronological Test Set)")
    print("-" * 80)
    comparison_df, predictions = evaluate_models(models, X_train, y_train, X_test, y_test)
    print(comparison_df.to_string(index=False))

    # 4. Save Models & Results
    print("\n" + "-" * 80)
    print("SAVING MODEL ARTIFACTS & EVALUATION METRICS")
    print("-" * 80)
    save_trained_models(models, MODELS_DIR)

    # Save comparison table
    metrics_csv_path = os.path.join(RESULTS_DIR, "model_comparison_metrics.csv")
    comparison_df.to_csv(metrics_csv_path, index=False)
    print(f"  * Comparative metrics saved: {metrics_csv_path}")

    # Save detailed JSON for Streamlit UI
    metrics_json_path = os.path.join(RESULTS_DIR, "model_metrics.json")
    metrics_dict = comparison_df.set_index("Model").to_dict(orient="index")
    with open(metrics_json_path, "w") as f:
        json.dump(metrics_dict, f, indent=4)
    print(f"  * JSON metrics saved: {metrics_json_path}")

    # 5. Extract & Save Feature Importances for Random Forest
    rf_importances = pd.DataFrame({
        "Feature": X_train.columns,
        "Importance": rf_model.feature_importances_
    }).sort_values(by="Importance", ascending=False)
    
    importance_path = os.path.join(RESULTS_DIR, "random_forest_feature_importance.csv")
    rf_importances.to_csv(importance_path, index=False)
    print(f"  * Random Forest Feature Importances saved: {importance_path}")

    print("\nTop 7 Most Important Features (Random Forest):")
    print(rf_importances.head(7).to_string(index=False))

    # 6. Conceptual Viva Explanation
    explain_algorithms_simple_language()

    return models, comparison_df


if __name__ == "__main__":
    train_and_evaluate_all()
