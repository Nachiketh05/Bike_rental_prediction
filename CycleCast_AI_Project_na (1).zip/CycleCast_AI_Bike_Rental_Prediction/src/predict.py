"""
Module: predict.py
Project: Bike Rental Demand Prediction Using Machine Learning
Institution: Amrita Vishwa Vidyapeetham (BCA Final Year Project)

Description:
    Provides the inference engine to load trained models and preprocessing artifacts,
    transform raw user inputs, and output predicted hourly bike rental demand.
"""

import os
import sys
import joblib
import numpy as np
import pandas as pd

# Ensure root directory is on python path
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from src.feature_engineering import transform_new_samples, MODELS_DIR


def get_model_path(model_name: str = "Random Forest Regressor") -> str:
    """
    Resolves the serialized model file path for the chosen algorithm.
    """
    if "linear" in model_name.lower():
        return os.path.join(MODELS_DIR, "linear_regression.pkl")
    else:
        # Default to Random Forest
        rf_path = os.path.join(MODELS_DIR, "random_forest_regressor.pkl")
        if not os.path.exists(rf_path):
            rf_path = os.path.join(MODELS_DIR, "random_forest.pkl")
        return rf_path


def load_model(model_name: str = "Random Forest Regressor"):
    """
    Loads and caches the requested trained model.
    """
    path = get_model_path(model_name)
    if not os.path.exists(path):
        raise FileNotFoundError(f"Model file not found at {path}. Please run train_model.py first.")
    return joblib.load(path)


def predict_bike_demand(input_data: dict | pd.DataFrame, model_name: str = "Random Forest Regressor") -> dict:
    """
    Generates hourly bike rental predictions from raw user inputs.
    
    Parameters:
        input_data (dict | pd.DataFrame): Raw feature values (season, yr, mnth, hr, holiday,
                                          weekday, workingday, weathersit, temp, hum, windspeed).
        model_name (str): 'Random Forest Regressor' or 'Linear Regression'.
        
    Returns:
        dict: Prediction metrics including raw count, rounded count, and demand category.
    """
    if isinstance(input_data, dict):
        df_raw = pd.DataFrame([input_data])
    else:
        df_raw = input_data.copy()

    # Preprocess and scale features using saved pipeline
    X_processed = transform_new_samples(df_raw)

    # Load model and predict
    model = load_model(model_name)
    raw_pred = model.predict(X_processed)[0]

    # Physical constraint: Demand cannot be negative
    clamped_pred = max(0.0, float(raw_pred))
    rounded_pred = int(round(clamped_pred))

    # Determine qualitative demand level
    if rounded_pred < 50:
        category = "Low Demand"
        badge_color = "#3498db"
    elif rounded_pred < 250:
        category = "Moderate Demand"
        badge_color = "#2ecc71"
    elif rounded_pred < 500:
        category = "High Demand"
        badge_color = "#f39c12"
    else:
        category = "Peak Rush Surge"
        badge_color = "#e74c3c"

    return {
        "model_used": model_name,
        "prediction_raw": round(clamped_pred, 2),
        "prediction_rounded": rounded_pred,
        "demand_category": category,
        "badge_color": badge_color
    }


if __name__ == "__main__":
    print("Testing Prediction Engine...")
    test_sample = {
        "season": 3,        # Fall
        "yr": 1,            # 2012
        "mnth": 9,          # September
        "hr": 17,           # 5 PM (Evening Rush Hour)
        "holiday": 0,       # No holiday
        "weekday": 4,       # Thursday
        "workingday": 1,    # Working day
        "weathersit": 1,    # Clear weather
        "temp": 0.65,       # ~26.6°C
        "atemp": 0.62,
        "hum": 0.45,        # 45% humidity
        "windspeed": 0.15   # ~10 km/h
    }

    rf_result = predict_bike_demand(test_sample, "Random Forest Regressor")
    lr_result = predict_bike_demand(test_sample, "Linear Regression")

    print("\n[Input Conditions]: Thursday, 5:00 PM, Working Day, Clear Weather, 26.6°C")
    print(f"Random Forest Prediction : {rf_result['prediction_rounded']} bikes/hour ({rf_result['demand_category']})")
    print(f"Linear Regression Prediction: {lr_result['prediction_rounded']} bikes/hour ({lr_result['demand_category']})")
