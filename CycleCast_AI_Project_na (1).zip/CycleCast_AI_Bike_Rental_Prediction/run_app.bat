@echo off
echo ========================================================
echo  Bike Rental Demand Prediction System
echo  Amrita Vishwa Vidyapeetham - BCA Final Year Project
echo ========================================================
echo Starting Streamlit Web Application...
streamlit run app.py
pause
