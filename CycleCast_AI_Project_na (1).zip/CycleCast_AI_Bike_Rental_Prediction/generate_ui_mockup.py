"""
Generates an illustrative UI Architecture and Workflow infographic
for Chapter 14: Application Demonstration.
"""

import os
import matplotlib.pyplot as plt
import matplotlib.patches as patches

OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "reports", "graphs")
os.makedirs(OUTPUT_DIR, exist_ok=True)

fig, ax = plt.subplots(figsize=(12, 7.5), dpi=300)
ax.set_xlim(0, 12)
ax.set_ylim(0, 8)
ax.axis("off")

# Title Bar
rect_top = patches.FancyBboxPatch((0.5, 7.0), 11, 0.8, boxstyle="round,pad=0.1", ec="#1E3A8A", fc="#1E3A8A")
ax.add_patch(rect_top)
ax.text(6.0, 7.4, "Streamlit Web Dashboard: Bike Rental Demand Prediction System", color="white", fontsize=13, fontweight="bold", ha="center", va="center")

# Sidebar Mockup
rect_side = patches.FancyBboxPatch((0.5, 0.5), 2.8, 6.2, boxstyle="round,pad=0.1", ec="#D1D5DB", fc="#F3F4F6")
ax.add_patch(rect_side)
ax.text(1.9, 6.3, "Navigation Menu", fontsize=11, fontweight="bold", ha="center", color="#111827")
nav_items = ["Home Page", "Predict Demand", "Model Comparison", "Data Visualizations", "About Project"]
for i, item in enumerate(nav_items):
    bg_col = "#DBEAFE" if i == 1 else "white"
    txt_col = "#1E40AF" if i == 1 else "#374151"
    rect_item = patches.FancyBboxPatch((0.7, 5.4 - i * 0.9), 2.4, 0.65, boxstyle="round,pad=0.05", ec="#93C5FD" if i == 1 else "#E5E7EB", fc=bg_col)
    ax.add_patch(rect_item)
    ax.text(1.9, 5.72 - i * 0.9, item, fontsize=9.5, fontweight="bold" if i == 1 else "normal", ha="center", va="center", color=txt_col)

# Main Screen Mockup
rect_main = patches.FancyBboxPatch((3.6, 0.5), 7.9, 6.2, boxstyle="round,pad=0.1", ec="#D1D5DB", fc="white")
ax.add_patch(rect_main)

# Screen Title
ax.text(7.55, 6.3, "Real-Time Bike Demand Prediction Panel", fontsize=12, fontweight="bold", ha="center", color="#1E3A8A")

# Input Columns
rect_c1 = patches.FancyBboxPatch((3.8, 2.6), 3.6, 3.4, boxstyle="round,pad=0.08", ec="#E5E7EB", fc="#F9FAFB")
ax.add_patch(rect_c1)
ax.text(5.6, 5.7, "Temporal Inputs", fontsize=10, fontweight="bold", ha="center", color="#374151")
ax.text(5.6, 5.2, "- Season: Fall (3)\n- Year: 2012 (Adoption)\n- Month: September (9)\n- Hour Slider: 17:00 (5 PM)\n- Day: Thursday (4)\n- Working Day: Yes (1)", fontsize=8.5, ha="center", va="top", color="#4B5563")

rect_c2 = patches.FancyBboxPatch((7.7, 2.6), 3.6, 3.4, boxstyle="round,pad=0.08", ec="#E5E7EB", fc="#F9FAFB")
ax.add_patch(rect_c2)
ax.text(9.5, 5.7, "Weather Inputs", fontsize=10, fontweight="bold", ha="center", color="#374151")
ax.text(9.5, 5.2, "- Weather: Clear / Few Clouds\n- Temperature: 26.5 C\n- Feels Like: 28.0 C\n- Humidity Slider: 45 %\n- Wind Speed: 12 km/h\n- Model: Random Forest", fontsize=8.5, ha="center", va="top", color="#4B5563")

# Prediction Output Box
rect_out = patches.FancyBboxPatch((4.2, 0.7), 6.7, 1.6, boxstyle="round,pad=0.1", ec="#3B82F6", fc="#EFF6FF")
ax.add_patch(rect_out)
ax.text(7.55, 1.9, "Predicted Hourly Demand", fontsize=10, fontweight="bold", ha="center", color="#1E3A8A")
ax.text(7.55, 1.45, "710 bikes / hour", fontsize=18, fontweight="black", ha="center", color="#1D4ED8")
rect_badge = patches.FancyBboxPatch((6.3, 0.85), 2.5, 0.35, boxstyle="round,pad=0.05", ec="#DC2626", fc="#EF4444")
ax.add_patch(rect_badge)
ax.text(7.55, 1.02, "● Peak Rush Surge", fontsize=8.5, fontweight="bold", ha="center", color="white")

out_path = os.path.join(OUTPUT_DIR, "17_streamlit_app_interface.png")
fig.savefig(out_path, bbox_inches="tight", dpi=300)
plt.close(fig)
print(f"Generated UI Infographic: {out_path}")
