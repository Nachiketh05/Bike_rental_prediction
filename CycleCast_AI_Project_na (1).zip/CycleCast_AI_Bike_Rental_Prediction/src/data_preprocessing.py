"""
Module: data_preprocessing.py
Project: Bike Rental Demand Prediction Using Machine Learning
Institution: Amrita Vishwa Vidyapeetham (BCA Final Year Project)

Description:
    Implements the end-to-end data preprocessing pipeline:
    1. Ingests raw 'hour.csv' dataset.
    2. Audits and handles missing values.
    3. Detects and removes duplicate records.
    4. Converts date fields into standard datetime format.
    5. Classifies categorical and numerical feature sets.
    6. Eliminates uninformative features ('instant').
    7. Eliminates target leakage columns ('casual', 'registered').
    8. Preserves the target variable ('cnt').
    9. Exports the cleaned dataset as 'dataset/cleaned_data.csv'.
    10. Produces a clear before-and-after comparison summary.
"""

import os
import zipfile
import urllib.request
import pandas as pd


# Directory & Path Constants
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATASET_DIR = os.path.join(BASE_DIR, "dataset")
RAW_DATA_PATH = os.path.join(DATASET_DIR, "hour.csv")
CLEANED_DATA_PATH = os.path.join(DATASET_DIR, "cleaned_data.csv")
DATASET_URL = "https://archive.ics.uci.edu/static/public/275/bike+sharing+dataset.zip"


def download_and_extract_dataset(url: str = DATASET_URL, target_dir: str = DATASET_DIR) -> str:
    """
    Downloads and unpacks the official UCI Bike Sharing Dataset archive if not already present.
    """
    os.makedirs(target_dir, exist_ok=True)
    hour_csv_path = os.path.join(target_dir, "hour.csv")
    zip_path = os.path.join(target_dir, "bike_sharing_dataset.zip")

    if not os.path.exists(hour_csv_path) or os.path.getsize(hour_csv_path) == 0:
        print(f"Downloading dataset from:\n  {url}")
        headers = {'User-Agent': 'Mozilla/5.0'}
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req) as resp, open(zip_path, 'wb') as out_f:
            out_f.write(resp.read())

        with zipfile.ZipFile(zip_path, 'r') as zf:
            for member in ["hour.csv", "day.csv", "Readme.txt"]:
                if member in zf.namelist():
                    zf.extract(member, target_dir)

        if os.path.exists(zip_path):
            os.remove(zip_path)
        print("Dataset extracted successfully.")

    return hour_csv_path


def load_raw_data(filepath: str = RAW_DATA_PATH) -> pd.DataFrame:
    """
    Loads the raw hour.csv dataset into a pandas DataFrame without modifying the source file.
    
    Parameters:
        filepath (str): Path to hour.csv.
        
    Returns:
        pd.DataFrame: Raw dataset.
    """
    if not os.path.exists(filepath) or os.path.getsize(filepath) == 0:
        download_and_extract_dataset(target_dir=os.path.dirname(filepath))
    
    df = pd.read_csv(filepath)
    return df


def audit_missing_values(df: pd.DataFrame) -> pd.Series:
    """
    Identifies count and percentage of missing values per column.
    """
    missing_counts = df.isnull().sum()
    return missing_counts


def handle_missing_values(df: pd.DataFrame) -> pd.DataFrame:
    """
    Handles missing values if any exist:
    - Numerical features: Imputed using median strategy.
    - Categorical features: Imputed using mode strategy.
    """
    df_clean = df.copy()
    if df_clean.isnull().sum().sum() > 0:
        num_cols = df_clean.select_dtypes(include=['float64', 'int64']).columns
        cat_cols = df_clean.select_dtypes(include=['object']).columns

        for col in num_cols:
            if df_clean[col].isnull().sum() > 0:
                df_clean[col] = df_clean[col].fillna(df_clean[col].median())

        for col in cat_cols:
            if df_clean[col].isnull().sum() > 0:
                df_clean[col] = df_clean[col].fillna(df_clean[col].mode()[0])
    return df_clean


def check_and_remove_duplicates(df: pd.DataFrame) -> tuple[pd.DataFrame, int]:
    """
    Checks for duplicate rows and removes them if present.
    
    Returns:
        tuple[pd.DataFrame, int]: Deduplicated DataFrame and the count of dropped duplicates.
    """
    df_clean = df.copy()
    initial_count = len(df_clean)
    duplicate_count = df_clean.duplicated().sum()
    if duplicate_count > 0:
        df_clean = df_clean.drop_duplicates().reset_index(drop=True)
    return df_clean, int(duplicate_count)


def convert_date_column(df: pd.DataFrame, date_col: str = "dteday") -> pd.DataFrame:
    """
    Converts the date string column into standard pandas datetime format.
    """
    df_clean = df.copy()
    if date_col in df_clean.columns:
        df_clean[date_col] = pd.to_datetime(df_clean[date_col], format="%Y-%m-%d")
    return df_clean


def classify_features(df: pd.DataFrame) -> dict:
    """
    Categorizes the dataset features into categorical, continuous numerical, 
    datetime, target, and excluded leakage features.
    """
    feature_meta = {
        "datetime": ["dteday"] if "dteday" in df.columns else [],
        "categorical": ["season", "yr", "mnth", "hr", "holiday", "weekday", "workingday", "weathersit"],
        "numerical": ["temp", "atemp", "hum", "windspeed"],
        "leakage": ["casual", "registered"],
        "identifier": ["instant"],
        "target": ["cnt"]
    }
    return feature_meta


def remove_irrelevant_and_leakage_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Drops:
    1. 'instant': Arbitrary serial row index that has no predictive value.
    2. 'casual' and 'registered': Direct sub-components of target 'cnt' (cnt = casual + registered).
       Retaining these causes severe data leakage where the model trivially sums them.
       
    Retains:
    - 'cnt': The true prediction target.
    - Weather & calendar attributes for predictive modeling.
    - 'dteday': Retained in cleaned_data.csv for time-based EDA reference.
    """
    df_clean = df.copy()
    columns_to_drop = [col for col in ["instant", "casual", "registered"] if col in df_clean.columns]
    df_clean = df_clean.drop(columns=columns_to_drop)
    return df_clean


def save_cleaned_dataset(df: pd.DataFrame, output_path: str = CLEANED_DATA_PATH) -> str:
    """
    Saves the cleaned DataFrame to CSV format.
    """
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    df.to_csv(output_path, index=False)
    return output_path


def preprocess_data(raw_csv_path: str = RAW_DATA_PATH, output_csv_path: str = CLEANED_DATA_PATH) -> tuple[pd.DataFrame, dict, dict]:
    """
    Orchestrates the entire preprocessing pipeline:
    - Ingests raw data.
    - Audits missing and duplicate values.
    - Converts datetime.
    - Removes irrelevant/leakage columns.
    - Retains target variable.
    - Saves cleaned dataset.
    
    Returns:
        tuple: (cleaned_df, before_stats, after_stats)
    """
    # 1. Load raw data
    raw_df = load_raw_data(raw_csv_path)

    # Compute Before Stats
    before_stats = {
        "shape": raw_df.shape,
        "columns": list(raw_df.columns),
        "missing_values": int(raw_df.isnull().sum().sum()),
        "duplicate_rows": int(raw_df.duplicated().sum()),
        "dtypes": raw_df.dtypes.to_dict(),
        "memory_mb": round(raw_df.memory_usage(deep=True).sum() / (1024 * 1024), 2)
    }

    # 2. Audit & handle missing values
    cleaned_df = handle_missing_values(raw_df)

    # 3. Check & remove duplicates
    cleaned_df, dropped_dups = check_and_remove_duplicates(cleaned_df)

    # 4. Convert date column
    cleaned_df = convert_date_column(cleaned_df, date_col="dteday")

    # 5. Remove irrelevant features & leakage features
    cleaned_df = remove_irrelevant_and_leakage_features(cleaned_df)

    # Compute After Stats
    after_stats = {
        "shape": cleaned_df.shape,
        "columns": list(cleaned_df.columns),
        "missing_values": int(cleaned_df.isnull().sum().sum()),
        "duplicate_rows": int(cleaned_df.duplicated().sum()),
        "dtypes": cleaned_df.dtypes.to_dict(),
        "memory_mb": round(cleaned_df.memory_usage(deep=True).sum() / (1024 * 1024), 2),
        "dropped_columns": [col for col in before_stats["columns"] if col not in cleaned_df.columns],
        "target_variable": "cnt"
    }

    # 6. Save cleaned dataset
    save_cleaned_dataset(cleaned_df, output_csv_path)

    return cleaned_df, before_stats, after_stats


def display_before_after_summary(before: dict, after: dict):
    """
    Formats and prints a detailed before-and-after summary table.
    """
    print("\n" + "=" * 75)
    print("           DATA PREPROCESSING: BEFORE VS. AFTER COMPARISON")
    print("=" * 75)

    comparison_data = [
        ("Number of Rows", f"{before['shape'][0]:,}", f"{after['shape'][0]:,}", "Preserved all valid rows"),
        ("Number of Columns", f"{before['shape'][1]}", f"{after['shape'][1]}", f"Dropped {len(after['dropped_columns'])} irrelevant/leakage cols"),
        ("Missing Values (NaN)", f"{before['missing_values']}", f"{after['missing_values']}", "Zero missing values"),
        ("Duplicate Records", f"{before['duplicate_rows']}", f"{after['duplicate_rows']}", "Zero duplicates"),
        ("Memory Footprint", f"{before['memory_mb']} MB", f"{after['memory_mb']} MB", "Optimized memory usage"),
        ("Target Variable", "cnt", "cnt", "Kept as primary prediction target")
    ]

    col_w = [25, 15, 15, 30]
    header = f"{'Metric':<{col_w[0]}} | {'Before':<{col_w[1]}} | {'After':<{col_w[2]}} | {'Remarks':<{col_w[3]}}"
    print(header)
    print("-" * len(header))
    for row in comparison_data:
        print(f"{row[0]:<{col_w[0]}} | {row[1]:<{col_w[1]}} | {row[2]:<{col_w[2]}} | {row[3]:<{col_w[3]}}")
    print("-" * len(header))

    print("\n[Dropped Columns Details]:")
    print("  • 'instant'    : Arbitrary row serial index (no predictive signal).")
    print("  • 'casual'     : Excluded to prevent target leakage (cnt = casual + registered).")
    print("  • 'registered' : Excluded to prevent target leakage (cnt = casual + registered).")

    print("\n[Retained Cleaned Features]:")
    print("  • Datetime     : dteday (standardized datetime64[ns])")
    print("  • Categorical  : season, yr, mnth, hr, holiday, weekday, workingday, weathersit")
    print("  • Numerical    : temp, atemp, hum, windspeed")
    print("  • Target ($y$) : cnt (hourly bike rental demand)")
    print("=" * 75)


if __name__ == "__main__":
    print("Running Data Preprocessing Pipeline...")
    cleaned_df, before_stats, after_stats = preprocess_data()
    display_before_after_summary(before_stats, after_stats)
    print(f"\nCleaned dataset saved successfully to:\n  {CLEANED_DATA_PATH}")
    print("\nFirst 5 rows of cleaned dataset:")
    print(cleaned_df.head(5).to_string())
