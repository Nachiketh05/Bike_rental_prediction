"""
Script: create_presentation.py
Project: Bike Rental Demand Prediction Using Machine Learning
Institution: Amrita Vishwa Vidyapeetham - BCA Final Year Major Project

Creates: Bike_Rental_Prediction_Presentation.pptx
Includes:
- 16:9 Widescreen modern layout
- 15 academic presentation slides
- Embedded project graphs and workflow diagrams
- Tables with actual verified metrics
- Comprehensive speaker notes for viva defense
"""

import os
import sys
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import pptx
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
GRAPHS_DIR = os.path.join(BASE_DIR, "reports", "graphs")
RESULTS_DIR = os.path.join(BASE_DIR, "reports", "model_results")
PPTX_PATH = os.path.join(BASE_DIR, "Bike_Rental_Prediction_Presentation.pptx")


def generate_workflow_diagram():
    """Generates an aesthetic project workflow diagram for Slide 7."""
    fig, ax = plt.subplots(figsize=(12, 4.5), dpi=300)
    ax.set_xlim(0, 12)
    ax.set_ylim(0, 5)
    ax.axis("off")

    stages = [
        ("1. Data Ingestion", "UCI hour.csv\n17,379 Records", "#1E3A8A"),
        ("2. Preprocessing", "Leakage Removal\n(casual, reg dropped)", "#2563EB"),
        ("3. EDA & Insights", "Skewness +1.28\nr(temp, atemp)=0.99", "#3B82F6"),
        ("4. Feature Eng.", "Cyclical Encoding\nChronological Split", "#0D9488"),
        ("5. Model Training", "Linear Reg. vs\nRandom Forest", "#16A34A"),
        ("6. Web Deployment", "Streamlit App\nLive Predictions", "#8B0000"),
    ]

    for i, (title, desc, col) in enumerate(stages):
        x = 0.3 + i * 1.95
        # Box
        rect = patches.FancyBboxPatch((x, 1.2), 1.65, 2.6, boxstyle="round,pad=0.1", ec="none", fc=col)
        ax.add_patch(rect)
        # Title
        ax.text(x + 0.825, 3.2, title, color="white", fontsize=10, fontweight="bold", ha="center")
        # Description
        ax.text(x + 0.825, 2.1, desc, color="#F8FAFC", fontsize=8.5, ha="center", va="center")

        # Arrow
        if i < len(stages) - 1:
            ax.annotate("", xy=(x + 1.95, 2.5), xytext=(x + 1.68, 2.5),
                        arrowprops=dict(arrowstyle="->", lw=2.5, color="#64748B"))

    out_path = os.path.join(GRAPHS_DIR, "18_project_workflow.png")
    fig.savefig(out_path, bbox_inches="tight", dpi=300)
    plt.close(fig)
    print(f"Generated Workflow Infographic: {out_path}")
    return out_path


def apply_slide_header(slide, title_text, category_text="AMRITA VISHWA VIDYAPEETHAM | BCA FINAL YEAR PROJECT"):
    """Creates a consistent header across slides."""
    # Top banner line
    shapes = slide.shapes
    rect = shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(13.33), Inches(0.12))
    rect.fill.solid()
    rect.fill.fore_color.rgb = RGBColor(139, 0, 0) # Amrita Maroon
    rect.line.color.rgb = RGBColor(139, 0, 0)

    # Category / Super-title
    cat_box = shapes.add_textbox(Inches(0.8), Inches(0.35), Inches(11.5), Inches(0.4))
    tf_c = cat_box.text_frame
    tf_c.word_wrap = True
    p_c = tf_c.paragraphs[0]
    p_c.text = category_text.upper()
    p_c.font.size = Pt(10)
    p_c.font.bold = True
    p_c.font.color.rgb = RGBColor(100, 116, 139)

    # Main Title
    title_box = shapes.add_textbox(Inches(0.8), Inches(0.65), Inches(11.5), Inches(0.8))
    tf_t = title_box.text_frame
    tf_t.word_wrap = True
    p_t = tf_t.paragraphs[0]
    p_t.text = title_text
    p_t.font.size = Pt(22)
    p_t.font.bold = True
    p_t.font.color.rgb = RGBColor(30, 58, 138) # Deep Navy


def add_bullet_points(tf, points, font_size=13, space_after=10):
    """Populates text frames with clean bullet points."""
    for i, pt in enumerate(points):
        if i == 0 and len(tf.paragraphs) > 0:
            p = tf.paragraphs[0]
        else:
            p = tf.add_paragraph()
        p.text = pt
        p.font.size = Pt(font_size)
        p.font.color.rgb = RGBColor(31, 41, 55)
        p.space_after = Pt(space_after)
        p.level = 0


def set_speaker_notes(slide, notes_text):
    """Attaches spoken explanation for viva defense."""
    notes_slide = slide.notes_slide
    text_frame = notes_slide.notes_text_frame
    text_frame.text = notes_text


def build_presentation():
    print("Building 15-Slide Academic PowerPoint Presentation...")
    generate_workflow_diagram()

    prs = Presentation()
    prs.slide_width = Inches(13.333) # 16:9 Widescreen
    prs.slide_height = Inches(7.5)
    blank_layout = prs.slide_layouts[6]

    # =========================================================
    # SLIDE 1: TITLE SLIDE
    # =========================================================
    s1 = prs.slides.add_slide(blank_layout)
    # Background accent
    bg_rect = s1.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(13.333), Inches(7.5))
    bg_rect.fill.solid()
    bg_rect.fill.fore_color.rgb = RGBColor(248, 250, 252)
    bg_rect.line.fill.background()

    # Maroon Top Accent Bar
    top_bar = s1.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(13.333), Inches(0.2))
    top_bar.fill.solid()
    top_bar.fill.fore_color.rgb = RGBColor(139, 0, 0)
    top_bar.line.fill.background()

    # Title Box
    tb1 = s1.shapes.add_textbox(Inches(1.0), Inches(1.5), Inches(11.333), Inches(3.5))
    tf1 = tb1.text_frame
    tf1.word_wrap = True
    
    p_u = tf1.paragraphs[0]
    p_u.text = "AMRITA VISHWA VIDYAPEETHAM\nDEPARTMENT OF COMPUTER APPLICATIONS"
    p_u.font.size = Pt(14)
    p_u.font.bold = True
    p_u.font.color.rgb = RGBColor(139, 0, 0)
    p_u.space_after = Pt(20)

    p_t = tf1.add_paragraph()
    p_t.text = "Bike Rental Demand Prediction Using Machine Learning"
    p_t.font.size = Pt(30)
    p_t.font.bold = True
    p_t.font.color.rgb = RGBColor(30, 58, 138)
    p_t.space_after = Pt(14)

    p_s = tf1.add_paragraph()
    p_s.text = "BCA Final Year Major Project | Predictive Analytics & Smart Urban Mobility"
    p_s.font.size = Pt(15)
    p_s.font.color.rgb = RGBColor(75, 85, 99)

    # Footer Card
    card1 = s1.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(1.0), Inches(5.2), Inches(11.333), Inches(1.4))
    card1.fill.solid()
    card1.fill.fore_color.rgb = RGBColor(239, 246, 255)
    card1.line.color.rgb = RGBColor(191, 219, 254)
    tf_c1 = card1.text_frame
    p_c1 = tf_c1.paragraphs[0]
    p_c1.text = "Submitted by: BCA Final Year Student     |     Faculty Guidance: Department of Computer Applications\nAcademic Year: 2026–2027     |     Technology Stack: Python, Scikit-learn, Streamlit"
    p_c1.font.size = Pt(12)
    p_c1.font.bold = True
    p_c1.font.color.rgb = RGBColor(30, 58, 138)
    p_c1.alignment = PP_ALIGN.CENTER

    set_speaker_notes(s1, 
        "Good morning respected evaluators. My name is [Your Name], and I am a final-year BCA student at Amrita Vishwa Vidyapeetham. "
        "Today, I am presenting my final-year project titled 'Bike Rental Demand Prediction Using Machine Learning'. "
        "This project builds an end-to-end predictive analytics system designed to forecast hourly bike-sharing demand accurately "
        "and deploy it into an interactive Streamlit web dashboard.")

    # =========================================================
    # SLIDE 2: INTRODUCTION
    # =========================================================
    s2 = prs.slides.add_slide(blank_layout)
    apply_slide_header(s2, "Introduction to Bike Sharing Systems")

    tb2_left = s2.shapes.add_textbox(Inches(0.8), Inches(1.6), Inches(6.8), Inches(5.2))
    tf2_left = tb2_left.text_frame
    tf2_left.word_wrap = True
    add_bullet_points(tf2_left, [
        "🚲 Micro-Mobility Transformation: Bike sharing is an automated, eco-friendly transit solution operating in over 500 cities globally.",
        "🔄 Point-to-Point Travel: Commuters unlock bikes at one dock station and return them at any other station across the city.",
        "📡 Urban Sensor Networks: Every rental logs time, weather, and usage, transforming the bike fleet into a virtual city mobility sensor.",
        "🎯 Operational Need: Because users travel independently, stations frequently face severe demand imbalances.",
        "💡 AI Opportunity: Machine Learning can anticipate hourly volume by analyzing calendar rhythms and meteorological conditions."
    ], font_size=13.5, space_after=14)

    # Right Card: Quick stats
    card2 = s2.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(8.0), Inches(1.8), Inches(4.5), Inches(4.8))
    card2.fill.solid()
    card2.fill.fore_color.rgb = RGBColor(241, 245, 249)
    card2.line.color.rgb = RGBColor(203, 213, 225)
    tf_c2 = card2.text_frame
    tf_c2.word_wrap = True
    p_c2 = tf_c2.paragraphs[0]
    p_c2.text = "Key Project Drivers\n"
    p_c2.font.size = Pt(16)
    p_c2.font.bold = True
    p_c2.font.color.rgb = RGBColor(30, 58, 138)
    
    drivers = [
        "• 17,379 Hourly Records analyzed over two calendar years (2011–2012).",
        "• Solves dock starvation at morning hubs and dock overflow in evenings.",
        "• Combines weather forecasts with commuter work schedules.",
        "• Replaces guesswork with machine learning intelligence."
    ]
    for d in drivers:
        p = tf_c2.add_paragraph()
        p.text = d
        p.font.size = Pt(12)
        p.font.color.rgb = RGBColor(51, 65, 85)
        p.space_after = Pt(10)

    set_speaker_notes(s2, 
        "To introduce the project: bike-sharing systems allow flexible urban micro-mobility. When commuters rent bikes, "
        "they generate valuable timestamped sensor records. However, because trips are spontaneous, stations empty out or overflow. "
        "By applying machine learning to historical weather and calendar patterns, we can forecast demand hours in advance.")

    # =========================================================
    # SLIDE 3: PROBLEM STATEMENT
    # =========================================================
    s3 = prs.slides.add_slide(blank_layout)
    apply_slide_header(s3, "Problem Statement: The Urban Fleet Dilemma")

    boxes = [
        ("Dock Starvation", "Transit hubs run out of bicycles during morning rush hours (8:00 AM - 9:00 AM). Commuters face delays and loss of trust.", "#DC2626"),
        ("Dock Saturation", "Commercial centers become completely full during evening rush hours (5:00 PM - 6:00 PM), leaving riders unable to park bikes safely.", "#EA580C"),
        ("Weather Volatility", "Sudden precipitation or temperature drops drastically slash ridership, leaving hundreds of bikes unused and depreciating in the rain.", "#2563EB"),
        ("Rebalancing Cost", "Trucks currently rebalance bikes reactively. Proactive predictive analytics saves fuel, human labor, and prevents lost trips.", "#16A34A")
    ]

    for i, (head, desc, col) in enumerate(boxes):
        col_pos = i % 2
        row_pos = i // 2
        x = Inches(0.8 + col_pos * 6.0)
        y = Inches(1.8 + row_pos * 2.6)

        c = s3.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, y, Inches(5.6), Inches(2.2))
        c.fill.solid()
        c.fill.fore_color.rgb = RGBColor(248, 250, 252)
        c.line.color.rgb = RGBColor(226, 232, 240)
        
        # Indicator bar
        bar = s3.shapes.add_shape(MSO_SHAPE.RECTANGLE, x, y, Inches(0.18), Inches(2.2))
        bar.fill.solid()
        bar.fill.fore_color.rgb = RGBColor.from_string(col.replace("#", ""))
        bar.line.fill.background()

        tf = c.text_frame
        tf.word_wrap = True
        p_h = tf.paragraphs[0]
        p_h.text = f"  {head}"
        p_h.font.size = Pt(15)
        p_h.font.bold = True
        p_h.font.color.rgb = RGBColor.from_string(col.replace("#", ""))
        p_h.space_after = Pt(6)

        p_d = tf.add_paragraph()
        p_d.text = f"  {desc}"
        p_d.font.size = Pt(11.5)
        p_d.font.color.rgb = RGBColor(51, 65, 85)

    set_speaker_notes(s3, 
        "Here is the core problem: In cities, bike demand fluctuates sharply. During morning rush hours, residential stations empty out, "
        "causing dock starvation. In the evening, destination stations overflow, leading to dock saturation. Weather also adds severe volatility. "
        "Without predictive analytics, operators rebalance fleets reactively, which wastes operational budget.")

    # =========================================================
    # SLIDE 4: OBJECTIVES
    # =========================================================
    s4 = prs.slides.add_slide(blank_layout)
    apply_slide_header(s4, "Project Objectives & Scope")

    tb4 = s4.shapes.add_textbox(Inches(0.8), Inches(1.6), Inches(11.7), Inches(5.2))
    tf4 = tb4.text_frame
    tf4.word_wrap = True
    add_bullet_points(tf4, [
        "1. Ingest & Audit Official Dataset: Acquire the UCI Bike Sharing hourly dataset (hour.csv, 17,379 observations) and verify 0 missing values.",
        "2. Strict Data Leakage Elimination: Remove target sub-components (casual and registered users) and uninformative indices to ensure model integrity.",
        "3. Exploratory Data Analysis: Discover diurnal commute curves, seasonal peaks, and resolve severe multicollinearity between temp and atemp (r = 0.988).",
        "4. Cyclical Feature Engineering: Map periodic time attributes (hour, month, weekday) onto 2D continuous circles using sine/cosine harmonic transforms.",
        "5. Chronological Model Benchmarking: Train baseline Linear Regression vs ensemble Random Forest Regressor using strict chronological 80/20 splitting.",
        "6. Interactive Web Deployment: Build and deploy a multi-page Streamlit web dashboard for real-time predictions and operational scenario testing."
    ], font_size=13.5, space_after=12)

    set_speaker_notes(s4, 
        "Our project objectives are structured across six key milestones: First, data ingestion and validation. Second, strictly eliminating "
        "target leakage by dropping casual and registered columns. Third, discovering key demand drivers through EDA. Fourth, engineering cyclical "
        "sine and cosine features. Fifth, benchmarking Linear Regression against Random Forest on unseen chronological test data. "
        "Finally, deploying the champion model in an interactive Streamlit application.")

    # =========================================================
    # SLIDE 5: DATASET DESCRIPTION
    # =========================================================
    s5 = prs.slides.add_slide(blank_layout)
    apply_slide_header(s5, "Dataset Description: UCI Bike Sharing Dataset")

    # Left: Details
    tb5_left = s5.shapes.add_textbox(Inches(0.8), Inches(1.6), Inches(5.8), Inches(5.2))
    tf5_left = tb5_left.text_frame
    tf5_left.word_wrap = True
    add_bullet_points(tf5_left, [
        "• Source: UCI Machine Learning Repository (Capital Bikeshare log, Washington D.C., USA).",
        "• Total Records: 17,379 hourly observations spanning 2011 to 2012.",
        "• Attributes: 17 initial raw features encompassing temporal, weather, and rental counts.",
        "• Target Variable: cnt (Total bike rentals per hour, ranging from 1 to 977 bikes/hr).",
        "• Zero Missing Values & Zero Duplicate Records verified across all rows.",
        "• Target Leakage Rule: casual + registered = cnt. Dropping both is mandatory to prevent artificial 100% data leakage."
    ], font_size=12.5, space_after=10)

    # Right: Summary Table
    t_shape5 = s5.shapes.add_table(rows=7, cols=3, left=Inches(7.0), top=Inches(1.8), width=Inches(5.5), height=Inches(4.6))
    table5 = t_shape5.table
    table5.columns[0].width = Inches(1.8)
    table5.columns[1].width = Inches(1.7)
    table5.columns[2].width = Inches(2.0)

    t5_rows = [
        ("Feature Group", "Columns", "Role"),
        ("Calendar / Time", "dteday, yr, mnth, hr, weekday", "Predictor features"),
        ("Work Schedule", "workingday, holiday", "Interaction with hr"),
        ("Weather Index", "weathersit (1 to 4)", "Rain / Snow indicator"),
        ("Meteorology", "temp, atemp, hum, windspeed", "Continuous scaled features"),
        ("Target Components", "casual, registered", "DROPPED (Data Leakage)"),
        ("Target Variable", "cnt", "Dependent Variable (y)")
    ]

    for r_idx, row in enumerate(t5_rows):
        for c_idx, val in enumerate(row):
            cell = table5.cell(r_idx, c_idx)
            cell.text = val
            p = cell.text_frame.paragraphs[0]
            p.font.size = Pt(9.5)
            if r_idx == 0:
                p.font.bold = True
                p.font.color.rgb = RGBColor(255, 255, 255)
                cell.fill.solid()
                cell.fill.fore_color.rgb = RGBColor(30, 58, 138)
            elif r_idx == 5:
                p.font.bold = True
                p.font.color.rgb = RGBColor(185, 28, 28)
                cell.fill.solid()
                cell.fill.fore_color.rgb = RGBColor(254, 226, 226)

    set_speaker_notes(s5, 
        "Moving to our dataset: We used the official UCI Bike Sharing Dataset containing 17,379 hours across 2011 and 2012. "
        "Our target variable is 'cnt', which represents total hourly rentals. "
        "An essential academic observation is that 'cnt' equals casual plus registered users. In a real-world system, "
        "we don't know casual or registered users in advance. Therefore, both were strictly dropped to prevent data leakage.")

    # =========================================================
    # SLIDE 6: TECHNOLOGIES USED
    # =========================================================
    s6 = prs.slides.add_slide(blank_layout)
    apply_slide_header(s6, "Technology Stack & Development Environment")

    tech_cards = [
        ("Python 3.13", "Core programming language for data manipulation, numerical modeling, and inference pipelines.", "#3B82F6"),
        ("Pandas & NumPy", "High-performance dataframes, matrix operations, statistical profiling, and datetime indexing.", "#2563EB"),
        ("Matplotlib & Seaborn", "Generation of publication-quality statistical charts, correlation heatmaps, and diagnostic plots.", "#0D9488"),
        ("Scikit-Learn", "Machine learning algorithms: LinearRegression, RandomForestRegressor, StandardScaler, and metrics.", "#16A34A"),
        ("Joblib", "Efficient serialization and persistence of trained model pipelines and scaler transformations.", "#D97706"),
        ("Streamlit", "Interactive reactive web dashboard framework for user scenario testing and live predictions.", "#DC2626")
    ]

    for i, (name, desc, col) in enumerate(tech_cards):
        col_pos = i % 3
        row_pos = i // 3
        x = Inches(0.8 + col_pos * 4.0)
        y = Inches(1.8 + row_pos * 2.6)

        c = s6.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, y, Inches(3.7), Inches(2.2))
        c.fill.solid()
        c.fill.fore_color.rgb = RGBColor(248, 250, 252)
        c.line.color.rgb = RGBColor(226, 232, 240)

        bar = s6.shapes.add_shape(MSO_SHAPE.RECTANGLE, x, y, Inches(3.7), Inches(0.12))
        bar.fill.solid()
        bar.fill.fore_color.rgb = RGBColor.from_string(col.replace("#", ""))
        bar.line.fill.background()

        tf = c.text_frame
        tf.word_wrap = True
        p_n = tf.paragraphs[0]
        p_n.text = f"\n{name}"
        p_n.font.size = Pt(14)
        p_n.font.bold = True
        p_n.font.color.rgb = RGBColor(30, 58, 138)
        p_n.space_after = Pt(6)

        p_d = tf.add_paragraph()
        p_d.text = desc
        p_d.font.size = Pt(10.5)
        p_d.font.color.rgb = RGBColor(71, 85, 105)

    set_speaker_notes(s6, 
        "Our technology stack is built on Python 3.13. We used Pandas and NumPy for feature processing, Matplotlib and Seaborn "
        "for publication-quality visual diagnostics, Scikit-learn for machine learning estimators and evaluation metrics, "
        "Joblib for pipeline persistence, and Streamlit for web application deployment.")

    # =========================================================
    # SLIDE 7: PROJECT WORKFLOW
    # =========================================================
    s7 = prs.slides.add_slide(blank_layout)
    apply_slide_header(s7, "End-to-End System Workflow Architecture")

    wf_img = os.path.join(GRAPHS_DIR, "18_project_workflow.png")
    if os.path.exists(wf_img):
        s7.shapes.add_picture(wf_img, Inches(0.8), Inches(1.8), width=Inches(11.7))

    tb7 = s7.shapes.add_textbox(Inches(0.8), Inches(5.4), Inches(11.7), Inches(1.6))
    tf7 = tb7.text_frame
    tf7.word_wrap = True
    add_bullet_points(tf7, [
        "• Structured CRISP-DM Architecture: Ingestion → Cleaning → EDA → Feature Engineering → Model Training → Streamlit Deployment.",
        "• Modular Separation: Each layer resides in an independent script in src/ to support software reusability and testing.",
        "• Zero Lookahead Guarantee: Preprocessing scalers fit strictly on training data; models predict chronologically."
    ], font_size=12, space_after=6)

    set_speaker_notes(s7, 
        "This slide presents our complete project workflow architecture. The raw dataset flows through six modular stages: "
        "from ingestion and leakage removal, to exploratory data analysis, cyclical feature engineering, model training, "
        "benchmarking, and finally real-time deployment in Streamlit. Every module is cleanly separated into reusable Python files.")

    # =========================================================
    # SLIDE 8: DATA PREPROCESSING
    # =========================================================
    s8 = prs.slides.add_slide(blank_layout)
    apply_slide_header(s8, "Data Preprocessing & Quality Assurance")

    # Left: Explanation
    tb8 = s8.shapes.add_textbox(Inches(0.8), Inches(1.6), Inches(5.8), Inches(5.2))
    tf8 = tb8.text_frame
    tf8.word_wrap = True
    add_bullet_points(tf8, [
        "1. Leakage Elimination: Dropped casual and registered. Including them yields trivial R² = 1.0, which is invalid in deployment.",
        "2. Irrelevant Column Dropped: Dropped instant (row index) to prevent models memorizing serial positions.",
        "3. Timestamp Standardized: Converted dteday into datetime64[ns] for accurate chronological sorting.",
        "4. Multicollinearity Solved: temp and atemp have r = 0.988. atemp was dropped to eliminate variance inflation.",
        "5. Output Dataset: Saved cleaned_data.csv with 14 verified predictive attributes."
    ], font_size=12.5, space_after=10)

    # Right: Preprocessing Table
    t_shape8 = s8.shapes.add_table(rows=6, cols=3, left=Inches(7.0), top=Inches(1.8), width=Inches(5.5), height=Inches(4.5))
    table8 = t_shape8.table
    table8.columns[0].width = Inches(2.0)
    table8.columns[1].width = Inches(1.7)
    table8.columns[2].width = Inches(1.8)

    t8_rows = [
        ("Audit Metric", "Before Preprocessing", "After Preprocessing"),
        ("Dataset Rows", "17,379", "17,379 (100% retained)"),
        ("Feature Columns", "17 columns", "14 clean columns"),
        ("Missing Values", "0 (0.0%)", "0 (Imputation verified)"),
        ("Duplicate Records", "0 (0.0%)", "0 unique timestamps"),
        ("Memory Footprint", "2.42 MB", "1.86 MB (23.1% reduction)")
    ]

    for r_idx, row in enumerate(t8_rows):
        for c_idx, val in enumerate(row):
            cell = table8.cell(r_idx, c_idx)
            cell.text = val
            p = cell.text_frame.paragraphs[0]
            p.font.size = Pt(10)
            if r_idx == 0:
                p.font.bold = True
                p.font.color.rgb = RGBColor(255, 255, 255)
                cell.fill.solid()
                cell.fill.fore_color.rgb = RGBColor(30, 58, 138)
            elif r_idx % 2 == 1:
                cell.fill.solid()
                cell.fill.fore_color.rgb = RGBColor(241, 245, 249)

    set_speaker_notes(s8, 
        "During preprocessing, our primary focus was data integrity. We removed the 'instant' index and eliminated 'casual' and 'registered' "
        "to prevent target leakage. We also identified severe multicollinearity: actual temperature and feeling temperature have a 98.8% correlation. "
        "To avoid unstable regression coefficients, we dropped feeling temperature.")

    # =========================================================
    # SLIDE 9: EXPLORATORY DATA ANALYSIS
    # =========================================================
    s9 = prs.slides.add_slide(blank_layout)
    apply_slide_header(s9, "Exploratory Data Analysis: Key Findings")

    # Embed 2 key plots: Hourly rentals and target distribution
    p_img9_1 = os.path.join(GRAPHS_DIR, "02_hourly_rentals.png")
    p_img9_2 = os.path.join(GRAPHS_DIR, "01_target_distribution.png")

    if os.path.exists(p_img9_1):
        s9.shapes.add_picture(p_img9_1, Inches(0.8), Inches(1.8), width=Inches(5.7))
    if os.path.exists(p_img9_2):
        s9.shapes.add_picture(p_img9_2, Inches(6.8), Inches(1.8), width=Inches(5.7))

    tb9 = s9.shapes.add_textbox(Inches(0.8), Inches(5.5), Inches(11.7), Inches(1.6))
    tf9 = tb9.text_frame
    tf9.word_wrap = True
    add_bullet_points(tf9, [
        "• Dual Commute Peaks on Workdays: Sharp volume spikes at 8:00 AM (470 bikes/hr) and 5:00-6:00 PM (530 bikes/hr).",
        "• Unimodal Leisure Curve on Weekends: Demand transitions to a midday curve peaking from 12:00 PM to 4:00 PM (370 bikes/hr).",
        "• Positive Target Skewness (+1.28): Mean (189.5) > Median (142.0), showing heavy tails during peak rush periods."
    ], font_size=12, space_after=6)

    set_speaker_notes(s9, 
        "Exploratory Data Analysis revealed the core behavioral rhythm of bike sharing: On working days, demand is bimodal, "
        "peaking at 8 AM and 5 PM as commuters travel to and from work. On weekends, it shifts to a smooth afternoon curve for leisure riders. "
        "Furthermore, total demand has a positive skewness of +1.28, reflecting high rush-hour surges.")

    # =========================================================
    # SLIDE 10: DATA VISUALIZATION
    # =========================================================
    s10 = prs.slides.add_slide(blank_layout)
    apply_slide_header(s10, "Data Visualization: Weather Sensitivity")

    p_img10_1 = os.path.join(GRAPHS_DIR, "07_temperature_vs_rentals.png")
    p_img10_2 = os.path.join(GRAPHS_DIR, "10_correlation_heatmap.png")

    if os.path.exists(p_img10_1):
        s10.shapes.add_picture(p_img10_1, Inches(0.8), Inches(1.8), width=Inches(5.7))
    if os.path.exists(p_img10_2):
        s10.shapes.add_picture(p_img10_2, Inches(6.8), Inches(1.8), width=Inches(5.7))

    tb10 = s10.shapes.add_textbox(Inches(0.8), Inches(5.5), Inches(11.7), Inches(1.6))
    tf10 = tb10.text_frame
    tf10.word_wrap = True
    add_bullet_points(tf10, [
        "• Temperature has Strongest Positive Correlation (+0.405): Demand increases steadily from 10°C to 30°C before flattening at extreme heat.",
        "• Humidity has Strongest Negative Correlation (-0.323): Relative humidity above 75% severely depresses bike rental volume.",
        "• Correlation Matrix: Confirms hour, temperature, and year are the dominant individual linear drivers."
    ], font_size=12, space_after=6)

    set_speaker_notes(s10, 
        "Visualizing weather impacts shows that temperature is the strongest positive driver with a correlation of +0.405, "
        "while humidity is the strongest negative driver with -0.323. When temperature rises toward 25 to 30 degrees Celsius, "
        "ridership reaches its highest levels. Conversely, rain and high humidity sharply curtail demand.")

    # =========================================================
    # SLIDE 11: MACHINE LEARNING ALGORITHMS
    # =========================================================
    s11 = prs.slides.add_slide(blank_layout)
    apply_slide_header(s11, "Machine Learning Algorithms Implemented")

    # Model 1 Card
    c11_1 = s11.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), Inches(1.8), Inches(5.7), Inches(4.8))
    c11_1.fill.solid()
    c11_1.fill.fore_color.rgb = RGBColor(248, 250, 252)
    c11_1.line.color.rgb = RGBColor(191, 219, 254)
    tf11_1 = c11_1.text_frame
    tf11_1.word_wrap = True
    
    p = tf11_1.paragraphs[0]
    p.text = "Model 1: Linear Regression (Baseline)"
    p.font.size = Pt(15)
    p.font.bold = True
    p.font.color.rgb = RGBColor(30, 58, 138)
    p.space_after = Pt(10)
    
    lr_pts = [
        "• Type: Parametric linear model.",
        "• Mechanism: Fits mathematical equation minimizing sum of squared errors via Ordinary Least Squares (OLS):",
        "  cnt = β₀ + β₁(temp) + β₂(hum) + β₃(hr) + ...",
        "• Strengths: Transparent coefficients, fast computation, interpretable baseline.",
        "• Limitation: Cannot bend to fit non-linear rush-hour spikes or multi-way interactions."
    ]
    for pt in lr_pts:
        p = tf11_1.add_paragraph()
        p.text = pt
        p.font.size = Pt(11)
        p.font.color.rgb = RGBColor(51, 65, 85)
        p.space_after = Pt(6)

    # Model 2 Card
    c11_2 = s11.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(6.8), Inches(1.8), Inches(5.7), Inches(4.8))
    c11_2.fill.solid()
    c11_2.fill.fore_color.rgb = RGBColor(248, 250, 252)
    c11_2.line.color.rgb = RGBColor(187, 247, 208)
    tf11_2 = c11_2.text_frame
    tf11_2.word_wrap = True

    p = tf11_2.paragraphs[0]
    p.text = "Model 2: Random Forest Regressor (Champion)"
    p.font.size = Pt(15)
    p.font.bold = True
    p.font.color.rgb = RGBColor(22, 101, 52)
    p.space_after = Pt(10)

    rf_pts = [
        "• Type: Non-parametric ensemble learning.",
        "• Mechanism: Combines 150 bagged decision trees trained on bootstrap data subsets with feature sub-sampling.",
        "• Final Prediction: Arithmetic average of predictions across all 150 individual trees.",
        "• Strengths: Captures complex non-linear thresholds (e.g. rush hour on clear workdays) and resists overfitting.",
        "• Hyperparameters: n_estimators=150, max_depth=18, min_samples_split=4, random_state=42."
    ]
    for pt in rf_pts:
        p = tf11_2.add_paragraph()
        p.text = pt
        p.font.size = Pt(11)
        p.font.color.rgb = RGBColor(51, 65, 85)
        p.space_after = Pt(6)

    set_speaker_notes(s11, 
        "We compared two contrasting algorithms: Linear Regression serves as our interpretable parametric baseline, "
        "estimating direct slopes for each variable. Random Forest Regressor is an ensemble bagging algorithm that combines "
        "150 decision trees. Because bike demand has conditional thresholds—like morning peaks occurring only on workdays—"
        "Random Forest's tree splits capture these complex interactions naturally.")

    # =========================================================
    # SLIDE 12: MODEL PERFORMANCE COMPARISON
    # =========================================================
    s12 = prs.slides.add_slide(blank_layout)
    apply_slide_header(s12, "Model Evaluation & Performance Benchmarking")

    # Table of Results
    t_shape12 = s12.shapes.add_table(rows=4, cols=6, left=Inches(0.8), top=Inches(1.8), width=Inches(11.7), height=Inches(2.2))
    table12 = t_shape12.table
    col_w = [Inches(2.5), Inches(1.8), Inches(1.8), Inches(1.8), Inches(1.8), Inches(2.0)]
    for idx, w in enumerate(col_w):
        table12.columns[idx].width = w

    t12_rows = [
        ("Machine Learning Model", "Train MAE", "Test MAE", "Train RMSE", "Test RMSE", "Test R² Score"),
        ("Linear Regression (Baseline)", "66.29", "102.36", "91.08", "135.70", "0.6212 (62.1%)"),
        ("Random Forest Regressor", "16.84", "65.73", "26.18", "96.75", "0.8075 (80.8%)"),
        ("Relative Improvement", "↓ 74.6%", "↓ 35.8% Lower", "↓ 71.3%", "↓ 28.7% Lower", "↑ +18.6% Gain")
    ]

    for r_idx, row in enumerate(t12_rows):
        for c_idx, val in enumerate(row):
            cell = table12.cell(r_idx, c_idx)
            cell.text = val
            p = cell.text_frame.paragraphs[0]
            p.font.size = Pt(10.5)
            p.alignment = PP_ALIGN.CENTER
            if r_idx == 0:
                p.font.bold = True
                p.font.color.rgb = RGBColor(255, 255, 255)
                cell.fill.solid()
                cell.fill.fore_color.rgb = RGBColor(30, 58, 138)
            elif r_idx == 2:
                p.font.bold = True
                p.font.color.rgb = RGBColor(22, 101, 52)
                cell.fill.solid()
                cell.fill.fore_color.rgb = RGBColor(240, 253, 244)
            elif r_idx == 3:
                p.font.bold = True
                p.font.color.rgb = RGBColor(30, 58, 138)
                cell.fill.solid()
                cell.fill.fore_color.rgb = RGBColor(239, 246, 255)

    # Embed bar chart below
    p_img12 = os.path.join(RESULTS_DIR, "model_performance_comparison.png")
    if os.path.exists(p_img12):
        s12.shapes.add_picture(p_img12, Inches(1.8), Inches(4.2), width=Inches(9.7))

    set_speaker_notes(s12, 
        "This is our key results slide. Evaluated on unseen chronological test data, Random Forest decisively outperforms "
        "Linear Regression across all metrics. Test MAE dropped by 35.8%, from 102 down to 65 bikes per hour. "
        "RMSE decreased by 28.7%, from 135 to 96. And the R-squared score jumped from 62.1% to 80.8%, demonstrating that "
        "Random Forest accounts for over 80% of total variance in real-world demand.")

    # =========================================================
    # SLIDE 13: STREAMLIT APPLICATION DEMONSTRATION
    # =========================================================
    s13 = prs.slides.add_slide(blank_layout)
    apply_slide_header(s13, "Streamlit Web Application Demonstration")

    # Embed UI mockup image
    ui_img = os.path.join(GRAPHS_DIR, "17_streamlit_app_interface.png")
    if os.path.exists(ui_img):
        s13.shapes.add_picture(ui_img, Inches(0.8), Inches(1.8), width=Inches(6.8))

    tb13 = s13.shapes.add_textbox(Inches(7.8), Inches(1.8), Inches(4.8), Inches(5.2))
    tf13 = tb13.text_frame
    tf13.word_wrap = True
    add_bullet_points(tf13, [
        "🚀 Web Dashboard Structure:",
        "1. Home: Project background and objectives.",
        "2. Predict Demand: Real-time user input sliders for season, hour, day, weather, temperature, humidity, windspeed.",
        "3. Model Comparison: Comparative metric cards and embedded diagnostic plots.",
        "4. Data Visualizations: Interactive tabs exploring historical EDA patterns.",
        "5. About Project: Complete documentation.",
        "🎯 Live Scenario Tested: Autumn Thursday, 5:00 PM, 26.5°C → 710 bikes/hr predicted (Peak Rush Surge status badge)."
    ], font_size=11.5, space_after=8)

    set_speaker_notes(s13, 
        "To make our machine learning model practically usable, we developed a 5-page interactive web dashboard using Streamlit. "
        "Users can adjust temporal sliders and weather controls. When clicking 'Predict', the system processes inputs through "
        "our serialized preprocessor pipeline and generates live predictions with color-coded demand categories and fleet advisory alerts.")

    # =========================================================
    # SLIDE 14: CONCLUSION
    # =========================================================
    s14 = prs.slides.add_slide(blank_layout)
    apply_slide_header(s14, "Project Conclusion & Academic Achievements")

    tb14 = s14.shapes.add_textbox(Inches(0.8), Inches(1.8), Inches(11.7), Inches(5.2))
    tf14 = tb14.text_frame
    tf14.word_wrap = True
    add_bullet_points(tf14, [
        "✔ End-to-End Predictive Analytics: Successfully built, benchmarked, and deployed a machine learning forecasting system for urban bike sharing.",
        "✔ Zero Data Leakage: Strictly removed casual and registered components, preserving realistic operational forecasting constraints.",
        "✔ Effective Feature Engineering: Cyclical trigonometric transformations and domain rush-hour indicators enhanced tree split accuracy.",
        "✔ Empirical Superiority: Random Forest achieved 80.75% Test R² and 65.73 Test MAE, reducing error by 35.8% compared to Linear Regression.",
        "✔ Production Web Deployment: Delivered a responsive, modern Streamlit web dashboard with instant inference and advisory alerts.",
        "✔ Software Engineering Rigor: Passed a 15-point automated integration test suite with zero errors."
    ], font_size=13.5, space_after=12)

    set_speaker_notes(s14, 
        "In conclusion, this project met all academic and technical objectives. We built a complete predictive analytics pipeline "
        "with zero data leakage, solved severe multicollinearity, proved the superiority of Random Forest with an 80.8% test R-squared, "
        "and deployed a responsive web application that solves real-world fleet rebalancing challenges.")

    # =========================================================
    # SLIDE 15: FUTURE SCOPE & REFERENCES
    # =========================================================
    s15 = prs.slides.add_slide(blank_layout)
    apply_slide_header(s15, "Future Scope & Key Academic References")

    # Left: Future Scope
    tb15_l = s15.shapes.add_textbox(Inches(0.8), Inches(1.8), Inches(5.7), Inches(5.0))
    tf15_l = tb15_l.text_frame
    tf15_l.word_wrap = True
    p = tf15_l.paragraphs[0]
    p.text = "Future Research Directions"
    p.font.size = Pt(14)
    p.font.bold = True
    p.font.color.rgb = RGBColor(30, 58, 138)
    p.space_after = Pt(8)
    add_bullet_points(tf15_l, [
        "1. Deep Learning Sequences: Implementing LSTM / GRU networks to capture multi-hour lag momentum.",
        "2. Live Weather API Integration: Connecting OpenWeatherMap API for live automated 24-hour city forecasting.",
        "3. GIS Station Routing: Extending to individual station docks and computing optimal Vehicle Routing Problem (VRP) paths for rebalancing vans.",
        "4. Dynamic Surge Pricing: Implementing elastic pricing to encourage commuters to self-rebalance bikes."
    ], font_size=11, space_after=8)

    # Right: References
    tb15_r = s15.shapes.add_textbox(Inches(6.8), Inches(1.8), Inches(5.7), Inches(5.0))
    tf15_r = tb15_r.text_frame
    tf15_r.word_wrap = True
    p = tf15_r.paragraphs[0]
    p.text = "Academic References"
    p.font.size = Pt(14)
    p.font.bold = True
    p.font.color.rgb = RGBColor(30, 58, 138)
    p.space_after = Pt(8)
    refs = [
        "[1] Fanaee-T, H., & Gama, J. (2013). Event labeling combining ensemble detectors and background knowledge. Progress in Artificial Intelligence, Springer.",
        "[2] Breiman, L. (2001). Random Forests. Machine Learning, 45(1), 5-32.",
        "[3] Pedregosa, F., et al. (2011). Scikit-learn: Machine Learning in Python. JMLR, 12, 2825-2830.",
        "[4] McKinney, W. (2010). Data Structures for Statistical Computing in Python. SciPy.",
        "[5] Streamlit Documentation (2026). https://docs.streamlit.io/"
    ]
    for r in refs:
        p = tf15_r.add_paragraph()
        p.text = r
        p.font.size = Pt(9.5)
        p.font.color.rgb = RGBColor(71, 85, 105)
        p.space_after = Pt(6)

    set_speaker_notes(s15, 
        "Finally, for future work, we plan to implement recurrent LSTM neural networks for sequence modeling, integrate live weather APIs, "
        "and optimize GPS vehicle routes for rebalancing vans. Our work is grounded in established literature by Fanaee-T and Breiman. "
        "Thank you respected evaluators. I am now ready for questions.")

    prs.save(PPTX_PATH)
    print(f"Presentation Successfully Created: {PPTX_PATH}")
    return PPTX_PATH


if __name__ == "__main__":
    build_presentation()
